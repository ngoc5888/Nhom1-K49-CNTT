import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), '..', 'lms.db')
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

print("--- STUDENTS SCHEMA ---")
print(cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='students'").fetchone()['sql'])

print("\n--- STUDENT_PORTFOLIOS SCHEMA ---")
print(cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='student_portfolios'").fetchone()['sql'])

print("\n--- ENROLLMENTS SCHEMA ---")
print(cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='enrollments'").fetchone()['sql'])

print("\n--- STUDENT_CLASSES SCHEMA ---")
print(cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='student_classes'").fetchone()['sql'])

conn.close()
