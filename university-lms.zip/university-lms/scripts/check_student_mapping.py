import zipfile
import xml.etree.ElementTree as ET
import unicodedata
import re
import sqlite3
import os

excel_path = r'C:/Users/ADMIN/.gemini/antigravity/brain/3bdfa942-0f80-4b3e-b2f1-d5a61fc784bc/.user_uploaded/media_1794448310821_b8a4c371.xlsx'
zf = zipfile.ZipFile(excel_path)
shared_strings = []
if 'xl/sharedStrings.xml' in zf.namelist():
    sst_root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
    for si in sst_root.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si'):
        t = si.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
        shared_strings.append(t.text if t is not None else ''.join([e.text for e in si.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t') if e.text]))

sheet_root = ET.fromstring(zf.read('xl/worksheets/sheet1.xml'))
rows = []
for row in sheet_root.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row'):
    r_data = []
    for c in row.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        t = c.get('t')
        v = c.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
        val = v.text if v is not None else ''
        if t == 's' and val.isdigit():
            val = shared_strings[int(val)]
        r_data.append(val)
    if any(r_data):
        rows.append(r_data)

def remove_accents(input_str):
    if not input_str:
        return ""
    # Normalize unicode
    nfkd = unicodedata.normalize('NFKD', input_str)
    no_accent = "".join([c for c in nfkd if not unicodedata.combining(c)])
    # Vietnamese specific replacements for đ, Đ
    no_accent = no_accent.replace('đ', 'd').replace('Đ', 'D')
    return no_accent

def make_email_prefix(full_name):
    clean = remove_accents(full_name).lower()
    clean = re.sub(r'[^a-z0-9\s]', '', clean)
    parts = clean.split()
    if not parts:
        return "student"
    return "".join(parts)

students_data = []
for r in rows[1:]:
    if not r or not r[0] or not r[0].isdigit() or int(r[0]) == 0:
        continue
    stt = int(r[0])
    ho = r[1].strip() if len(r) > 1 and r[1] else ""
    ten = r[2].strip() if len(r) > 2 and r[2] else ""
    lop = r[3].strip() if len(r) > 3 and r[3] else "K49 CNTT"
    full_name = f"{ho} {ten}".strip()
    
    code = f"K49CNTT{stt:02d}"
    email_base = make_email_prefix(full_name)
    email = f"{email_base}@hpu2.edu.vn"
    students_data.append({
        'stt': stt,
        'ho': ho,
        'ten': ten,
        'full_name': full_name,
        'lop': lop,
        'student_code': code,
        'email': email
    })

db_path = os.path.join(os.path.dirname(__file__), '..', 'lms.db')
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

all_emails = [r['email'] for r in cursor.execute("SELECT email FROM users").fetchall()]
all_codes = [r['student_code'] for r in cursor.execute("SELECT student_code FROM students").fetchall()]

print(f"Total students to process: {len(students_data)}")
for s in students_data:
    existing_e = s['email'] in all_emails
    existing_c = s['student_code'] in all_codes
    flag = ""
    if existing_e or existing_c:
        flag = f" [EXISTS: email={existing_e}, code={existing_c}]"
    print(f"STT {s['stt']:2d} | {s['full_name']:28s} | {s['student_code']} | {s['email']:30s}{flag}")

conn.close()
