import zipfile
import xml.etree.ElementTree as ET
import unicodedata
import re
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

# 1. Path definitions
excel_path = r'C:/Users/ADMIN/.gemini/antigravity/brain/3bdfa942-0f80-4b3e-b2f1-d5a61fc784bc/.user_uploaded/media_1794448310821_b8a4c371.xlsx'
db_path = os.path.join(os.path.dirname(__file__), '..', 'lms.db')

print(f"Loading Excel from: {excel_path}")
print(f"Target Database: {db_path}")

# 2. Extract Excel data using stdlib
zf = zipfile.ZipFile(excel_path)
shared_strings = []
if 'xl/sharedStrings.xml' in zf.namelist():
    sst_root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
    for si in sst_root.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si'):
        t = si.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
        shared_strings.append(t.text if t is not None else ''.join([e.text for e in si.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t') if e.text]))

sheet_root = ET.fromstring(zf.read('xl/worksheets/sheet1.xml'))
rows = []
for row in sheet_root.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row'):
    r_data = []
    for c in row.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        t = c.get('t')
        v = c.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
        val = v.text if v is not None else ''
        if t == 's' and val.isdigit():
            val = shared_strings[int(val)]
        r_data.append(val)
    if any(r_data):
        rows.append(r_data)

def remove_accents(input_str):
    if not input_str:
        return ""
    nfkd = unicodedata.normalize('NFKD', input_str)
    no_accent = "".join([c for c in nfkd if not unicodedata.combining(c)])
    no_accent = no_accent.replace('đ', 'd').replace('Đ', 'D')
    return no_accent

def make_email_prefix(full_name):
    clean = remove_accents(full_name).lower()
    clean = re.sub(r'[^a-z0-9\s]', '', clean)
    parts = clean.split()
    return "".join(parts) if parts else "student"

students_data = []
for r in rows[1:]:
    if not r or not r[0] or not r[0].isdigit() or int(r[0]) == 0:
        continue
    stt = int(r[0])
    ho = r[1].strip() if len(r) > 1 and r[1] else ""
    ten = r[2].strip() if len(r) > 2 and r[2] else ""
    lop = r[3].strip() if len(r) > 3 and r[3] else "K49 CNTT"
    
    # Capitalize names cleanly
    if ho and ten:
        # Title case if all lower (e.g. 'visouda vy')
        if ho.islower():
            ho = ho.title()
        if ten.islower():
            ten = ten.title()
        full_name = f"{ho} {ten}".strip()
    else:
        full_name = (ho or ten).strip()
        
    code = f"K49CNTT{stt:02d}"
    email = f"{make_email_prefix(full_name)}@hpu2.edu.vn"
    
    students_data.append({
        'stt': stt,
        'ho': ho,
        'ten': ten,
        'full_name': full_name,
        'lop': lop,
        'student_code': code,
        'email': email,
        'password': '123456'
    })

print(f"Parsed {len(students_data)} students from spreadsheet.")

# 3. Connect to SQLite DB
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

# 4. Ensure class 'K49 CNTT' exists
cursor.execute("SELECT id FROM student_classes WHERE code = 'K49-CNTT' OR name = 'K49 CNTT'")
class_row = cursor.fetchone()
if class_row:
    k49_class_id = class_row['id']
    print(f"Found existing class 'K49 CNTT' (id: {k49_class_id})")
else:
    cursor.execute("""
        INSERT INTO student_classes (major_id, code, name, year)
        VALUES (1, 'K49-CNTT', 'K49 CNTT', '2023-2027')
    """)
    k49_class_id = cursor.lastrowid
    print(f"Created new class 'K49 CNTT' (id: {k49_class_id})")

# 5. Insert / Update each student
default_pass_hash = generate_password_hash('123456')
created_count = 0
updated_count = 0
results = []

for s in students_data:
    stt = s['stt']
    full_name = s['full_name']
    email = s['email']
    code = s['student_code']
    password = s['password']
    
    # Check if user with this email exists
    cursor.execute("SELECT id, email, full_name FROM users WHERE email = ?", (email,))
    existing_user = cursor.fetchone()
    
    if existing_user:
        user_id = existing_user['id']
        cursor.execute("""
            UPDATE users
            SET full_name = ?, password_hash = ?, role = 'student', is_active = 1
            WHERE id = ?
        """, (full_name, default_pass_hash, user_id))
        
        # Ensure in students table
        cursor.execute("SELECT user_id FROM students WHERE user_id = ?", (user_id,))
        if cursor.fetchone():
            cursor.execute("""
                UPDATE students
                SET student_code = ?, department_id = 1, major_id = 1, student_class_id = ?
                WHERE user_id = ?
            """, (code, k49_class_id, user_id))
        else:
            cursor.execute("""
                INSERT INTO students (user_id, student_code, department_id, major_id, student_class_id)
                VALUES (?, ?, 1, 1, ?)
            """, (user_id, code, k49_class_id))
        updated_count += 1
        action = "UPDATED"
    else:
        # Check if student_code already exists in students table
        cursor.execute("SELECT user_id FROM students WHERE student_code = ?", (code,))
        existing_code_row = cursor.fetchone()
        if existing_code_row:
            user_id = existing_code_row['user_id']
            cursor.execute("""
                UPDATE users
                SET email = ?, full_name = ?, password_hash = ?, role = 'student', is_active = 1
                WHERE id = ?
            """, (email, full_name, default_pass_hash, user_id))
            cursor.execute("""
                UPDATE students
                SET department_id = 1, major_id = 1, student_class_id = ?
                WHERE user_id = ?
            """, (k49_class_id, user_id))
            updated_count += 1
            action = "UPDATED"
        else:
            cursor.execute("""
                INSERT INTO users (email, password_hash, full_name, role, phone, is_active, avatar)
                VALUES (?, ?, ?, 'student', '', 1, '/static/images/default_avatar.png')
            """, (email, default_pass_hash, full_name))
            user_id = cursor.lastrowid
            
            cursor.execute("""
                INSERT INTO students (user_id, student_code, department_id, major_id, student_class_id)
                VALUES (?, ?, 1, 1, ?)
            """, (user_id, code, k49_class_id))
            created_count += 1
            action = "CREATED"
            
    # Ensure student portfolio exists
    cursor.execute("SELECT id FROM student_portfolios WHERE student_id = ?", (user_id,))
    if not cursor.fetchone():
        cursor.execute("""
            INSERT INTO student_portfolios (student_id, headline, bio, is_public)
            VALUES (?, 'Sinh viên K49 CNTT nhiệt huyết & sáng tạo', 'Chào mừng bạn đến với Hồ sơ năng lực số của tôi!', 1)
        """, (user_id,))
        
    # Enroll into Course 1 and Course 2
    for course_id in [1, 2]:
        cursor.execute("""
            INSERT OR IGNORE INTO enrollments (course_id, student_id, status)
            VALUES (?, ?, 'active')
        """, (course_id, user_id))
        
    results.append({
        'stt': stt,
        'user_id': user_id,
        'full_name': full_name,
        'student_code': code,
        'email': email,
        'password': password,
        'class': 'K49 CNTT',
        'action': action
    })

conn.commit()
print(f"Database update complete! Created: {created_count}, Updated: {updated_count}, Total: {len(results)}")

# 6. Verify Logins
print("\nVerifying Accounts & Login Capability...")
all_pass = True
for r in results:
    u = cursor.execute("""
        SELECT u.*, st.student_code, sc.name as class_name
        FROM users u
        LEFT JOIN students st ON u.id = st.user_id
        LEFT JOIN student_classes sc ON st.student_class_id = sc.id
        WHERE u.email = ? OR st.student_code = ?
    """, (r['email'], r['student_code'])).fetchone()
    
    if not u:
        print(f"FAILED: User not found for {r['email']}")
        all_pass = False
        continue
        
    pwd_valid = check_password_hash(u['password_hash'], r['password'])
    if not pwd_valid:
        print(f"FAILED: Password hash check failed for {r['email']}")
        all_pass = False
        continue

    # Check enrollments
    enroll_cnt = cursor.execute("SELECT COUNT(*) FROM enrollments WHERE student_id = ?", (u['id'],)).fetchone()[0]
    if enroll_cnt < 2:
        print(f"FAILED: Missing enrollments for user {u['id']}")
        all_pass = False

print(f"All 34 students verified successfully: {all_pass}")

conn.close()
