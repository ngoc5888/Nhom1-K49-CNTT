import sys
import os

# Add app to path
app_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, app_dir)
sys.path.insert(0, os.path.join(app_dir, 'app'))

from app import create_app

app = create_app()
client = app.test_client()

print("=" * 60)
print("TESTING K49 CNTT STUDENT LOGIN FLOW VIA FLASK TEST CLIENT")
print("=" * 60)

test_cases = [
    ("Login via Email", "dovietanh@hpu2.edu.vn", "123456"),
    ("Login via Student Code", "K49CNTT01", "123456"),
    ("Login via Student Code STT 27", "K49CNTT27", "123456"),
    ("Login via Email STT 27", "phamquyet@hpu2.edu.vn", "123456"),
    ("Login via Student Code STT 34", "K49CNTT34", "123456"),
    ("Login via Email STT 34", "lexuanmanh@hpu2.edu.vn", "123456"),
    ("Login via Email STT 32 (Visouda Vy)", "visoudavy@hpu2.edu.vn", "123456"),
]

all_passed = True
for name, identity, pwd in test_cases:
    # 1. Post to /login
    resp = client.post('/login', data={'email': identity, 'password': pwd}, follow_redirects=True)
    if resp.status_code == 200 and (b'dashboard' in resp.data.lower() or b'student' in resp.data.lower()):
        # Check if dashboard was reached
        print(f"[PASS] {name} ({identity}) -> Login successful, redirected to Student Portal!")
    else:
        print(f"[FAIL] {name} ({identity}) -> Status: {resp.status_code}")
        all_passed = False
        
    # Logout
    client.get('/logout', follow_redirects=True)

# Test accessing dashboard and verifying student data
with client:
    resp = client.post('/login', data={'email': 'dovietanh@hpu2.edu.vn', 'password': '123456'}, follow_redirects=True)
    dash_resp = client.get('/student/dashboard')
    content = dash_resp.data.decode('utf-8', errors='ignore')
    has_name = "Đỗ Việt Anh" in content
    has_class = "K49 CNTT" in content
    print(f"\nStudent Profile in Dashboard:")
    print(f"  - Full name displayed: {'PASS' if has_name else 'FAIL'}")
    print(f"  - Class 'K49 CNTT' displayed: {'PASS' if has_class else 'FAIL'}")
    
    classes_resp = client.get('/student/classes')
    has_web = "Lập trình Web" in classes_resp.data.decode('utf-8', errors='ignore')
    has_db = "Cơ sở dữ liệu" in classes_resp.data.decode('utf-8', errors='ignore')
    print(f"Enrolled Courses Access:")
    print(f"  - Lập trình Web: {'PASS' if has_web else 'FAIL'}")
    print(f"  - Cơ sở dữ liệu: {'PASS' if has_db else 'FAIL'}")

print("=" * 60)
print(f"ALL STUDENT LOGIN AND PORTAL TESTS: {'SUCCESS' if all_passed and has_name and has_class and has_web and has_db else 'FAILED'}")
print("=" * 60)
