@echo off
title Tao Link Truy Cap Cong Khai Qua Internet - University LMS
echo ================================================================
echo   TAO LINK CONG KHAI (PUBLIC HOST) TRUY CAP QUA INTERNET
echo   Dung cho sinh vien / giang vien truy cap tu bat ky dau (4G/Nha)
echo ================================================================
echo.
echo He thong dang tao duong dan HTTPS truc tuyen mien phi...
echo Luu y: Dam bao server Flask (start.bat) dang chay o cong 5000!
echo.
npx localtunnel --port 5000
pause
