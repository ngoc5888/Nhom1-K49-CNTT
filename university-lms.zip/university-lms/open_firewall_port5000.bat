@echo off
:: Batch script to open Port 5000 for LAN access in Windows Firewall
echo ================================================================
echo   MO CONG 5000 WINDOWS FIREWALL DE CHO PHEP TRUY CAP MANG LAN
echo ================================================================
echo.

:: Check for administrative rights
net session >nul 2>&1
if %errorLevel% == 0 (
    echo Dang chay voi quyen Administrator...
) else (
    echo [THONG BAO] Dang yeu cau quyen Administrator (UAC)...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

netsh advfirewall firewall show rule name="University LMS (Port 5000)" >nul 2>&1
if %errorLevel% == 0 (
    echo Quy tac tuong lua da ton tai. Dang cap nhat...
    netsh advfirewall firewall delete rule name="University LMS (Port 5000)"
)

netsh advfirewall firewall add rule name="University LMS (Port 5000)" dir=in action=allow protocol=TCP localport=5000 profile=any
echo.
echo ================================================================
echo   DA MO CONG 5000 THANH CONG TREN WINDOWS FIREWALL!
echo   Cac thiet bi khac trong cung mang Wi-Fi / LAN gio co the
echo   truy cap vao he thong qua dia chi IP cua may nay.
echo ================================================================
echo.
pause
