# BÁO CÁO PHÂN TÍCH TOÀN BỘ HỆ THỐNG LMS & BASELINE TRƯỚC NÂNG CẤP
**Dự án:** AI-Powered Smart Learning Ecosystem  
**Giai đoạn:** PROMPT 0 – Phase 0: System Analysis & Baseline  
**Thời điểm lập:** 10/11/2026  
**Trạng thái:** HOÀN THÀNH (100% Khảo sát & Đánh giá - Bảo toàn nguyên trạng mã nguồn và CSDL)

---

## 1. TỔNG QUAN CÔNG NGHỆ VÀ MÔI TRƯỜNG HIỆN TẠI

Hệ thống LMS hiện tại là một ứng dụng Web hoàn chỉnh theo kiến trúc Monolith chuẩn MVC/MTV trên nền tảng Python Flask, phục vụ trường đại học với 3 phân quyền chính thức (Admin, Giảng viên, Sinh viên).

### 1.1. Công nghệ Frontend
- **Ngôn ngữ:** HTML5, CSS3, JavaScript (Vanilla ES6, không dùng framework frontend nặng để tối ưu tốc độ và đơn giản hóa môi trường).
- **CSS Framework:** Tailwind CSS (nhúng qua CDN với cấu hình mở rộng màu chủ đạo Navy `#0f172a`, Pink `#ec4899`, Purple `#7c3aed`).
- **Thư viện Icon:** FontAwesome 6.5.1 CDN (bộ icon đồng bộ, chuẩn giáo dục).
- **Biểu đồ & Trực quan hóa:** Chart.js (tích hợp trực tiếp trên dashboard và trang báo cáo thống kê đa chiều).
- **Font chữ:** Google Fonts (`Plus Jakarta Sans` - hỗ trợ tiếng Việt đầy đủ).
- **Thiết kế:** Responsive hoàn toàn (Desktop, Tablet, Mobile) với thanh điều hướng Sidebar có cơ chế đóng/mở linh hoạt trên màn hình nhỏ.

### 1.2. Công nghệ Backend
- **Ngôn ngữ lập trình:** Python 3.13.x.
- **Web Framework:** Flask 3.0.x (sử dụng mẫu thiết kế Application Factory `create_app()` và Blueprints phân tách theo vai trò).
- **WSGI / Security Utility:** Werkzeug >= 3.0.0 (quản lý hàm băm mật khẩu `generate_password_hash`, `check_password_hash` và middleware kiểm soát request).
- **Cơ chế xác thực (Authentication):** Quản lý phiên làm việc Session phía máy chủ (`flask.session`), kết hợp cookie HTTP-Only có mã bí mật ký số `SECRET_KEY`.
- **Cơ chế phân quyền (Authorization - RBAC):** Decorators `@login_required` và `@role_required('admin', 'teacher', 'student')` kiểm soát mọi Route tại Backend.
- **Bộ lọc kiểm soát toàn cục (Global Interceptors):** `@app.before_request` hook tự động chặn/chuyển hướng người dùng khi hệ thống bật chế độ Bảo trì (`/maintenance`) hoặc Khóa khẩn cấp (`/system-locked`), ngoại trừ Quản trị viên (Admin không bao giờ bị khóa).

### 1.3. Cơ sở dữ liệu & Lưu trữ (Data Layer)
- **Hệ quản trị CSDL:** SQLite 3 (`lms.db` kích thước ~438 KB, chứa đầy đủ cấu trúc quan hệ toàn vẹn).
- **Cơ chế kết nối:** Thư viện chuẩn `sqlite3` của Python, sử dụng ngữ cảnh Flask `g.db` và `row_factory = sqlite3.Row` cho phép truy xuất dữ liệu theo tên cột như Dictionary.
- **Ràng buộc quan hệ:** Kích hoạt chế độ kiểm tra khóa ngoại bắt buộc `PRAGMA foreign_keys = ON`.
- **Lưu trữ tệp tin:** Tệp tin tải lên (slide, giáo trình, bài nộp của sinh viên) được lưu trữ tại đường dẫn tĩnh nội bộ `app/static/uploads/`.

### 1.4. Khởi chạy & Vận hành (Deployment)
- **File khởi chạy chính:** `run.py` (tự động kiểm tra cài đặt thư viện thiếu, kiểm tra database tồn tại, tự động kích hoạt chế độ UTF-8 stdout trên môi trường Windows).
- **Script Windows:** `start.bat` hỗ trợ khởi động nhanh với 1 cú click chuột.
- **Địa chỉ máy chủ nội bộ:** `http://127.0.0.1:5000` (chế độ phát triển Debug mode).

---

## 2. SƠ ĐỒ CẤU TRÚC THƯ MỤC DỰ ÁN

```text
F:\THCN_HTQLHT\university-lms
│
├── app/                                    # Thư mục mã nguồn chính của ứng dụng
│   ├── __init__.py                         # Application Factory, cấu hình & Interceptor toàn cục
│   ├── auth.py                             # Logic xác thực, phân quyền RBAC & Decorators
│   ├── database.py                         # Khởi tạo Schema CSDL (21 bảng) & Helper truy vấn
│   ├── seed.py                             # Script khởi tạo dữ liệu mẫu ban đầu
│   ├── enrich_data.py                      # Script làm giàu dữ liệu năm học, học kỳ, thông báo
│   ├── balance_distribution.py             # Script chuẩn hóa dữ liệu thực tế (54 SV, 20 GV, 10 Khoa)
│   ├── verify_system.py                    # Script kiểm tra tích hợp tự động 8 kịch bản (100% PASS)
│   ├── test_full_suite.py                  # Script kiểm tra hồi quy 27 Routes (100% 200 OK)
│   │
│   ├── routes/                             # Các Blueprint phụ trách định tuyến và nghiệp vụ
│   │   ├── admin_routes.py                 # Nghiệp vụ Quản trị viên (550+ dòng code, 16 endpoints)
│   │   ├── teacher_routes.py               # Nghiệp vụ Giảng viên (16 endpoints)
│   │   ├── student_routes.py               # Nghiệp vụ Sinh viên (12 endpoints)
│   │   ├── auth_routes.py                  # Đăng nhập, Đăng xuất, Khôi phục mật khẩu (4 endpoints)
│   │   └── common_routes.py                # Thông báo, Hồ sơ, Trang bảo trì, Khóa hệ thống (6 endpoints)
│   │
│   ├── static/                             # Tệp tin tĩnh
│   │   ├── uploads/                        # Thư mục lưu trữ bài giảng, học liệu và bài nộp
│   │   └── images/                         # Ảnh đại diện mặc định, logo
│   │
│   └── templates/                          # 32 Giao diện Jinja2 HTML chuẩn Tailwind CSS
│       ├── base.html                       # Giao diện khung dùng chung (Sidebar, Header, Footer)
│       ├── admin/                          # 5 templates quản trị (Dashboard, Users, Education, Reports, Notifications)
│       ├── teacher/                        # 9 templates giảng dạy (Dashboard, Classes, Materials, Assignments, Exams,...)
│       ├── student/                        # 10 templates học tập (Dashboard, Classes, Materials, Exams, Results,...)
│       ├── auth/                           # 3 templates xác thực (Login, Register, Forgot Password)
│       └── common/                         # 4 templates tiện ích (Notifications, Profile, Maintenance, System Locked)
│
├── documentation/                          # Thư mục tài liệu kỹ thuật & kiến trúc
│   └── PHASE0_SYSTEM_ANALYSIS_BASELINE.md  # Bản báo cáo khảo sát chi tiết này
│
├── lms.db                                  # Cơ sở dữ liệu SQLite thực tế (21 bảng chuẩn hóa)
├── requirements.txt                        # Danh mục thư viện phụ thuộc (Flask, Werkzeug)
├── run.py                                  # Điểm kích hoạt ứng dụng máy chủ
├── start.bat                               # Kịch bản khởi chạy 1-click trên Windows
└── README.md                               # Hướng dẫn cài đặt và sử dụng hệ thống
```

---

## 3. DANH SÁCH VÀ PHÂN TÍCH CHỨC NĂNG HIỆN CÓ

Hệ thống hiện sở hữu tổng cộng **55 Endpoints** đã được phân quyền chặt chẽ:

### 3.1. Phân hệ Quản trị viên (Admin) - Blueprint: `admin_bp` (Prefix: `/admin`)
1. `GET /admin/dashboard`: Bảng điều khiển trung tâm với 12 thẻ chỉ số thống kê thời gian thực (KPI).
2. `POST /admin/system/toggle-maintenance`: Bật/Tắt chế độ bảo trì toàn hệ thống.
3. `POST /admin/system/toggle-lock`: Kích hoạt/Gỡ bỏ trạng thái khóa khẩn cấp toàn trường.
4. `GET, POST /admin/notifications`: Trung tâm phát thông báo Broadcast (Toàn trường, Toàn bộ GV, Toàn bộ SV).
5. `POST /admin/notification/<id>/delete`: Xóa bản tin thông báo phát thanh.
6. `GET /admin/users`: Quản lý danh sách tài khoản kèm bộ lọc đa tiêu chí (Vai trò, Trạng thái hoạt động, Tìm kiếm).
7. `POST /admin/user/create`: Tạo tài khoản mới (Admin/GV/SV) với mật khẩu ban đầu và phân bổ khoa/lớp.
8. `POST /admin/user/<id>/edit`: Chỉnh sửa thông tin tài khoản, email, số điện thoại, vai trò.
9. `GET /admin/user/<id>/json`: API nội bộ trả về JSON dữ liệu người dùng phục vụ Modal chỉnh sửa.
10. `GET /admin/user/<id>/toggle-status`: Khóa hoặc Mở khóa tài khoản ngay lập tức.
11. `GET, POST /admin/user/<id>/delete`: Xóa tài khoản người dùng kèm xác thực an toàn.
12. `GET /admin/education`: Quản lý danh mục đào tạo (Khoa, Ngành, Môn học, Lớp sinh hoạt, Niên khóa, Học kỳ).
13. `POST /admin/department/create`: Tạo mới Khoa chuyên môn.
14. `POST /admin/major/create`: Tạo mới Ngành đào tạo trực thuộc Khoa.
15. `POST /admin/subject/create`: Tạo mới Môn học và cấu hình số tín chỉ.
16. `GET /admin/reports`: Báo cáo thống kê chuyên sâu 4 chiều (Năm, Kỳ, Khoa, Môn), 5 khối A-E, 7 đồ thị Chart.js và hỗ trợ xuất CSV.

### 3.2. Phân hệ Giảng viên (Teacher) - Blueprint: `teacher_bp` (Prefix: `/teacher`)
1. `GET /teacher/dashboard`: Bảng điều khiển giảng viên, số lớp phụ trách, bài chờ chấm, thi sắp diễn ra.
2. `GET /teacher/classes`: Danh sách các lớp học phần được phân công giảng dạy.
3. `POST /teacher/class/create`: Khởi tạo lớp học phần mới theo phân bổ.
4. `GET /teacher/materials`: Quản lý kho học liệu số (slide, giáo trình PDF, tài liệu tham khảo).
5. `POST /teacher/material/upload`: Tải lên học liệu mới kèm phân loại file và lớp học phần.
6. `GET /teacher/assignments`: Quản lý danh sách bài tập về nhà theo từng học phần.
7. `POST /teacher/assignment/create`: Thiết lập bài tập mới kèm hạn nộp (Deadline) và thang điểm.
8. `GET /teacher/assignment/<id>/submissions`: Theo dõi tiến độ nộp bài của sinh viên trong lớp.
9. `POST /teacher/submission/<id>/grade`: Chấm điểm bài tập thang 10 kèm nhận xét phản hồi chi tiết.
10. `GET /teacher/exams`: Danh sách các đợt thi trắc nghiệm trực tuyến.
11. `POST /teacher/exam/create`: Tạo phòng thi mới (thời gian mở/đóng, thời lượng làm bài phút).
12. `GET /teacher/exam/<id>/questions`: Quản trị ngân hàng câu hỏi của đề thi.
13. `POST /teacher/exam/<id>/question/add`: Thêm câu hỏi trắc nghiệm (Nội dung, 4 đáp án A-B-C-D, đáp án đúng).
14. `GET /teacher/grades`: Sổ điểm tổng hợp lớp học phần ($A_1$ 20%, $A_2$ 30%, $A_3$ 50%, điểm chữ, GPA).
15. `POST /teacher/grades/update`: Cập nhật bảng điểm định kỳ cho sinh viên.
16. `GET, POST /teacher/notifications`: Gửi và quản lý thông báo riêng tới từng lớp học phần phụ trách.

### 3.3. Phân hệ Sinh viên (Student) - Blueprint: `student_bp` (Prefix: `/student`)
1. `GET /student/dashboard`: Tổng quan tiến độ học tập, bài tập sắp đến hạn, ca thi sắp tới, GPA hiện tại.
2. `GET /student/classes`: Danh sách các lớp học phần sinh viên đang ghi danh.
3. `GET /student/class/<id>`: Chi tiết lớp học phần, thông tin giảng viên, tài liệu và bảng tin lớp.
4. `GET /student/materials`: Khai thác và tải về các tài liệu bài giảng của các môn đang học.
5. `GET /student/assignments`: Danh sách bài tập cần hoàn thành kèm thời hạn nộp.
6. `GET /student/assignment/<id>`: Xem yêu cầu chi tiết của bài tập.
7. `POST /student/assignment/<id>/submit`: Nộp file bài tập hoặc nội dung giải trực tuyến.
8. `GET /student/exams`: Danh sách các bài thi trắc nghiệm đang mở hoặc đã hoàn thành.
9. `GET /student/exam/<id>/take`: Phòng thi trực tuyến với đồng hồ đếm ngược JS tự động.
10. `POST /student/exam/<id>/submit`: Nộp bài thi trắc nghiệm và kích hoạt chấm điểm tự động.
11. `GET /student/exam/<id>/result`: Xem ngay kết quả bài thi, điểm số và số câu đúng.
12. `GET /student/academic-results`: Tra cứu bảng điểm chi tiết, GPA thang 10 & 4, xếp loại học lực toàn khóa.

### 3.4. Phân hệ Xác thực & Tiện ích chung (Auth & Common)
1. `GET, POST /login`: Đăng nhập hệ thống bằng Email/Mã định danh + Mật khẩu.
2. `GET, POST /register`: Thông báo đóng đăng ký công khai; hướng dẫn liên hệ Admin cấp tài khoản.
3. `GET, POST /forgot-password`: Cơ chế cấp lại mật khẩu tạm thời mặc định an toàn.
4. `GET /logout`: Xóa phiên làm việc và đăng xuất an toàn.
5. `GET /notifications`: Hộp thư thông báo cá nhân (phân trang, đánh dấu đã đọc, xóa thông báo).
6. `GET /profile`: Xem hồ sơ cá nhân và đổi mật khẩu có kiểm tra mật khẩu cũ.
7. `GET /maintenance`: Trang thông báo hệ thống đang bảo trì.
8. `GET /system-locked`: Trang thông báo hệ thống bị khóa khẩn cấp.

---

## 4. PHÂN TÍCH CƠ SỞ DỮ LIỆU HIỆN CÓ (DATABASE SCHEMA & DATA)

Hệ thống vận hành trên CSDL SQLite gồm **21 bảng quan hệ**. Dữ liệu mẫu thực tế và tính toàn vẹn khóa ngoại như sau:

| STT | Tên bảng | Số dòng | Số cột | Khóa ngoại | Chức năng nghiệp vụ chính |
| :---: | :--- | :---: | :---: | :---: | :--- |
| 1 | `users` | 73 | 9 | 0 | Lưu tài khoản định danh (1 Admin, 20 Giảng viên, 52 Sinh viên). |
| 2 | `departments` | 10 | 4 | 0 | 10 Khoa chuyên môn của trường đại học. |
| 3 | `majors` | 10 | 4 | 1 | 10 Ngành đào tạo đại học (`department_id`). |
| 4 | `student_classes`| 40 | 5 | 1 | 40 Lớp sinh hoạt hành chính (`major_id`). |
| 5 | `students` | 54 | 5 | 4 | Hồ sơ chi tiết SV (`user_id`, `department_id`, `major_id`, `student_class_id`). |
| 6 | `teachers` | 20 | 4 | 2 | Hồ sơ giảng viên (`user_id`, `department_id`). |
| 7 | `subjects` | 20 | 6 | 1 | 20 Môn học và số tín chỉ (`department_id`). |
| 8 | `courses` | 42 | 10 | 2 | 42 Lớp học phần đào tạo (`subject_id`, `teacher_id`). |
| 9 | `enrollments` | 405 | 5 | 2 | Ghi danh sinh viên vào lớp học phần (`course_id`, `student_id`). |
| 10 | `materials` | 10 | 9 | 2 | Học liệu số đã đăng tải (`course_id`, `uploaded_by`). |
| 11 | `assignments` | 6 | 9 | 2 | Bài tập đã giao (`course_id`, `created_by`). |
| 12 | `submissions` | 2 | 9 | 2 | Bài nộp của sinh viên (`assignment_id`, `student_id`). |
| 13 | `exams` | 2 | 10 | 2 | Đợt thi trắc nghiệm (`course_id`, `created_by`). |
| 14 | `questions` | 5 | 7 | 1 | Câu hỏi thi trắc nghiệm kèm JSON đáp án (`exam_id`). |
| 15 | `exam_results` | 2 | 9 | 2 | Điểm số và bài làm thi trắc nghiệm (`exam_id`, `student_id`). |
| 16 | `grades` | 248 | 10 | 2 | Điểm tổng hợp học phần: A1, A2, A3, điểm chữ (`course_id`, `student_id`). |
| 17 | `notifications` | 1472 | 8 | 1 | Hộp thư thông báo cá nhân (`user_id`). |
| 18 | `announcements` | 24 | 7 | 2 | Bảng tin thông báo toàn trường hoặc lớp học phần (`sender_id`, `course_id`). |
| 19 | `academic_years`| 8 | 5 | 0 | Niên khóa từ 2020-2021 đến 2027-2028. |
| 20 | `semesters` | 16 | 5 | 1 | 16 Học kỳ (HK1, HK2 cho từng năm học) (`academic_year_id`). |
| 21 | `system_settings`| 4 | 3 | 0 | Cấu hình bảo trì, khóa hệ thống và tham số vận hành (`key-value`). |

### Phân biệt tuyệt đối giữa các khái niệm đào tạo:
1. **Lớp sinh hoạt (`student_classes`)**: Là đơn vị hành chính quản lý sinh viên suốt 4 năm học (ví dụ: *CNTT-K68A*), gắn liền với Ngành học và Khoa.
2. **Lớp học phần (`courses`)**: Là đơn vị tổ chức học tập của một Môn học cụ thể trong một Học kỳ nhất định, do một Giảng viên phụ trách (ví dụ: *Lập trình Web - Nhóm 01 - HK1 2024-2025*).
3. **Đăng ký học phần (`enrollments`)**: Bản ghi kết nối một sinh viên cụ thể tham gia vào một lớp học phần.
4. **Giảng viên phụ trách (`courses.teacher_id`)**: Phân công giảng dạy của giảng viên trên lớp học phần đó.

---

## 5. ĐÁNH GIÁ CHẤT LƯỢNG HỆ THỐNG VÀ CÁC ĐIỂM CẦN LƯU Ý

### 5.1. Điểm mạnh hiện tại (Baseline Quality)
- **Hoạt động ổn định 100%**: 2 kịch bản kiểm thử toàn diện `test_full_suite.py` (27 route) và `verify_system.py` (8 bài test nghiệp vụ & an ninh) đều vượt qua 100%.
- **Bảo mật phân quyền tốt**: Cơ chế RBAC ngăn chặn triệt để sinh viên truy cập vào các chức năng của giảng viên hoặc quản trị viên; ngăn chặn giảng viên chấm điểm lớp không phân công.
- **An ninh dữ liệu**: Toàn bộ câu lệnh SQL đều sử dụng tham số hóa SQLite (`?`), loại trừ rủi ro SQL Injection. Mật khẩu được băm chuẩn `pbkdf2:sha256`.
- **Cơ chế kiểm soát sự cố tốt**: Chế độ Bảo trì và Khóa khẩn cấp được triển khai ở tầng Middleware `@app.before_request`, đảm bảo an toàn tuyệt đối khi cần dừng hệ thống để xử lý sự cố.

### 5.2. Các điểm cần hoàn thiện và tối ưu khi nâng cấp thành Smart Ecosystem
1. **Cấu hình biến môi trường (`.env`)**: Khóa bí mật `SECRET_KEY` hiện đang fix cứng trong mã nguồn (`app/__init__.py`), cần chuyển sang nạp từ biến môi trường để an toàn khi tích hợp AI API Key.
2. **Tách biệt Service Layer**: Hiện một số route controller chứa cả logic nghiệp vụ và truy vấn CSDL trực tiếp. Cần bổ sung các lớp dịch vụ độc lập (`services/`) cho các module thông minh mới (AI Service, Analytics Engine, Adaptive Engine).
3. **Audit Log & Activity Logging**: Chưa có bảng chuyên biệt lưu vết thao tác người dùng (Audit Log) và hành vi học tập chi tiết (Learning Activities Event Log) để phục vụ thuật toán phân tích học tập (Learning Analytics).
4. **Cơ chế RAG & AI Vector**: Cần chuẩn bị thư viện trích xuất văn bản (PDF, DOCX, TXT) và bộ nhớ vector/embeddings để hỗ trợ tính năng AI hỏi đáp theo tài liệu học phần.

---

## 6. DANH MỤC CÁC CHỨC NĂNG CẦN BẢO TOÀN NGUYÊN TRẠNG

Theo nguyên tắc bất biến tại Phần A của Dự án, các thành phần sau **TUYỆT ĐỐI BẢO TOÀN NGUYÊN TRẠNG**:
- Toàn bộ 21 bảng CSDL hiện hữu và 100% dữ liệu đã có (tài khoản, điểm số, học liệu, đề thi, khoa, ngành, lớp sinh hoạt, lớp học phần).
- Logic đăng nhập hiện tại (`/login`), đăng xuất (`/logout`), đổi mật khẩu (`/profile`).
- Logic tính điểm thành phần: $A_1$ (20%), $A_2$ (30%), $A_3$ (50%) và thang điểm chữ.
- Logic phòng thi trực tuyến của sinh viên (giao diện làm bài, đồng hồ đếm ngược JS, tự nộp bài khi hết giờ).
- Toàn bộ giao diện màu sắc chủ đạo Tailwind CSS và bố cục hiện tại của Admin, Teacher, Student.
- Cơ chế bảo vệ `@app.before_request` (Maintenance mode & System Lock).

---

## 7. ĐỀ XUẤT KIẾN TRÚC MỞ RỘNG (SMART LEARNING ECOSYSTEM)

Kiến trúc mở rộng tuân theo mô hình **Modular Monolith kết hợp AI Services Layer độc lập**:

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                    AI-POWERED SMART LEARNING ECOSYSTEM                      │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
        ┌─────────────────────────────┼─────────────────────────────┐
        ▼                             ▼                             ▼
┌──────────────────┐        ┌──────────────────┐        ┌──────────────────┐
│  CORE LMS LAYER  │        │ SMART ECOSYSTEM  │        │   AI SERVICES    │
│  (Bảo toàn 100%) │        │   (Mở rộng mới)  │        │ (Độc lập & Cách ly)│
├──────────────────┤        ├──────────────────┤        ├──────────────────┤
│• Quản trị Admin  │        │• Learning        │        │• AI Gateway API  │
│• Đào tạo tín chỉ │        │  Analytics       │        │  (Gemini/Claude) │
│• Lớp học phần    │        │• Predictive      │        │• RAG Engine      │
│• Giảng dạy & Thi │        │  Intervention    │        │  (Vector Search) │
│• Sổ điểm & GPA   │        │• Adaptive Path   │        │• AI Student Bot  │
│• Thông báo lớp   │        │• Smart Study     │        │• AI Teacher Bot  │
│• Bảo trì & Lock  │        │• Competency Map  │        │• Token & Cost    │
│                  │        │• Portfolio/Badge │        │  Usage Monitor   │
└────────┬─────────┘        └────────┬─────────┘        └────────┬─────────┘
         │                           │                           │
         └───────────────────────────┼───────────────────────────┘
                                     ▼
                    ┌─────────────────────────────────┐
                    │    DATA & PERSISTENCE LAYER     │
                    ├─────────────────────────────────┤
                    │• SQLite Database (21 Bảng cũ)   │
                    │• New Extension Tables:          │
                    │  - audit_logs                   │
                    │  - learning_activities          │
                    │  - document_embeddings (RAG)    │
                    │  - ai_conversations             │
                    │  - competencies & badges        │
                    │• Local File Storage (Static)    │
                    └─────────────────────────────────┘
```

---

## 8. KẾ HOẠCH LỘ TRÌNH TRIỂN KHAI TỪNG GIAI ĐOẠN

1. **Phase 1: Nền tảng Dữ liệu, Bảo mật, Audit Log & Learning Activities**
   - Bổ sung bảng `audit_logs` (ghi vết tạo/sửa/khóa tài khoản, sửa điểm).
   - Bổ sung bảng `learning_activities` (ghi vết mở tài liệu, nộp bài, thi).
   - Tích hợp nạp cấu hình bảo mật từ biến môi trường (`.env`).
   - Xây dựng lớp API nội bộ chuẩn hóa response JSON.
2. **Phase 2: Learning Analytics & Predictive Learning Analytics**
   - Xây dựng `/admin/analytics` và `/teacher/analytics` (dựa trên dữ liệu thực tế 100%).
   - Thuật toán phân nhóm cảnh báo học tập sớm (Cần hỗ trợ, Cần theo dõi, Bình thường).
   - Tích hợp AI Insights tóm tắt xu hướng học tập.
3. **Phase 3: AI Services, AI Learning Assistant & AI Teacher Assistant**
   - Xây dựng AI Gateway quản lý API Key, kiểm soát token/chi phí, cơ chế fallback.
   - Trợ lý học tập sinh viên `/student/ai-assistant` kèm cơ chế RAG tra cứu tài liệu học phần.
   - Trợ lý giảng viên `/teacher/ai-assistant` hỗ trợ sinh câu hỏi trắc nghiệm, tạo ma trận đề thi.
4. **Phase 4: Adaptive Learning & Smart Study**
   - Lộ trình học cá nhân hóa `/student/learning-path`.
   - Không gian học thông minh `/student/smart-study` (Flashcards, Ghi chú, Spaced Repetition).
5. **Phase 5: Smart Assessment & Online Coding Sandbox**
   - Ngân hàng câu hỏi thông minh `/teacher/question-bank`.
   - Đánh giá theo tiến trình (Process-based) và Rubrics.
   - Thử nghiệm giao diện lập trình trực tuyến Online Coding Assessment cách ly.
6. **Phase 6: Competency Map, Digital Portfolio & Digital Badges**
   - Bản đồ năng lực sinh viên `/student/competencies`.
   - Hồ sơ học tập số `/student/portfolio` và Hệ thống huy hiệu số `/student/badges`.
7. **Phase 7: Mở rộng Hệ sinh thái, Tích hợp & Nghiệm thu toàn diện**
   - Lịch học thông minh `/calendar`, Diễn đàn thảo luận `/courses/<id>/discussions`.
   - Tối ưu Responsive, kiểm thử hồi quy toàn bộ hệ thống và báo cáo nghiệm thu hoàn chỉnh.

---

## 9. MA TRẬN RỦI RO VÀ PHƯƠNG ÁN KHẮC PHỤC

| Nguy cơ / Rủi ro | Mức độ | Phương án phòng ngừa & Xử lý |
| :--- | :---: | :--- |
| **Xung đột hoặc mất dữ liệu cũ** | Nghiêm trọng | Không dùng DROP TABLE hoặc ALTER phá hủy. Sử dụng migration thêm cột/bảng mới với giá trị mặc định. |
| **Dịch vụ AI không phản hồi / hết quota** | Trung bình | AI Gateway có cơ chế Timeout và Fallback: Nếu AI lỗi, hiển thị thông báo rõ ràng; **toàn bộ chức năng LMS cốt lõi vẫn hoạt động 100% bình thường**. |
| **Rò rỉ API Key AI ra bên ngoài** | Nghiêm trọng | Lưu trữ hoàn toàn trong file môi trường `.env` phía backend, không render hoặc truyền về phía frontend/client. |
| **AI bịa đặt câu trả lời (Hallucination)** | Trung bình | Trong chế độ hỏi đáp RAG, bắt buộc kiểm tra tài liệu thuộc phạm vi lớp học phần; trích dẫn rõ nguồn trang/tệp. Nếu không thấy tài liệu thì AI nói rõ không tìm thấy. |
| **Truy cập chéo dữ liệu giữa các lớp** | Nghiêm trọng | Tầng kiểm soát quyền ở Backend luôn kiểm tra `user_id` và `course_id` trong bảng `enrollments` hoặc `courses` trước khi trả dữ liệu tài liệu/hội thoại AI. |

---

## 10. KẾT LUẬN & ĐIỀU KIỆN CHUYỂN GIAI ĐOẠN

Giai đoạn **PROMPT 0 – Phân tích toàn bộ LMS hiện tại** đã hoàn thành toàn diện:
- Mã nguồn và cơ sở dữ liệu hiện tại được **bảo toàn nguyên vẹn 100%**, không có bất kỳ dòng code hay bản ghi CSDL nào bị sửa đổi.
- Báo cáo phân tích và baseline kỹ thuật đã được biên soạn và lưu trữ tại `documentation/PHASE0_SYSTEM_ANALYSIS_BASELINE.md`.
- Hệ thống đã sẵn sàng để bước sang **PROMPT 1 – Xây dựng nền tảng dữ liệu, bảo mật và API** khi có yêu cầu tiếp theo từ Quản trị viên.
