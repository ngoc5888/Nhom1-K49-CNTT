# DANH SÁCH TÀI KHOẢN SINH VIÊN LỚP K49 CNTT

> Hệ thống LMS thông minh đã khởi tạo thành công tài khoản cho toàn bộ **34 sinh viên** lớp **K49 CNTT** (Khoa Công nghệ thông tin - Ngành Kỹ thuật phần mềm).
> Mỗi tài khoản có thể đăng nhập bằng **Địa chỉ Email** HOẶC **Mã sinh viên** với mật khẩu mặc định là `123456`.

---

## 1. Thông Tin Đăng Nhập Chung

- **Địa chỉ truy cập (URL):** `http://localhost:5000/login`
- **Tên đăng nhập:** Nhập **Email** (ví dụ: `dovietanh@hpu2.edu.vn`) HOẶC **Mã SV** (ví dụ: `K49CNTT01`)
- **Mật khẩu mặc định:** `123456`
- **Lớp học phần ghi danh sẵn:**
  1. `LHP_WEB201_01` - Lập trình Web - Nhóm 01 (GV: Trần Thị Mai)
  2. `LHP_CSDL101_01` - Cơ sở dữ liệu - Nhóm 01 (GV: Trần Thị Mai)

---

## 2. Bảng Danh Sách 34 Tài Khoản Sinh Viên Lớp K49 CNTT

| STT | Mã SV | Họ và tên | Lớp | Email đăng nhập | Mật khẩu mặc định | Trạng thái |
|:---:|:---:|:---|:---:|:---|:---:|:---:|
| 1 | `K49CNTT01` | Đỗ Việt Anh | K49 CNTT | `dovietanh@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 2 | `K49CNTT02` | Nguyễn Hà Anh | K49 CNTT | `nguyenhaanh@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 3 | `K49CNTT03` | Phạm Văn Cường | K49 CNTT | `phamvancuong@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 4 | `K49CNTT04` | Nguyễn Thị Phương Diễm | K49 CNTT | `nguyenthiphuongdiem@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 5 | `K49CNTT05` | Nguyễn Thùy Dung | K49 CNTT | `nguyenthuydung@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 6 | `K49CNTT06` | Nguyễn Thành Đạt | K49 CNTT | `nguyenthanhdat@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 7 | `K49CNTT07` | Trần Anh Đức | K49 CNTT | `trananhduc@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 8 | `K49CNTT08` | Bùi Minh Đức | K49 CNTT | `buiminhduc@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 9 | `K49CNTT09` | Trần Đức Giang | K49 CNTT | `tranducgiang@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 10 | `K49CNTT10` | Nguyễn Thu Hà | K49 CNTT | `nguyenthuha@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 11 | `K49CNTT11` | Nguyễn Hồng Hà | K49 CNTT | `nguyenhongha@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 12 | `K49CNTT12` | Khuất Duy Hải | K49 CNTT | `khuatduyhai@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 13 | `K49CNTT13` | Đỗ Quang Minh Hiếu | K49 CNTT | `doquangminhhieu@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 14 | `K49CNTT14` | Nguyễn Huy Hoàng | K49 CNTT | `nguyenhuyhoang@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 15 | `K49CNTT15` | Ngô Việt Hoàng | K49 CNTT | `ngoviethoang@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 16 | `K49CNTT16` | Hoàng Mạnh Hùng | K49 CNTT | `hoangmanhhung@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 17 | `K49CNTT17` | Đặng Thanh Loan | K49 CNTT | `dangthanhloan@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 18 | `K49CNTT18` | Khammany Peopo Mai Ngọc | K49 CNTT | `khammanypeopomaingoc@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 19 | `K49CNTT19` | Hồ Duy Minh | K49 CNTT | `hoduyminh@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 20 | `K49CNTT20` | Lê Ngọc Minh | K49 CNTT | `lengocminh@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 21 | `K49CNTT21` | Nguyễn Bảo Ngọc | K49 CNTT | `nguyenbaongoc@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 22 | `K49CNTT22` | Nguyễn Trang Nhung | K49 CNTT | `nguyentrangnhung@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 23 | `K49CNTT23` | Phatsouna Phat | K49 CNTT | `phatsounaphat@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 24 | `K49CNTT24` | Phosi Doungchai Phong | K49 CNTT | `phosidoungchaiphong@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 25 | `K49CNTT25` | Hà Duy Quang | K49 CNTT | `haduyquang@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 26 | `K49CNTT26` | Đinh Xuân Quang | K49 CNTT | `dinhxuanquang@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 27 | `K49CNTT27` | Phạm Quyết | K49 CNTT | `phamquyet@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 28 | `K49CNTT28` | Vũ Đức Thành | K49 CNTT | `vuducthanh@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 29 | `K49CNTT29` | Huechi Thor | K49 CNTT | `huechithor@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 30 | `K49CNTT30` | Trương Văn Tiến | K49 CNTT | `truongvantien@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 31 | `K49CNTT31` | Hoàng Anh Tuấn | K49 CNTT | `hoanganhtuan@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 32 | `K49CNTT32` | Visouda Vy | K49 CNTT | `visoudavy@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 33 | `K49CNTT33` | Nguyễn Thị Thu Yên | K49 CNTT | `nguyenthithuyen@hpu2.edu.vn` | `123456` | Đã kích hoạt |
| 34 | `K49CNTT34` | Lê Xuân Mạnh | K49 CNTT | `lexuanmanh@hpu2.edu.vn` | `123456` | Đã kích hoạt |
