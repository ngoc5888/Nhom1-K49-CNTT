# BÁO CÁO KẾT QUẢ GIAI ĐOẠN 5: SMART ASSESSMENT VÀ ONLINE CODING ASSESSMENT

**Dự án:** Nâng cấp hệ thống LMS thành Hệ sinh thái Học tập Thông minh (AI-Powered Smart Learning Ecosystem)  
**Thời gian thực hiện:** 2026-11-11  
**Giai đoạn:** Giai đoạn 5 - Smart Assessment & Online Coding Assessment (Prompt 5)  
**Trạng thái:** HOÀN THÀNH 100% (Passed All Tests)

---

## 1. MỤC TIÊU GIAI ĐOẠN 5

Giai đoạn 5 nâng cấp toàn diện hệ thống kiểm tra, thi cử và đánh giá từ mô hình truyền thống sang **Hệ thống đánh giá thông minh đa chiều (Smart Assessment)**:
1. **Ngân hàng câu hỏi thông minh (Intelligent Question Bank):** Quản lý câu hỏi tách bạch khỏi đề thi, phân loại theo môn học, chương mục, độ khó (EASY, MEDIUM, HARD), gắn thẻ kiến thức và kỹ năng.
2. **Quy trình sinh câu hỏi bằng AI có phê duyệt (AI Question Generation Workflow):** Hỗ trợ giảng viên dùng AI tạo nhanh câu hỏi trắc nghiệm; giảng viên toàn quyền chỉnh sửa và duyệt trước khi lưu vào ngân hàng. Tuyệt đối không tự ý đưa vào đề thi chính thức nếu chưa được duyệt.
3. **Ma trận đề thi chuẩn hóa (Assessment Matrix):** Phân bổ câu hỏi theo chuẩn đầu ra và mức độ tư duy Bloom. Hỗ trợ 1-click tự động lắp ghép đề thi chính thức từ ngân hàng câu hỏi.
4. **Luyện thi thích ứng (Adaptive Practice Testing - CAT):** Thuật toán tự động tăng/giảm độ khó câu hỏi tiếp theo dựa trên độ chính xác của câu trả lời trước đó, tính toán mức độ thông thạo (Mastery Score) và xuất báo cáo chỉ dẫn học tập từ AI.
5. **Đánh giá theo tiến trình (Process-based Assessment):** Lưu vết toàn bộ lịch sử các phiên bản nộp bài (v1, v2...), cho phép giảng viên chấm điểm và nhận xét theo từng giai đoạn/milestone của đồ án.
6. **Đánh giá theo tiêu chí Rubric (Rubric Assessment):** Thiết lập các tiêu chí đánh giá chuẩn mực kèm trọng số (weight %); hệ thống tự động tính điểm bình quân gia quyền chính xác trên thang điểm 10.
7. **Nền tảng kiểm thử lập trình trực tuyến (Online Coding Assessment & Sandbox):** Trình biên soạn và thực thi mã nguồn Python 3 trực tuyến với bộ kiểm thử tự động (công khai và ẩn), kiểm soát thời gian chạy và cô lập an toàn tuyệt đối bằng cơ chế bảo mật Sandbox.

---

## 2. NÂNG CẤP CƠ SỞ DỮ LIỆU (DATABASE SCHEMA)

Cơ sở dữ liệu SQLite hiện hành (`lms.db`) được mở rộng an toàn bằng lệnh `CREATE TABLE IF NOT EXISTS`, bảo toàn 100% dữ liệu gốc:

### Các bảng mới được bổ sung (12 bảng mới, tổng cộng 46 bảng trong hệ thống):
1. **`question_bank`**: Ngân hàng câu hỏi trung tâm (`id`, `course_id`, `chapter_num`, `topic_id`, `question_text`, `options_json`, `correct_answers_json`, `difficulty`, `points`, `tags_json`, `skills_json`, `explanation`, `usage_count`, `discrimination_index`, `created_by`).
2. **`assessment_matrices`**: Ma trận đề thi chuẩn hóa (`id`, `course_id`, `title`, `description`, `total_questions`, `total_points`, `created_by`).
3. **`matrix_items`**: Chi tiết phân bổ câu hỏi theo chương, độ khó và kỹ năng trong ma trận.
4. **`adaptive_test_sessions`**: Phiên luyện thi thích ứng của sinh viên (`id`, `student_id`, `course_id`, `current_difficulty`, `total_questions`, `answered_count`, `correct_count`, `final_mastery_pct`, `status`, `recommendations_json`).
5. **`adaptive_test_answers`**: Chi tiết từng câu trả lời trong phiên luyện thi thích ứng kèm thời gian phản hồi.
6. **`process_submissions_history`**: Lịch sử phiên bản bài nộp (v1, v2...), điểm giai đoạn và nhận xét của giảng viên.
7. **`rubrics`**: Bộ tiêu chí đánh giá chuẩn mực gán theo bài tập (`id`, `assignment_id`, `title`, `description`, `created_by`).
8. **`rubric_criteria`**: Danh mục các tiêu chí đánh giá và trọng số phần trăm (`weight_pct`, `max_points`, `levels_json`).
9. **`rubric_evaluations`**: Chi tiết điểm số từng tiêu chí do giảng viên đánh giá cho bài nộp.
10. **`coding_problems`**: Bài tập lập trình trực tuyến (`id`, `course_id`, `title`, `description`, `difficulty`, `language`, `starter_code`, `time_limit_seconds`, `memory_limit_mb`).
11. **`coding_test_cases`**: Bộ kiểm thử đầu vào/đầu ra (hỗ trợ cờ `is_hidden` cho test case bí mật).
12. **`coding_submissions`**: Lịch sử nộp mã nguồn, trạng thái chấm (`PASSED`, `FAILED`, `SECURITY_ERROR`, `TIME_LIMIT_EXCEEDED`), thời gian thực thi (ms) và điểm tự động.

### Kiểm tra bảo toàn dữ liệu gốc:
- `users`: 73 tài khoản (nguyên vẹn)
- `courses`: 42 lớp học phần (nguyên vẹn)
- `enrollments`: 405 lượt ghi danh (nguyên vẹn)
- `grades`: 248 điểm học phần (nguyên vẹn)
- `PRAGMA integrity_check`: **ok**

---

## 3. CÁC DỊCH VỤ VÀ MODULE XỬ LÝ (BACKEND SERVICES)

### 3.1. Dịch vụ Đánh giá thông minh (`app/services/smart_assessment_service.py`)
- **Quản lý Ngân hàng câu hỏi:** Lọc đa chiều theo môn học, chương mục, độ khó, thẻ kỹ năng; tự động khởi tạo câu hỏi mẫu chuẩn hóa nếu ngân hàng của môn còn trống.
- **AI Question Generation Workflow:** Tích hợp cổng Gemini / AI Gateway tạo các câu hỏi dạng ứng viên (unapproved candidates). Giảng viên duyệt trực tiếp trên giao diện để lưu vào ngân hàng câu hỏi.
- **Ma trận đề thi & Lắp ghép tự động:** Định nghĩa số lượng câu theo từng chương và độ khó; tự động quét câu hỏi từ ngân hàng để sinh đề thi hoàn chỉnh trong bảng `exams` và `questions`.
- **Luyện thi thích ứng (CAT):** Bắt đầu từ mức `MEDIUM`. Nếu trả lời đúng -> nâng lên `HARD`. Nếu trả lời sai -> hạ xuống `EASY`. Tính điểm thông thạo và xuất khuyến nghị học tập AI.
- **Process-based Assessment:** Theo dõi tiến trình qua các phiên bản nộp bài (v1, v2...).
- **Rubric Assessment:** Tính điểm chính xác theo công thức bình quân gia quyền:
  $$\text{Điểm tổng} = \sum_{i=1}^n \left( \frac{\text{Điểm đạt}_i}{\text{Điểm tối đa}_i} \times \frac{\text{Trọng số}_i}{10} \right)$$

### 3.2. Nền tảng Lập trình trực tuyến & Sandbox Bảo mật (`app/services/online_coding_service.py`)
- **Quét bảo mật tĩnh (Static Security Scanning):** Chặn đứng các mã nguồn độc hại hoặc cố tình truy xuất trái phép máy chủ. Danh mục cấm triệt để: `import os`, `import sys`, `import subprocess`, `import shutil`, `import socket`, `import requests`, `open()`, `eval()`, `exec()`.
- **Sandbox thực thi tiến trình con cô lập (Isolated Subprocess):** Thực thi với cờ `python -I` (isolated mode), kiểm soát chặt chẽ thời gian chạy (`timeout` mặc định 2.0s) chống treo máy chủ hoặc vòng lặp vô hạn.
- **Chấm điểm tự động:** Tự động nạp dữ liệu vào luồng `stdin`, so sánh `stdout` với `expected_output` của từng test case và tính điểm quy chuẩn thang 10.

---

## 4. GIAO DIỆN NGƯỜI DÙNG VÀ ĐIỀU HƯỚNG

1. **Giảng viên:**
   - Ngân hàng câu hỏi: `/teacher/question-bank` ([`teacher/question_bank.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/teacher/question_bank.html))
   - Ma trận đề thi: `/teacher/assessment-matrices` ([`teacher/assessment_matrices.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/teacher/assessment_matrices.html))
   - Quản lý bài tập lập trình: `/teacher/courses/<id>/coding-assessments` ([`teacher/coding_assessments.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/teacher/coding_assessments.html))
   - Cấu hình Rubric: `/teacher/assignments/<id>/rubric` ([`teacher/rubric_config.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/teacher/rubric_config.html))
2. **Sinh viên:**
   - Luyện thi thích ứng: `/student/practice/adaptive` ([`student/adaptive_practice.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/student/adaptive_practice.html))
   - Báo cáo kết quả thích ứng: `/student/practice/adaptive/report/<id>` ([`student/adaptive_practice_report.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/student/adaptive_practice_report.html))
   - Danh sách bài tập code: `/student/coding-assessments` ([`student/coding_list.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/student/coding_list.html))
   - Không gian viết code Web IDE: `/student/coding-assessments/<id>` ([`student/coding_workspace.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/student/coding_workspace.html))
   - Lịch sử tiến trình nộp bài: `/student/assignments/<id>/history` ([`student/assignment_history.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/student/assignment_history.html))
3. **Cập nhật Sidebar Navigation:** Đã bổ sung đầy đủ các menu trong [`base.html`](file:///F:/THCN_HTQLHT/university-lms/app/templates/base.html).

---

## 5. KẾT QUẢ KIỂM THỬ TOÀN DIỆN (100% PASS)

```
==================================================
RUNNING COMPREHENSIVE PHASE 5 VERIFICATION SUITE
==================================================

[TEST 1] Database Tables & Old Data Preservation:
Total Tables in DB: 46/46
  -> Old data 100% preserved (Users: 73, Courses: 42, Enrollments: 405, Grades: 248): PASS

[TEST 2] Intelligent Question Bank & Teacher AI Approval Workflow:
  -> Question Bank seeded: Total = 6 (Easy: 1, Med: 3, Hard: 2): PASS
  -> AI Question Generation created unapproved candidates: PASS
  -> Teacher approved and saved AI question into Question Bank: PASS

[TEST 3] Assessment Matrix & Automatic Exam Assembly:
  -> Generated Exam #3 with 4 questions assembled from Matrix: PASS

[TEST 4] Adaptive Practice Testing (Computerized Adaptive Testing):
  -> Step 1 Correct: Difficulty dynamically escalated to HARD: PASS
  -> Step 2 Incorrect: Difficulty dynamically de-escalated to MEDIUM: PASS
  -> Adaptive Practice Finished: Final Mastery = 66.7%, Advice = Khá tốt! Bạn vững các câu hỏi EASY và ME...: PASS
  -> Adaptive Practice Detailed Report verified: PASS

[TEST 5] Process-based & Rubric Assessment:
  -> Process-based Assessment: 2 submission milestones tracked (v1, v2): PASS
  -> Rubric Assessment: Weighted total calculated accurately: 9.1/10: PASS

[TEST 6] Online Coding Assessment & Sandbox Security Isolation:
  -> Seeded 2 coding problems for course 1: PASS
  -> Sandbox Security Test 1 (import os blocked): PASS
  -> Sandbox Security Test 2 (file access blocked): PASS
  -> Sandbox Security Test 3 (Timeout protection at 1.0s): PASS
  -> Valid Code Submission: Passed 4/4 test cases, Score: 10.0/10: PASS

[TEST 7] HTTP Endpoints Verification:
  -> GET /teacher/question-bank: 200 OK
  -> GET /teacher/assessment-matrices: 200 OK
  -> GET /teacher/courses/1/coding-assessments: 200 OK
  -> GET /student/practice/adaptive: 200 OK
  -> GET /student/coding-assessments: 200 OK
  -> GET /student/coding-assessments/2: 200 OK

[TEST 8] Core System Non-regression Check:
  -> Anonymous core routes intact: PASS

==================================================
ALL PHASE 5 VERIFICATION TESTS PASSED SUCCESSFULLY!
==================================================
```

- **Baseline System Check (`verify_system.py`):** **8/8 bài test đạt 100% PASS**.
- **Phase 4 Regression (`test_phase4.py`):** **100% PASS**.

---

## 6. KẾT LUẬN

Giai đoạn 5 đã hoàn thành xuất sắc toàn bộ 7 yêu cầu nghiệp vụ khắt khe:
- Hệ thống đánh giá đã chuyển mình thành công cụ thông minh, đa chiều, khách quan và minh bạch.
- Sinh viên có môi trường luyện tập thích ứng CAT và nền tảng thực hành lập trình trực tuyến an toàn.
- Giảng viên có công cụ quản lý ngân hàng câu hỏi, ma trận đề chuẩn hóa và chấm điểm Rubric tự động.
- Hệ thống đã sẵn sàng bước vào **Giai đoạn 6 (Competency Map, Digital Portfolio và Digital Badges - Prompt 6)**.
