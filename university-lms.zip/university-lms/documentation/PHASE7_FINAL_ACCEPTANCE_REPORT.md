# BÁO CÁO NGHIỆM THU TỔNG THỂ DỰ ÁN (FINAL SYSTEM ACCEPTANCE & HANDOVER REPORT)
# DỰ ÁN: NÂNG CẤP HỆ THỐNG LMS THÀNH HỆ SINH THÁI HỌC TẬP THÔNG MINH (AI-POWERED SMART LEARNING ECOSYSTEM)

**Đơn vị thực hiện:** Antigravity AI Engineering Team  
**Khách hàng:** Ban Quản trị Hệ thống LMS Trường Đại học  
**Thời gian hoàn thành:** 2026-11-11  
**Trạng thái nghiệm thu:** ĐẠT 100% TIÊU CHÍ (Accepted & Verified)

---

## 1. TỔNG QUAN HỆ THỐNG TRƯỚC NÂNG CẤP (BASELINE SYSTEM)

Trước khi thực hiện nâng cấp (Giai đoạn 0), hệ thống LMS là một ứng dụng Flask nguyên khối truyền thống:
- **Cơ sở dữ liệu:** SQLite gồm 21 bảng quản lý tài khoản, đào tạo cơ bản (Khoa, Ngành, Môn học, Lớp sinh hoạt, Lớp học phần), tài liệu, bài tập, đề thi và điểm số.
- **Dữ liệu đào tạo gốc:** 73 tài khoản người dùng (Admin, 20 Teacher, 52 Student), 10 Khoa, 10 Ngành, 20 Môn học, 40 Lớp sinh hoạt, 42 Lớp học phần, 405 lượt ghi danh, 248 điểm học phần.
- **Hạn chế chính:** 
  - Thiếu hệ thống phân tích học tập (Learning Analytics) và dự báo nguy cơ sinh viên rớt môn.
  - Thiếu trợ lý AI tương tác và tra cứu tài liệu thông minh (RAG).
  - Lộ trình học tập cứng nhắc, không có khả năng thích ứng theo năng lực cá nhân.
  - Kiểm tra thi cử đơn giản, không có đánh giá theo tiến trình (Process-based), Rubric hay kiểm thử lập trình trực tuyến (Coding Sandbox).
  - Thiếu hồ sơ số (Portfolio) và huy hiệu số có thể kiểm chứng (Verifiable Badges).
  - Chưa có không gian cộng tác nhóm (Group Workspace) hay lịch học thông minh (Smart Calendar).

---

## 2. CÁC MODULE ĐÃ PHÁT TRIỂN (PHASE 1 - PHASE 7)

Dự án đã hoàn thành toàn diện 7 giai đoạn nâng cấp theo đúng lộ trình:

| Giai đoạn | Tên Module | Chức năng cốt lõi đã triển khai |
|:---:|:---|:---|
| **Phase 1** | Foundation, Security & Shared API | Audit logs, nhật ký học tập (Learning Activities), lịch sử đăng nhập, quản lý cấu hình hệ thống động, RESTful API phân quyền RBAC. |
| **Phase 2** | Learning Analytics & Predictive Early Warning | Thuật toán chấm điểm nguy cơ học tập (Risk Score 0-100), phân loại 4 cấp độ cảnh báo (An toàn, Thấp, Trung bình, Nguy cơ cao), can thiệp học thuật (Academic Interventions). |
| **Phase 3** | AI Services, RAG & Usage Governance | Cổng AI Gateway (Gemini/Mock fallback), RAG trích xuất ngữ cảnh tài liệu học phần, Trợ lý AI Sinh viên & Giảng viên, kiểm soát hạn mức Token hàng ngày. |
| **Phase 4** | Adaptive Learning & Smart Study Space | Đồ thị chủ đề môn học (Topic Graph), phát hiện điểm nghẽn kiến thức (Knowledge Bottlenecks), thẻ ghi nhớ thông minh Spaced Repetition (SM-2), đồng hồ Pomodoro tập trung. |
| **Phase 5** | Smart Assessment & Online Coding Sandbox | Ngân hàng câu hỏi thông minh, quy trình duyệt câu hỏi AI, ma trận đề thi chuẩn hóa, luyện thi thích ứng (CAT), đánh giá tiến trình (Milestones), đánh giá Rubric, Sandbox lập trình Python 3 bảo mật. |
| **Phase 6** | Competency Map, Digital Portfolio & Badges | Khung chuẩn 12 năng lực (CNTT & kỹ năng mềm), Biểu đồ Radar động, xác thực năng lực kèm minh chứng, Digital Portfolio kèm link công khai cho nhà tuyển dụng, 6 loại huy hiệu số Open Badges. |
| **Phase 7** | Smart Calendar, Discussion Forum, Group Workspace & Interop | Lịch học thông minh tổng hợp (tích hợp iCal .ics), diễn đàn thảo luận môn học (hỗ trợ câu trả lời hữu ích), không gian nhóm & Kanban phân công nhiệm vụ, chuẩn xAPI, QTI 2.1 XML, Open Badges JSON-LD. |

---

## 3. CÁC CHỨC NĂNG ĐƯỢC GIỮ NGUYÊN (PRESERVED FUNCTIONALITY)

Tuân thủ nghiêm ngặt **Quy tắc bắt buộc số 1**, toàn bộ các chức năng và dữ liệu LMS hiện hành được giữ nguyên vẹn 100%:
- Đăng nhập, đăng xuất, đổi mật khẩu và phân quyền 3 vai trò: Admin, Teacher, Student.
- Quản lý cơ cấu đào tạo: Khoa, Ngành, Môn học, Lớp sinh hoạt, Lớp học phần, Năm học, Học kỳ.
- Quản lý tài liệu môn học, bài tập nộp file, đề thi trắc nghiệm cũ, sổ điểm lớp học phần.
- Chế độ bảo trì hệ thống (Maintenance Mode) và khóa hệ thống (System Lock).
- Toàn bộ 73 tài khoản người dùng, 42 lớp học phần, 405 đăng ký và 248 điểm số không bị thay đổi hoặc mất mát.

---

## 4. CÁC CHỨC NĂNG ĐƯỢC MỞ RỘNG (ENHANCED CAPABILITIES)

- **Admin:** Bổ sung Learning Analytics toàn trường, Quản lý hạn mức AI, Quản lý Khung Chuẩn Năng lực, Quản lý Huy hiệu số, Lịch toàn trường, Báo cáo kiểm định xAPI/QTI.
- **Teacher:** Bổ sung Trợ lý AI Giảng dạy, Soạn câu hỏi AI có phê duyệt, Quản lý Ma trận đề thi, Chấm bài theo Rubric và Tiến trình nộp bài, Bài tập lập trình tự động chấm điểm, Xác thực chuẩn đầu ra cho sinh viên, Ghim thông báo diễn đàn.
- **Student:** Bổ sung Trợ lý gia sư AI, Lộ trình học cá nhân hóa, Luyện thi thích ứng thông minh (CAT), Trình biên soạn lập trình Sandbox an toàn, Góc tự học Flashcard & Pomodoro, Bản đồ Năng lực Radar, Hồ sơ số tuyển dụng và Huy hiệu số Open Badges.

---

## 5. CÔNG NGHỆ VÀ THƯ VIỆN SỬ DỤNG

- **Backend:** Python 3.13, Flask 2.3+ (Modular Blueprints: `auth_bp`, `admin_bp`, `teacher_bp`, `student_bp`, `common_bp`, `api_bp`).
- **Database:** SQLite 3 với cấu trúc 60 bảng quan hệ, `PRAGMA foreign_keys = ON`, `PRAGMA integrity_check = ok`.
- **Frontend:** Jinja2 Templates, HTML5 ngữ nghĩa, Tailwind CSS (Dark/Light Modern Palette), FontAwesome 6 Pro Icons, Chart.js (Radar Charts, Bar/Line Analytics, Doughnut Charts).
- **Trí tuệ nhân tạo (AI):** Cổng kết nối API Gemini (hỗ trợ Google Gemini 1.5 Flash), kiến trúc RAG vector chunking, cơ chế Offline Rule-based Heuristic Fallback khi không có mạng hoặc chưa nhập API Key.
- **Sandbox Lập trình:** Python Isolated Subprocess Execution với AST AST Parser lọc mã độc hại (chặn `os`, `sys`, `subprocess`, `open`, `eval`), giới hạn thời gian (Timeout 2.0s) và bộ nhớ (128MB).
- **Chuẩn hóa Quốc tế:** iCalendar (RFC 5545 .ics), IMS QTI 2.1 XML, W3C Verifiable Credentials / Open Badges 2.0 JSON-LD, ADL xAPI (Tin Can 1.0.3).

---

## 6. KIẾN TRÚC SAU NÂNG CẤP (UPGRADED ARCHITECTURE)

Hệ thống được tổ chức theo kiến trúc **Modular Monolith kết hợp AI Services độc lập**:

```
university-lms/
├── app/
│   ├── routes/                     # Tách bạch Controller theo phân quyền
│   │   ├── auth_routes.py          # Xác thực & Phiên làm việc
│   │   ├── admin_routes.py         # Quản trị & Báo cáo cấp cao
│   │   ├── teacher_routes.py       # Quản lý lớp, đề thi, chấm điểm, CĐR
│   │   ├── student_routes.py       # Lộ trình học, bài tập, coding, portfolio
│   │   ├── common_routes.py        # Calendar, Diễn đàn, Nhóm, Portfolio công khai
│   │   └── api_routes.py           # Shared REST API & Audit logs
│   ├── services/                   # Business Logic độc lập
│   │   ├── activity_service.py     # Ghi nhận hành vi học tập
│   │   ├── adaptive_service.py     # Lộ trình thích ứng & Điểm nghẽn
│   │   ├── ai_gateway.py           # Quản lý gọi AI & Hạn mức Token
│   │   ├── ai_teacher_service.py   # AI hỗ trợ soạn giáo án & câu hỏi
│   │   ├── analytics_service.py    # Phân tích học tập đa chiều
│   │   ├── audit_service.py        # Nhật ký kiểm toán bảo mật
│   │   ├── config_service.py       # Cấu hình hệ thống runtime
│   │   ├── ecosystem_service.py    # Calendar, Forum, Groups, Interop (xAPI, QTI)
│   │   ├── online_coding_service.py# Sandbox chấm mã nguồn tự động
│   │   ├── portfolio_competency_service.py # CĐR, Radar Chart, Portfolio, Badges
│   │   ├── predictive_service.py   # Dự báo nguy cơ rớt môn (Risk Scoring)
│   │   ├── rag_service.py          # Chunking & Semantic Search tài liệu
│   │   ├── smart_assessment_service.py # Ngân hàng câu hỏi, Rubric, CAT
│   │   └── spaced_repetition_service.py# Flashcard SM-2 & Pomodoro timer
│   ├── templates/                  # Giao diện người dùng đồng bộ
│   │   ├── admin/                  # Dashboard, Users, Analytics, Competencies, Badges
│   │   ├── teacher/                # Question bank, Matrices, Coding, Verification
│   │   ├── student/                # Adaptive practice, Workspace, Portfolio, Badges
│   │   ├── calendar/               # Smart Calendar tương tác
│   │   ├── discussion/             # Diễn đàn môn học & phản hồi
│   │   ├── group/                  # Không gian làm việc nhóm & Kanban
│   │   └── common/                 # Public portfolio, Maintenance, Notifications
│   ├── static/                     # CSS, JS, Avatars, Badges
│   ├── auth.py                     # Middleware RBAC & Decorators
│   └── database.py                 # SQLite Data Layer (60 bảng)
├── documentation/                  # Hồ sơ báo cáo chi tiết từng giai đoạn
└── lms.db                          # Cơ sở dữ liệu SQLite toàn vẹn
```

---

## 7. CƠ SỞ DỮ LIỆU VÀ QUÁ TRÌNH MIGRATION

Toàn bộ quá trình mở rộng cơ sở dữ liệu được thực hiện an toàn theo nguyên tắc:
1. Tạo điểm khôi phục (Backup) trước mỗi giai đoạn.
2. Sử dụng mệnh đề `CREATE TABLE IF NOT EXISTS` và `INSERT OR IGNORE`.
3. Tuyệt đối không chạy lệnh `DROP TABLE`, `DROP DATABASE` hoặc `TRUNCATE`.
4. Thiết lập đầy đủ khóa chính, khóa ngoại, ràng buộc toàn vẹn `ON DELETE CASCADE / SET NULL`.

### Danh sách 60 bảng cơ sở dữ liệu hoàn chỉnh:
- **Core LMS (21 bảng):** `users`, `departments`, `majors`, `subjects`, `student_classes`, `students`, `teachers`, `academic_years`, `semesters`, `courses`, `enrollments`, `materials`, `assignments`, `submissions`, `exams`, `questions`, `exam_results`, `grades`, `notifications`, `class_announcements`, `login_history`.
- **Phase 1 Foundation (3 bảng):** `system_settings`, `audit_logs`, `learning_activities`.
- **Phase 2 Analytics (1 bảng):** `student_interventions`.
- **Phase 3 AI & RAG (4 bảng):** `ai_conversations`, `ai_messages`, `ai_document_chunks`, `ai_usage_logs`.
- **Phase 4 Adaptive & Study (5 bảng):** `course_topics`, `student_topic_progress`, `study_notes`, `study_flashcards`, `study_sessions`.
- **Phase 5 Smart Assessment (12 bảng):** `question_bank`, `assessment_matrices`, `matrix_items`, `adaptive_test_sessions`, `adaptive_test_answers`, `process_submissions_history`, `rubrics`, `rubric_criteria`, `rubric_evaluations`, `coding_problems`, `coding_test_cases`, `coding_submissions`.
- **Phase 6 Competency & Portfolio (7 bảng):** `competencies`, `competency_mappings`, `student_competencies`, `student_portfolios`, `portfolio_items`, `digital_badges`, `student_badges`.
- **Phase 7 Ecosystem (7 bảng):** `calendar_events`, `course_discussions`, `discussion_comments`, `course_groups`, `group_members`, `group_tasks`, `group_resources`.

---

## 8. DANH MỤC API MỚI BỔ SUNG

Hệ thống cung cấp hơn 30 API RESTful chuẩn JSON phục vụ kết nối:
- **Audit & Cấu hình:** `/api/v1/admin/audit-logs`, `/api/v1/admin/system-config`.
- **Learning Analytics:** `/admin/analytics/export`, `/api/v1/analytics/course/<id>`.
- **Lập trình trực tuyến:** `/student/coding-assessments/<id>/run` (thực thi mã sandbox).
- **Luyện thi thích ứng:** `/student/practice/adaptive/answer` (chấm thích ứng CAT & nâng hạ độ khó).
- **Flashcard & Pomodoro:** `/student/study/flashcard/<id>/review`, `/student/study/pomodoro/save`.
- **Xác thực Năng lực:** `/teacher/competencies/verify`.
- **Hồ sơ số:** `/student/portfolio/update-profile`, `/student/portfolio/items/add`, `/portfolio/<id>`.
- **Lịch học thông minh:** `/api/calendar/events`, `/calendar/export.ics`.
- **Diễn đàn:** `/courses/<id>/discussions/create`, `/discussions/<id>/comment`, `/discussions/<id>/upvote`.
- **Nhóm học tập:** `/groups/<id>/join`, `/groups/<id>/tasks/add`, `/groups/tasks/<id>/update-status`.
- **Interoperability Standards:** 
  - `/api/v1/interop/exams/<id>/qti.xml` (Xuất IMS QTI 2.1 XML).
  - `/api/v1/interop/badges/<id>.json` (Xuất W3C Open Badges 2.0 JSON-LD).
  - `/api/v1/interop/xapi/statements` (Ghi nhận phát biểu chuẩn xAPI).

---

## 9. CẤU HÌNH AI VÀ BIẾN MÔI TRƯỜNG

Hệ thống hỗ trợ cấu hình AI linh hoạt qua giao diện Quản trị (`/admin/ai-usage`) hoặc qua file môi trường `.env`:

```env
# AI Gateway Configuration
GEMINI_API_KEY=your_gemini_api_key_here
AI_API_ENABLED=1
AI_PROVIDER=gemini
AI_MODEL=gemini-1.5-flash
AI_TEMPERATURE=0.7
AI_DAILY_TOKEN_LIMIT=50000

# Sandbox Security Configuration
SANDBOX_TIME_LIMIT_SECONDS=2.0
SANDBOX_MEMORY_LIMIT_MB=128

# LMS System Configuration
FLASK_SECRET_KEY=your_secure_random_key_here
MAX_UPLOAD_SIZE_MB=16
```

---

## 10. HƯỚNG DẪN CHẠY VÀ VẬN HÀNH HỆ THỐNG

### Khởi động ứng dụng LMS:
1. Mở terminal tại thư mục dự án `university-lms`:
   ```powershell
   cd F:\THCN_HTQLHT\university-lms
   $env:PYTHONPATH=".;app"
   python run.py
   ```
2. Truy cập trình duyệt tại địa chỉ: `http://localhost:5000`

### Tài khoản đăng nhập thử nghiệm:
- **Quản trị viên (Admin):** `admin@example.com` / Mật khẩu: `admin123`
- **Giảng viên (Teacher):** `teacher@example.com` / Mật khẩu: `teacher123`
- **Sinh viên (Student):** `student@example.com` / Mật khẩu: `student123`

---

## 11. HƯỚNG DẪN CẤU HÌNH AI API

1. Đăng nhập bằng tài khoản Quản trị viên (`admin@example.com`).
2. Vào mục **Quản lý AI & Usage** từ menu bên trái (`/admin/ai-usage`).
3. Nhập **Gemini API Key**, chọn Model (`gemini-1.5-flash`), đặt giới hạn Token hàng ngày (mặc định 50,000).
4. Nhấn **Lưu cấu hình**.
5. Trong trường hợp không có mạng hoặc chưa nhập Key, hệ thống tự động kích hoạt **Offline Fallback Engine** để không gây gián đoạn trải nghiệm học tập của sinh viên.

---

## 12. TỔNG KẾT KẾT QUẢ KIỂM THỬ TOÀN DIỆN

Tất cả các bộ kiểm thử tự động của dự án đều đạt kết quả tuyệt đối:

| Bộ kiểm thử | Phạm vi xác minh | Số test | Kết quả |
|:---|:---|:---:|:---:|
| `app/verify_system.py` | Kiểm thử hệ thống gốc, thực thể đào tạo, phân quyền RBAC, chế độ bảo trì | 8/8 | **100% PASS** |
| `app/test_phase1.py` | Kiểm thử nền tảng dữ liệu, audit log, cài đặt hệ thống, API phân quyền | 7/7 | **100% PASS** |
| `app/test_phase2.py` | Kiểm thử mô hình chấm điểm rủi ro, cảnh báo sớm và can thiệp học thuật | 6/6 | **100% PASS** |
| `app/test_phase3.py` | Kiểm thử AI Gateway, chunking tài liệu RAG và hạn mức Token | 7/7 | **100% PASS** |
| `app/test_phase4.py` | Kiểm thử đồ thị kiến thức, phát hiện điểm nghẽn, Flashcard SM-2, Pomodoro | 6/6 | **100% PASS** |
| `app/test_phase5.py` | Kiểm thử Ngân hàng câu hỏi, CAT, Rubric, Milestones, Sandbox Python | 8/8 | **100% PASS** |
| `app/test_phase6.py` | Kiểm thử Chuẩn năng lực, Radar chart, Digital Portfolio, Open Badges | 9/9 | **100% PASS** |
| `app/test_phase7_acceptance.py` | **Nghiệm thu toàn diện:** Calendar, Forum, Groups, Interop xAPI/QTI, Fallback, 22 Endpoints | 8/8 | **100% PASS** |

---

## 13. NHỮNG LỖI ĐÃ PHÁT HIỆN VÀ KHẮC PHỤC TRONG DỰ ÁN

1. **Jinja2 Dot Notation Collisions:** Xử lý xung đột giữa phương thức `dict.items()` và khóa dữ liệu `['items']` trong templates Portfolio và Competencies bằng cách truy cập chỉ mục tường minh.
2. **Column Name Discrepancies:** Chuẩn hóa tên cột giữa các bảng cũ và mới (`c.schedule_info` thay vì `c.schedule`, `total_score` thay vì `score`, `student_code` thông qua liên kết `LEFT JOIN students`).
3. **Sandbox Security Leaks:** Bổ sung bộ lọc AST (Abstract Syntax Tree) ngăn chặn triệt để kỹ thuật dùng `getattr(__builtins__, 'eval')` hoặc `import os`.
4. **Idempotency trong Kiểm thử:** Thêm các câu lệnh dọn dẹp dữ liệu kiểm thử trùng lặp trước mỗi lượt chạy test tự động để bộ kiểm thử có thể thực thi nhiều lần độc lập mà không báo lỗi Unique Constraint.

---

## 14. TIỀM NĂNG MỞ RỘNG VÀ HƯỚNG PHÁT TRIỂN TIẾP THEO

1. **Tích hợp Hội nghị Truyền hình Trực tuyến:** Tích hợp Zoom / Google Meet / Jitsi Meet trực tiếp vào các buổi học trực tuyến và không gian thảo luận nhóm.
2. **Mô hình Khuyến nghị Học tập Nâng cao:** Ứng dụng mô hình Collaborative Filtering kết hợp đồ thị tri thức để gợi ý tài liệu học tập theo điểm mạnh/yếu của sinh viên.
3. **Blockchain Credential Anchoring:** Ghi nhận mã băm (hash) của Huy hiệu số và Bảng điểm năng lực lên mạng lưới Blockchain công khai để chống hoàn toàn việc làm giả bằng cấp.
4. **Ứng dụng Di động (Mobile App):** Đóng gói REST API hiện tại để kết nối với ứng dụng React Native / Flutter hỗ trợ thông báo đẩy (Push Notifications) khi có bài tập mới hoặc tin nhắn nhóm.

---

## 15. KẾT LUẬN NGHIỆM THU

Dự án nâng cấp hệ thống LMS trường đại học thành **Hệ sinh thái Học tập Thông minh (AI-Powered Smart Learning Ecosystem)** đã hoàn thành toàn diện, đáp ứng đầy đủ tất cả các yêu cầu kỹ thuật, thẩm mỹ giao diện, an toàn bảo mật và khả năng vận hành liên tục.

Hệ thống đã được đóng gói hoàn chỉnh, sẵn sàng bàn giao và đưa vào phục vụ công tác giảng dạy, học tập chính thức của Nhà trường.
