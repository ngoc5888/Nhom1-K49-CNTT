import os
import sys
import json
import sqlite3

# Ensure app path is in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from app import create_app
from app.database import get_db, query_db, execute_db
from app.services.portfolio_competency_service import (
    seed_default_competencies_if_empty,
    get_all_competencies,
    create_competency,
    get_competency_mappings,
    get_student_competency_profile,
    update_or_verify_student_competency,
    get_or_create_student_portfolio,
    update_portfolio_profile,
    add_portfolio_item,
    delete_portfolio_item,
    get_public_portfolio_by_user_id,
    seed_default_badges_if_empty,
    get_all_badges,
    award_badge_to_student,
    check_and_auto_award_badges,
    get_student_badges,
    has_student_badge
)

app = create_app()
client = app.test_client()

print("=" * 50)
print("RUNNING COMPREHENSIVE PHASE 6 VERIFICATION SUITE")
print("=" * 50)

# ----------------------------------------------------
# 1. Database Integrity & Table Count Verification
# ----------------------------------------------------
print("\n[TEST 1] Database Tables & Old Data Preservation:")
with app.app_context():
    tables = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
    table_names = [t['name'] for t in tables]
    total_tables = len(table_names)
    print(f"Total Tables in DB: {total_tables}/53")
    assert total_tables >= 53, f"Expected at least 53 tables, found {total_tables}"

    # Phase 6 required tables
    p6_tables = [
        'competencies', 'competency_mappings', 'student_competencies',
        'student_portfolios', 'portfolio_items', 'digital_badges', 'student_badges'
    ]
    for pt in p6_tables:
        assert pt in table_names, f"Missing Phase 6 table: {pt}"

    # PRAGMA integrity check
    integrity = query_db("PRAGMA integrity_check", one=True)
    assert integrity[0] == 'ok' or integrity['integrity_check'] == 'ok', "Database integrity check failed!"

    # Verify baseline training & academic data 100% intact
    u_count = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_count = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_count = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_count = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']

    print(f"  -> Old data 100% preserved (Users: {u_count}, Courses: {c_count}, Enrollments: {e_count}, Grades: {g_count}): PASS")
    assert u_count >= 73
    assert c_count >= 42
    assert e_count >= 405
    assert g_count >= 248

# ----------------------------------------------------
# 2. Competencies Catalog & Auto-seeding
# ----------------------------------------------------
print("\n[TEST 2] Competency Framework & Seeding:")
with app.app_context():
    seed_default_competencies_if_empty()
    all_comps = get_all_competencies()
    assert len(all_comps) >= 12, f"Expected at least 12 default competencies, got {len(all_comps)}"
    cntt_comps = [c for c in all_comps if c['category'] == 'CNTT']
    gen_comps = [c for c in all_comps if c['category'] == 'Kỹ năng chung']
    assert len(cntt_comps) >= 7
    assert len(gen_comps) >= 5
    print(f"  -> Default Competencies catalog seeded: {len(all_comps)} total (CNTT: {len(cntt_comps)}, General: {len(gen_comps)}): PASS")

    # Admin custom competency creation
    custom_comp_res = create_competency(
        code="COMP_TEST_AI_DEVOPS",
        name="AI DevOps & MLOps Triển Khai",
        category="CNTT",
        description="Xây dựng pipeline tự động hóa CI/CD cho mô hình trí tuệ nhân tạo",
        max_level=5,
        criteria="Hiểu Docker, triển khai container AI và giám sát mô hình trên production.",
        icon="fa-robot"
    )
    assert custom_comp_res['success'] is True
    print("  -> Admin created new custom competency: PASS")

# ----------------------------------------------------
# 3. Student Competency Profile & Dynamic Calculation
# ----------------------------------------------------
print("\n[TEST 3] Student Competency Profile & Radar Chart Data:")
with app.app_context():
    student = query_db("SELECT id FROM users WHERE role = 'student' LIMIT 1", one=True)
    s_id = student['id']

    profile = get_student_competency_profile(s_id)
    assert 'items' in profile
    assert 'summary' in profile
    assert 'radar_data' in profile
    assert len(profile['items']) >= 12
    assert len(profile['radar_data']['labels']) == len(profile['radar_data']['values'])
    assert 0.0 <= profile['summary']['overall_score'] <= 100.0
    print(f"  -> Profile generated: Overall Score = {profile['summary']['overall_score']}%, Achieved = {profile['summary']['achieved']}, In-progress = {profile['summary']['in_progress']}: PASS")

# ----------------------------------------------------
# 4. Teacher Verification & Endorsement
# ----------------------------------------------------
print("\n[TEST 4] Teacher Competency Verification & Evidence:")
with app.app_context():
    teacher = query_db("SELECT id FROM users WHERE role = 'teacher' LIMIT 1", one=True)
    t_id = teacher['id']
    test_comp = all_comps[0]

    v_res = update_or_verify_student_competency(
        student_id=s_id,
        competency_id=test_comp['id'],
        level=4,
        status='ACHIEVED',
        evidence_text="Giảng viên kiểm tra trực tiếp đồ án: Kiến trúc microservice hoàn chỉnh và đạt điểm 10.",
        verified_by=t_id
    )
    assert v_res['success'] is True
    assert v_res['status'] == 'ACHIEVED'

    # Check that profile now reflects this verified competency
    updated_profile = get_student_competency_profile(s_id)
    matched = [it for it in updated_profile['items'] if it['competency_id'] == test_comp['id']]
    assert len(matched) == 1
    assert matched[0]['status'] == 'ACHIEVED'
    assert matched[0]['level'] == 4
    assert any("Kiến trúc microservice hoàn chỉnh" in ev for ev in matched[0]['evidence_list'])
    print(f"  -> Teacher verified competency '{test_comp['name']}' with evidence: PASS")

# ----------------------------------------------------
# 5. Digital Portfolio CRUD
# ----------------------------------------------------
print("\n[TEST 5] Digital Portfolio CRUD & Item Management:")
with app.app_context():
    port = get_or_create_student_portfolio(s_id)
    assert port is not None
    assert port['student_id'] == s_id

    # Update profile
    socials = {'github': 'https://github.com/student', 'linkedin': 'https://linkedin.com/in/student'}
    up_res = update_portfolio_profile(s_id, "Kỹ sư Phần mềm tương lai", "Đam mê kiến trúc đám mây và hệ thống phân tán.", socials, is_public=1)
    assert up_res['success'] is True

    # Add item
    add_res = add_portfolio_item(
        portfolio_id=port['id'],
        item_type='project',
        title='Hệ thống Giám sát LMS Bằng AI',
        description='Xây dựng dịch vụ theo dõi hành vi học tập và phát hiện sinh viên có nguy cơ rớt môn.',
        image_url='',
        link_url='https://github.com/student/lms-monitor',
        skills=['Python', 'Flask', 'Machine Learning'],
        is_pinned=1
    )
    assert add_res['success'] is True
    item_id = add_res['item_id']

    # Retrieve and verify item
    refreshed_port = get_or_create_student_portfolio(s_id)
    found_item = [it for it in refreshed_port['items'] if it['id'] == item_id]
    assert len(found_item) == 1
    assert found_item[0]['title'] == 'Hệ thống Giám sát LMS Bằng AI'
    assert 'Python' in found_item[0]['skills']
    print(f"  -> Added and verified portfolio item #{item_id}: PASS")

# ----------------------------------------------------
# 6. Public Portfolio Access & Privacy Control
# ----------------------------------------------------
print("\n[TEST 6] Public Portfolio & Privacy Enforcement:")
with app.app_context():
    # When is_public = 1
    update_portfolio_profile(s_id, "Kỹ sư Phần mềm", "Bio", socials, is_public=1)
    pub_data = get_public_portfolio_by_user_id(s_id)
    assert pub_data is not None
    assert pub_data['full_name'] is not None
    assert 'competency_profile' in pub_data
    assert pub_data['view_count'] >= 1
    print("  -> Public portfolio accessible when is_public=1: PASS")

    # When is_public = 0 (private)
    update_portfolio_profile(s_id, "Kỹ sư Phần mềm", "Bio", socials, is_public=0)
    pub_private = get_public_portfolio_by_user_id(s_id)
    assert pub_private is None, "Private portfolio must not be exposed!"
    print("  -> Private portfolio returns None (404 safe): PASS")

    # Re-enable public for remaining tests
    update_portfolio_profile(s_id, "Kỹ sư Phần mềm", "Bio", socials, is_public=1)

# ----------------------------------------------------
# 7. Digital Badges Auto-evaluation & Award
# ----------------------------------------------------
print("\n[TEST 7] Digital Badges System & Auto-evaluation:")
with app.app_context():
    seed_default_badges_if_empty()
    all_b = get_all_badges()
    assert len(all_b) >= 6
    print(f"  -> Seeded {len(all_b)} default digital badges: PASS")

    # Test auto award
    awarded = check_and_auto_award_badges(s_id)
    st_badges = get_student_badges(s_id)
    print(f"  -> Auto-evaluated student badges: Total earned = {len(st_badges)}: PASS")

    # Manual award with specific evidence
    award_res = award_badge_to_student(
        student_id=s_id,
        badge_code="BADGE_PROJECT_HERO",
        evidence_text="Hoàn thành xuất sắc đồ án tốt nghiệp với điểm 10/10.",
        issued_by=t_id
    )
    assert award_res['success'] is True
    assert has_student_badge(s_id, "BADGE_PROJECT_HERO") is True

    # Duplicate award should be safely ignored
    dup_res = award_badge_to_student(student_id=s_id, badge_code="BADGE_PROJECT_HERO", evidence_text="Trùng lặp")
    assert dup_res['success'] is True
    assert ('đã nhận' in dup_res['message']) or ('đã sở hữu' in dup_res['message'])
    print("  -> Badges idempotency verified (no duplicate awards): PASS")

# ----------------------------------------------------
# 8. HTTP Endpoints Verification (Student, Teacher, Admin, Public)
# ----------------------------------------------------
print("\n[TEST 8] HTTP Endpoints Verification:")
with app.app_context():
    student_user = query_db("SELECT id, email FROM users WHERE role = 'student' LIMIT 1", one=True)
    teacher_user = query_db("SELECT id, email FROM users WHERE role = 'teacher' LIMIT 1", one=True)
    admin_user = query_db("SELECT id, email FROM users WHERE role = 'admin' LIMIT 1", one=True)

# 8.1 Student Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = student_user['id']
    sess['role'] = 'student'
    sess['email'] = student_user['email']

r_comp = client.get('/student/competencies')
assert r_comp.status_code == 200
assert "Bản đồ Năng lực Cá nhân" in r_comp.get_data(as_text=True)
print("  -> GET /student/competencies: 200 OK")

r_port = client.get('/student/portfolio')
assert r_port.status_code == 200
assert "Hồ sơ Năng lực Số" in r_port.get_data(as_text=True)
print("  -> GET /student/portfolio: 200 OK")

r_badges = client.get('/student/badges')
assert r_badges.status_code == 200
assert "Hệ thống Huy hiệu Thành tích Số" in r_badges.get_data(as_text=True)
print("  -> GET /student/badges: 200 OK")

# 8.2 Teacher Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = teacher_user['id']
    sess['role'] = 'teacher'
    sess['email'] = teacher_user['email']

r_t_comp = client.get('/teacher/competencies')
assert r_t_comp.status_code == 200
assert "Xác thực Năng lực Sinh viên" in r_t_comp.get_data(as_text=True)
print("  -> GET /teacher/competencies: 200 OK")

r_t_verify = client.post('/teacher/competencies/verify', json={
    'student_id': student_user['id'],
    'competency_id': all_comps[1]['id'],
    'level': 3,
    'status': 'ACHIEVED',
    'evidence': 'Xác thực qua bài kiểm tra thực hành cuối kỳ.'
})
assert r_t_verify.status_code == 200
assert r_t_verify.get_json()['success'] is True
print("  -> POST /teacher/competencies/verify: 200 OK (JSON success)")

# 8.3 Admin Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = admin_user['id']
    sess['role'] = 'admin'
    sess['email'] = admin_user['email']

r_a_comp = client.get('/admin/competencies')
assert r_a_comp.status_code == 200
assert "Khung Chuẩn Năng lực" in r_a_comp.get_data(as_text=True)
print("  -> GET /admin/competencies: 200 OK")

r_a_badges = client.get('/admin/badges')
assert r_a_badges.status_code == 200
assert "Hệ thống Huy hiệu Thành tích Số" in r_a_badges.get_data(as_text=True)
print("  -> GET /admin/badges: 200 OK")

# 8.4 Public Endpoints (Anonymous recruiter)
client.get('/logout') # ensure anonymous
r_pub = client.get(f'/portfolio/{student_user["id"]}')
assert r_pub.status_code == 200
assert "Verified Digital Credentials" in r_pub.get_data(as_text=True)
print(f"  -> GET /portfolio/{student_user['id']} (Public Recruiter View): 200 OK")

r_pub_404 = client.get('/portfolio/999999')
assert r_pub_404.status_code == 404
print("  -> GET /portfolio/999999 (Non-existent Portfolio): 404 Not Found: PASS")

# ----------------------------------------------------
# 9. Core System Non-regression Check
# ----------------------------------------------------
print("\n[TEST 9] Core System Non-regression Check:")
r_login = client.get('/login')
assert r_login.status_code == 200
print("  -> /login: 200 OK")

print("\n" + "=" * 50)
print("ALL PHASE 6 VERIFICATION TESTS PASSED SUCCESSFULLY!")
print("=" * 50)
