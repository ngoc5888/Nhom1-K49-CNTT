import os
import shutil
import sqlite3
import datetime
import json

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'lms.db')
BACKUP_DIR = os.path.join(BASE_DIR, 'backups')

def verify_db_integrity(db_file):
    """Run SQLite integrity check on a database file."""
    if not os.path.exists(db_file):
        return False, "File does not exist"
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("PRAGMA integrity_check;")
        res = cursor.fetchone()
        conn.close()
        if res and res[0].lower() == 'ok':
            return True, "Integrity OK"
        return False, f"Integrity check failed: {res}"
    except Exception as e:
        return False, str(e)

def backup_database(dest_dir=None):
    """
    Create a timestamped backup of lms.db without locking the application.
    """
    target_dir = dest_dir or BACKUP_DIR
    os.makedirs(target_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"lms_backup_{timestamp}.db"
    backup_path = os.path.join(target_dir, backup_filename)
    meta_path = os.path.join(target_dir, f"lms_backup_{timestamp}.json")

    # Use SQLite backup API for online safe copy
    src_conn = sqlite3.connect(DB_PATH)
    dst_conn = sqlite3.connect(backup_path)
    with dst_conn:
        src_conn.backup(dst_conn)
    dst_conn.close()
    src_conn.close()

    ok, msg = verify_db_integrity(backup_path)
    if not ok:
        raise RuntimeError(f"Backup verification failed: {msg}")

    meta = {
        "filename": backup_filename,
        "backup_path": backup_path,
        "created_at": datetime.datetime.now().isoformat(),
        "size_bytes": os.path.getsize(backup_path),
        "integrity": msg
    }
    with open(meta_path, 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=2)

    print(f"[BACKUP SUCCESS] Created: {backup_path} ({meta['size_bytes']} bytes)")
    return backup_path

def restore_database(backup_file, target_path=None):
    """
    Safely restore database from a verified backup.
    """
    dest = target_path or DB_PATH
    if not os.path.exists(backup_file):
        raise FileNotFoundError(f"Backup file not found: {backup_file}")

    ok, msg = verify_db_integrity(backup_file)
    if not ok:
        raise ValueError(f"Cannot restore from corrupt backup: {msg}")

    # Create safety temp copy of current DB if exists
    temp_rollback = None
    if os.path.exists(dest):
        temp_rollback = dest + ".rollback_temp"
        shutil.copy2(dest, temp_rollback)

    try:
        shutil.copy2(backup_file, dest)
        dest_ok, dest_msg = verify_db_integrity(dest)
        if not dest_ok:
            raise RuntimeError(f"Restored DB failed verification: {dest_msg}")
        if temp_rollback and os.path.exists(temp_rollback):
            os.remove(temp_rollback)
        print(f"[RESTORE SUCCESS] Restored {dest} from {backup_file}")
        return True
    except Exception as e:
        if temp_rollback and os.path.exists(temp_rollback):
            shutil.copy2(temp_rollback, dest)
            os.remove(temp_rollback)
        raise RuntimeError(f"Restore failed, rolled back to original state: {e}")

def list_backups(dest_dir=None):
    target_dir = dest_dir or BACKUP_DIR
    if not os.path.exists(target_dir):
        return []
    files = [f for f in os.listdir(target_dir) if f.endswith('.db')]
    backups = []
    for f in sorted(files, reverse=True):
        full_path = os.path.join(target_dir, f)
        ok, msg = verify_db_integrity(full_path)
        backups.append({
            "name": f,
            "path": full_path,
            "size": os.path.getsize(full_path),
            "valid": ok
        })
    return backups

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'restore':
        if len(sys.argv) > 2:
            restore_database(sys.argv[2])
        else:
            print("Usage: python backup_recovery.py restore <backup_file_path>")
    else:
        backup_database()
