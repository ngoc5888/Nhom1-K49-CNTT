import json
from services.ai_gateway import call_ai
from database import query_db, execute_db

def generate_quiz_questions(topic, num_questions=3, difficulty="Trung bình", course_name=""):
    """
    Generate multiple-choice quiz questions using AI Gateway.
    Returns parsed list of questions: [{question, options, correct_index, explanation}]
    """
    system_instruction = (
        "Bạn là Chuyên gia Khảo thí và Đo lường Giáo dục Đại học. "
        "Nhiệm vụ của bạn là soạn các câu hỏi trắc nghiệm chất lượng cao. "
        "Định dạng phản hồi BẮT BUỘC là một JSON Array hợp lệ, không chứa văn bản thừa bên ngoài: "
        '[{"question": "Nội dung câu hỏi...", "options": ["Đáp án A", "Đáp án B", "Đáp án C", "Đáp án D"], "correct_index": 0, "explanation": "Giải thích tại sao đáp án này đúng..."}]'
    )

    prompt = (
        f"Hãy tạo {num_questions} câu hỏi trắc nghiệm 4 lựa chọn (A, B, C, D) "
        f"cho môn học '{course_name}', chủ đề: '{topic}'. "
        f"Mức độ khó: {difficulty}. "
        "Mỗi câu hỏi phải có 1 đáp án đúng duy nhất, các phương án nhiễu hợp lý và giải thích chi tiết."
    )

    ai_res = call_ai(
        prompt=prompt,
        system_instruction=system_instruction,
        role='teacher',
        service_name='quiz_gen'
    )

    if not ai_res['success']:
        # Fallback if no key or error
        return {
            "success": False,
            "status": ai_res['status'],
            "message": ai_res['content'],
            "questions": []
        }

    raw_text = ai_res['content'].strip()
    # Clean json formatting markdown if present (```json ... ```)
    if raw_text.startswith("```"):
        raw_text = raw_text.split("```")[1]
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    try:
        parsed_questions = json.loads(raw_text)
        return {
            "success": True,
            "status": "SUCCESS",
            "message": f"Đã tạo thành công {len(parsed_questions)} câu hỏi trắc nghiệm.",
            "questions": parsed_questions
        }
    except Exception as e:
        # Fallback parse or return raw
        return {
            "success": False,
            "status": "PARSE_ERROR",
            "message": f"Không thể phân tích định dạng JSON từ phản hồi AI: {raw_text[:200]}",
            "questions": []
        }

def generate_lecture_outline(topic, course_name=""):
    """
    Generate a lecture outline / syllabus structure.
    """
    system_instruction = "Bạn là Trợ lý Sư phạm Đại học. Hãy soạn dàn ý bài giảng chi tiết, có mục tiêu, nội dung chính, bài tập và tài liệu tham khảo."
    prompt = f"Soạn đề cương bài giảng chi tiết cho môn '{course_name}', bài học: '{topic}'."
    return call_ai(prompt=prompt, system_instruction=system_instruction, role='teacher', service_name='outline_gen')

def save_generated_question_to_exam(exam_id, question_text, options, correct_index, points=1.0):
    """
    Save an AI generated question directly to the database questions table for an exam.
    """
    return execute_db("""
        INSERT INTO questions (exam_id, question_text, question_type, options_json, correct_answers_json, points)
        VALUES (?, ?, 'single', ?, ?, ?)
    """, (exam_id, question_text, json.dumps(options, ensure_ascii=False), json.dumps([correct_index]), points))
