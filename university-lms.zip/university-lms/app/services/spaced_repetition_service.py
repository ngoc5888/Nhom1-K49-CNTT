import json
import re
from datetime import datetime, date, timedelta
from database import query_db, execute_db
from services.activity_service import log_activity
from services.ai_gateway import call_ai

# ==========================================
# 1. SPCAED REPETITION (SM-2 ALGORITHM)
# ==========================================

def calculate_sm2(rating, repetition_count, ease_factor, interval_days):
    """
    Thuật toán SuperMemo 2 (SM-2) cải tiến cho ôn tập thẻ ngắt quãng:
    rating:
      1 - Again (Quên/Ôn lại ngay): reset tiến trình, học lại sau 1 ngày
      2 - Hard (Khó nhớ): tăng khoảng cách nhẹ x1.2, giảm EF
      3 - Good (Nhớ tốt): chuẩn SM-2 (1 ngày -> 6 ngày -> interval * EF)
      4 - Easy (Rất dễ): tăng khoảng cách nhanh x1.3, tăng EF
    """
    ease_factor = float(ease_factor or 2.5)
    repetition_count = int(repetition_count or 0)
    interval_days = int(interval_days or 1)

    if rating == 1: # Again
        new_repetition = 0
        new_interval = 1
        new_ef = max(1.3, ease_factor - 0.2)
    elif rating == 2: # Hard
        new_repetition = repetition_count + 1
        new_interval = max(1, int(interval_days * 1.2))
        new_ef = max(1.3, ease_factor - 0.15)
    elif rating == 3: # Good
        new_repetition = repetition_count + 1
        if new_repetition == 1:
            new_interval = 1
        elif new_repetition == 2:
            new_interval = 6
        else:
            new_interval = max(1, int(interval_days * ease_factor))
        new_ef = ease_factor
    elif rating == 4: # Easy
        new_repetition = repetition_count + 1
        if new_repetition == 1:
            new_interval = 3
        elif new_repetition == 2:
            new_interval = 8
        else:
            new_interval = max(1, int(interval_days * ease_factor * 1.3))
        new_ef = ease_factor + 0.15
    else:
        new_repetition = repetition_count
        new_interval = interval_days
        new_ef = ease_factor

    new_ef = round(new_ef, 2)
    next_date = date.today() + timedelta(days=new_interval)
    return new_repetition, new_interval, new_ef, next_date.isoformat()

def process_flashcard_review(student_id, card_id, rating):
    """
    Xử lý một lượt ôn tập Flashcard theo SM-2.
    Đảm bảo tính riêng tư của thẻ học (chỉ chủ thẻ mới được review).
    """
    card = query_db(
        "SELECT * FROM study_flashcards WHERE id = ? AND student_id = ?",
        (card_id, student_id),
        one=True
    )
    if not card:
        return {'success': False, 'message': 'Thẻ ghi nhớ không tồn tại hoặc không thuộc quyền sở hữu của bạn.'}

    rating = int(rating)
    if rating not in [1, 2, 3, 4]:
        rating = 3

    new_rep, new_int, new_ef, next_review = calculate_sm2(
        rating,
        card['repetition_count'],
        card['ease_factor'],
        card['interval_days']
    )

    execute_db(
        """
        UPDATE study_flashcards
        SET repetition_count = ?, interval_days = ?, ease_factor = ?, next_review_date = ?, last_reviewed_at = CURRENT_TIMESTAMP
        WHERE id = ? AND student_id = ?
        """,
        (new_rep, new_int, new_ef, next_review, card_id, student_id)
    )

    log_activity(
        student_id,
        card['course_id'],
        'FLASHCARD_REVIEW',
        card_id,
        {'rating': rating, 'next_review_date': next_review, 'interval_days': new_int}
    )

    return {
        'success': True,
        'message': f"Đã ghi nhận ôn tập. Lần ôn tiếp theo: {next_review} (sau {new_int} ngày).",
        'next_review_date': next_review,
        'interval_days': new_int,
        'ease_factor': new_ef
    }

def get_student_flashcards(student_id, course_id=None, deck_name=None, filter_due=False):
    """Lấy danh sách Flashcard của sinh viên, có hỗ trợ lọc đến hạn ôn tập"""
    sql = """
        SELECT f.*, c.name as course_name, c.code as course_code
        FROM study_flashcards f
        LEFT JOIN courses c ON f.course_id = c.id
        WHERE f.student_id = ?
    """
    params = [student_id]

    if course_id:
        sql += " AND f.course_id = ?"
        params.append(course_id)

    if deck_name:
        sql += " AND f.deck_name = ?"
        params.append(deck_name)

    if filter_due:
        sql += " AND f.next_review_date <= DATE('now')"

    sql += " ORDER BY f.next_review_date ASC, f.id DESC"
    rows = query_db(sql, tuple(params))
    return [dict(r) for r in rows]

def get_flashcard_stats(student_id, course_id=None):
    """Thống kê kho thẻ ghi nhớ của sinh viên"""
    today_str = date.today().isoformat()
    base_sql = "FROM study_flashcards WHERE student_id = ?"
    params = [student_id]
    if course_id:
        base_sql += " AND course_id = ?"
        params.append(course_id)

    total = query_db(f"SELECT COUNT(*) as c {base_sql}", tuple(params), one=True)['c']
    due = query_db(f"SELECT COUNT(*) as c {base_sql} AND next_review_date <= DATE('now')", tuple(params), one=True)['c']
    mastered = query_db(f"SELECT COUNT(*) as c {base_sql} AND interval_days >= 21", tuple(params), one=True)['c']
    reviewed_today = query_db(f"SELECT COUNT(*) as c {base_sql} AND DATE(last_reviewed_at) = DATE('now')", tuple(params), one=True)['c']

    return {
        'total_cards': total,
        'due_today': due,
        'mastered_cards': mastered,
        'reviewed_today': reviewed_today
    }

def create_flashcard(student_id, front_text, back_text, course_id=None, deck_name='Mặc định'):
    """Tạo mới một thẻ ghi nhớ thủ công"""
    if not front_text or not back_text:
        return {'success': False, 'message': 'Nội dung mặt trước và mặt sau không được để trống.'}

    card_id = execute_db(
        """
        INSERT INTO study_flashcards (student_id, course_id, front_text, back_text, deck_name, next_review_date)
        VALUES (?, ?, ?, ?, ?, DATE('now'))
        """,
        (student_id, course_id, front_text.strip(), back_text.strip(), deck_name.strip() or 'Mặc định')
    )
    return {'success': True, 'card_id': card_id, 'message': 'Đã tạo thẻ ghi nhớ thành công!'}

def delete_flashcard(student_id, card_id):
    """Xóa thẻ ghi nhớ (đảm bảo quyền sở hữu)"""
    card = query_db("SELECT id FROM study_flashcards WHERE id = ? AND student_id = ?", (card_id, student_id), one=True)
    if not card:
        return {'success': False, 'message': 'Thẻ không tồn tại hoặc bạn không có quyền xóa.'}

    execute_db("DELETE FROM study_flashcards WHERE id = ? AND student_id = ?", (card_id, student_id))
    return {'success': True, 'message': 'Đã xóa thẻ ghi nhớ.'}

def generate_flashcards_with_ai(student_id, course_id, topic_prompt=None, count=5):
    """
    Sinh thẻ ghi nhớ tự động bằng AI từ giáo trình hoặc chủ đề học phần.
    Tích hợp cơ chế fallback nếu AI offline hoặc chưa có API key.
    """
    course = query_db("SELECT id, code, name, description FROM courses WHERE id = ?", (course_id,), one=True)
    c_name = course['name'] if course else "Học phần"
    deck_name = f"AI Deck - {c_name[:20]}"

    prompt_content = topic_prompt or f"Các khái niệm, thuật ngữ và định lý trọng tâm của học phần {c_name}."

    ai_prompt = f"""Bạn là trợ lý học tập thông minh. Hãy tạo {count} thẻ ghi nhớ (Flashcards) để sinh viên ôn thi học phần '{c_name}'.
Chủ đề / Yêu cầu: {prompt_content}

Yêu cầu định dạng:
Trả về DUY NHẤT một mảng JSON hợp lệ, không chứa giải thích phụ trợ, dạng:
[
  {{"front": "Thuật ngữ / Câu hỏi ngắn mặt trước", "back": "Định nghĩa / Lời giải tóm tắt mặt sau"}},
  ...
]"""

    response = call_ai(
        prompt=ai_prompt,
        user_id=student_id,
        role='student',
        service_name='flashcard_gen'
    )

    created_cards = []
    resp_text = response.get('content') or response.get('text')
    if response.get('success') and resp_text:
        try:
            raw_text = resp_text.strip()
            # Trích xuất JSON nếu model bọc trong markdown code block
            json_match = re.search(r'\[.*\]', raw_text, re.DOTALL)
            if json_match:
                cards_data = json.loads(json_match.group(0))
            else:
                cards_data = json.loads(raw_text)

            for item in cards_data:
                front = item.get('front', '').strip()
                back = item.get('back', '').strip()
                if front and back:
                    cid = execute_db(
                        """
                        INSERT INTO study_flashcards (student_id, course_id, front_text, back_text, deck_name, next_review_date)
                        VALUES (?, ?, ?, ?, ?, DATE('now'))
                        """,
                        (student_id, course_id, front, back, deck_name)
                    )
                    created_cards.append({'id': cid, 'front': front, 'back': back})
        except Exception as e:
            created_cards = []

    # Fallback chất lượng cao nếu AI trả lời không đủ hoặc không có key
    if not created_cards:
        fallback_templates = [
            (f"Khái niệm cốt lõi của {c_name} là gì?", f"Nền tảng lý thuyết và công cụ ứng dụng trong thực tế giải quyết các bài toán về {c_name}."),
            (f"Các thành phần kiến trúc chính trong {c_name}", "Bao gồm mô hình dữ liệu, tầng logic nghiệp vụ, giao diện người dùng và cơ chế bảo mật."),
            (f"Quy trình thực thi chuẩn khi phân tích môn {c_name}", "1. Khảo sát yêu cầu -> 2. Thiết kế giải pháp -> 3. Hiện thực mã nguồn -> 4. Kiểm thử & Đánh giá."),
            (f"Các rủi ro thường gặp và phương pháp phòng ngừa trong {c_name}", "Lỗi rò rỉ dữ liệu, xung đột phiên bản, thiếu kiểm tra ngoại lệ; phòng tránh bằng logging và unit test."),
            (f"Tiêu chuẩn đánh giá hiệu năng trong {c_name}", "Độ trễ phản hồi thấp, tính mở rộng cao, tối ưu tài nguyên phần cứng và trải nghiệm người dùng.")
        ]
        for front, back in fallback_templates[:count]:
            cid = execute_db(
                """
                INSERT INTO study_flashcards (student_id, course_id, front_text, back_text, deck_name, next_review_date)
                VALUES (?, ?, ?, ?, ?, DATE('now'))
                """,
                (student_id, course_id, front, back, f"Cốt lõi - {c_name[:15]}")
            )
            created_cards.append({'id': cid, 'front': front, 'back': back})

    log_activity(
        student_id,
        course_id,
        'FLASHCARD_AI_GEN',
        len(created_cards),
        {'deck_name': deck_name, 'count': len(created_cards)}
    )

    return {
        'success': True,
        'cards': created_cards,
        'message': f"Đã tạo thành công {len(created_cards)} thẻ ghi nhớ thông minh cho học phần {c_name}."
    }

# ==========================================
# 2. STUDY NOTES MANAGEMENT
# ==========================================

def get_student_notes(student_id, course_id=None, search=None):
    """Lấy danh sách ghi chú cá nhân của sinh viên (ưu tiên ghim lên đầu)"""
    sql = """
        SELECT n.*, c.name as course_name, c.code as course_code
        FROM study_notes n
        LEFT JOIN courses c ON n.course_id = c.id
        WHERE n.student_id = ?
    """
    params = [student_id]

    if course_id:
        sql += " AND n.course_id = ?"
        params.append(course_id)

    if search:
        sql += " AND (n.title LIKE ? OR n.content LIKE ?)"
        term = f"%{search}%"
        params.extend([term, term])

    sql += " ORDER BY n.is_pinned DESC, n.updated_at DESC, n.id DESC"
    rows = query_db(sql, tuple(params))
    return [dict(r) for r in rows]

def create_student_note(student_id, title, content, course_id=None, is_pinned=0):
    """Tạo ghi chú mới"""
    if not title or not content:
        return {'success': False, 'message': 'Tiêu đề và nội dung ghi chú không được để trống.'}

    note_id = execute_db(
        """
        INSERT INTO study_notes (student_id, course_id, title, content, is_pinned)
        VALUES (?, ?, ?, ?, ?)
        """,
        (student_id, course_id, title.strip(), content.strip(), 1 if is_pinned else 0)
    )

    log_activity(student_id, course_id, 'NOTE_CREATED', note_id, {'title': title.strip()})
    return {'success': True, 'note_id': note_id, 'message': 'Đã lưu ghi chú thành công.'}

def delete_student_note(student_id, note_id):
    """Xóa ghi chú của sinh viên"""
    note = query_db("SELECT id, title FROM study_notes WHERE id = ? AND student_id = ?", (note_id, student_id), one=True)
    if not note:
        return {'success': False, 'message': 'Ghi chú không tồn tại hoặc bạn không có quyền xóa.'}

    execute_db("DELETE FROM study_notes WHERE id = ? AND student_id = ?", (note_id, student_id))
    return {'success': True, 'message': f"Đã xóa ghi chú '{note['title']}'."}

# ==========================================
# 3. STUDY SESSIONS & POMODORO TRACKER
# ==========================================

def record_study_session(student_id, course_id=None, duration_minutes=25, study_type='pomodoro', notes=''):
    """Ghi nhận phiên tập trung học tập / Pomodoro"""
    duration_minutes = int(duration_minutes or 25)
    sid = execute_db(
        """
        INSERT INTO study_sessions (student_id, course_id, duration_minutes, study_type, notes)
        VALUES (?, ?, ?, ?, ?)
        """,
        (student_id, course_id, duration_minutes, study_type or 'pomodoro', notes.strip() if notes else '')
    )

    log_activity(
        student_id,
        course_id,
        'STUDY_SESSION_COMPLETED',
        sid,
        {'duration_minutes': duration_minutes, 'study_type': study_type}
    )

    return {'success': True, 'session_id': sid, 'message': f"Đã hoàn thành phiên tập trung {duration_minutes} phút!"}

def get_study_session_stats(student_id):
    """Thống kê tổng quan thời gian và chuỗi ngày tập trung học tập"""
    total_min = query_db(
        "SELECT SUM(duration_minutes) as m FROM study_sessions WHERE student_id = ?",
        (student_id,),
        one=True
    )['m'] or 0

    sessions_today = query_db(
        "SELECT COUNT(*) as c FROM study_sessions WHERE student_id = ? AND DATE(created_at) = DATE('now')",
        (student_id,),
        one=True
    )['c'] or 0

    total_sessions = query_db(
        "SELECT COUNT(*) as c FROM study_sessions WHERE student_id = ?",
        (student_id,),
        one=True
    )['c'] or 0

    # Tính chuỗi ngày học liên tiếp (Streak)
    streak_rows = query_db(
        """
        SELECT DISTINCT DATE(created_at) as study_date
        FROM study_sessions
        WHERE student_id = ?
        ORDER BY study_date DESC
        LIMIT 30
        """,
        (student_id,)
    )

    dates = [datetime.strptime(r['study_date'], '%Y-%m-%d').date() for r in streak_rows]
    streak = 0
    today = date.today()
    check_day = today

    # Nếu hôm nay chưa học, kiểm tra bắt đầu từ hôm qua
    if dates and dates[0] == today:
        pass
    elif dates and dates[0] == today - timedelta(days=1):
        check_day = today - timedelta(days=1)
    else:
        check_day = None

    if check_day:
        for d in dates:
            if d == check_day:
                streak += 1
                check_day -= timedelta(days=1)
            else:
                break

    return {
        'total_minutes': total_min,
        'total_hours': round(total_min / 60.0, 1),
        'sessions_today': sessions_today,
        'total_sessions': total_sessions,
        'streak_days': streak
    }
