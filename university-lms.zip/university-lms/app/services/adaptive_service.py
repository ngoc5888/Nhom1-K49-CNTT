import json
from datetime import datetime
from database import query_db, execute_db
from services.activity_service import log_activity
from services.ai_gateway import call_ai

def ensure_course_topics(course_id):
    """
    Đảm bảo môn học luôn có danh sách chủ đề / chương mục học tập thích ứng.
    Nếu chưa có, tự động tạo cấu trúc 4 chương chuẩn hoá dựa trên thông tin môn học.
    """
    existing = query_db(
        "SELECT * FROM course_topics WHERE course_id = ? ORDER BY order_index ASC",
        (course_id,)
    )
    if existing:
        return existing

    # Lấy thông tin lớp học phần
    course = query_db("SELECT id, name, code, description FROM courses WHERE id = ?", (course_id,), one=True)
    c_name = course['name'] if course else f"Học phần #{course_id}"

    default_topics = [
        (1, f"Chương 1: Tổng quan & Cơ sở lý thuyết {c_name}", "Nắm vững các khái niệm nền tảng, thuật ngữ và phạm vi ứng dụng.", None),
        (2, f"Chương 2: Kiến trúc & Phương pháp thực hành cốt lõi", "Các nguyên lý thiết kế, công cụ và quy trình làm việc chuẩn mực.", 1),
        (3, f"Chương 3: Kỹ thuật nâng cao & Ứng dụng thực tế", "Giải quyết các bài toán phức tạp, chuyên sâu và nghiên cứu tình huống.", 2),
        (4, f"Chương 4: Đánh giá, Tối ưu & Đồ án chuyên sâu", "Tổng kết, kiểm thử, tối ưu hiệu năng và triển khai sản phẩm thực tế.", 3)
    ]

    created_ids = {}
    for chapter_num, title, desc, prereq_chap in default_topics:
        prereq_id = created_ids.get(prereq_chap)
        new_id = execute_db(
            """
            INSERT INTO course_topics (course_id, chapter_num, title, description, order_index, prerequisite_topic_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (course_id, chapter_num, title, desc, chapter_num, prereq_id)
        )
        created_ids[chapter_num] = new_id

    return query_db(
        "SELECT * FROM course_topics WHERE course_id = ? ORDER BY order_index ASC",
        (course_id,)
    )

def get_student_courses(student_id):
    """Lấy danh sách các lớp học phần sinh viên đang theo học"""
    return query_db(
        """
        SELECT c.id, c.code, c.name, c.semester, c.academic_year, u.full_name as teacher_name
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        LEFT JOIN users u ON c.teacher_id = u.id
        WHERE e.student_id = ? AND (e.status = 'active' OR e.status IS NULL)
        ORDER BY c.code ASC
        """,
        (student_id,)
    )

def compute_student_learning_path(student_id, course_id=None):
    """
    Tính toán lộ trình học tập cá nhân hoá thích ứng (Adaptive Learning Path)
    theo từng chủ đề cho sinh viên.
    """
    courses = get_student_courses(student_id)
    if not courses:
        return {
            'courses': [],
            'selected_course': None,
            'topics': [],
            'summary': {
                'total_topics': 0,
                'mastered_topics': 0,
                'in_progress_topics': 0,
                'needs_review_topics': 0,
                'not_started_topics': 0,
                'overall_mastery': 0.0
            },
            'recommended_topic': None,
            'adaptive_advice': "Bạn hiện chưa đăng ký lớp học phần nào để lập lộ trình."
        }

    # Chọn môn học mặc định nếu chưa chọn
    if not course_id:
        course_id = courses[0]['id']
    else:
        course_id = int(course_id)

    # Đảm bảo sinh viên thực sự đăng ký môn học này (Bảo mật RBAC)
    selected_course = next((c for c in courses if c['id'] == course_id), None)
    if not selected_course:
        selected_course = courses[0]
        course_id = selected_course['id']

    # Đảm bảo môn học có các chủ đề chuẩn
    topics = ensure_course_topics(course_id)

    # Lấy tiến độ của sinh viên đối với từng chủ đề
    progress_rows = query_db(
        """
        SELECT topic_id, mastery_score, status, notes, last_studied_at
        FROM student_topic_progress
        WHERE student_id = ? AND course_id = ?
        """,
        (student_id, course_id)
    )
    progress_map = {p['topic_id']: p for p in progress_rows}

    # Lấy điểm thi/bài tập trung bình nếu có để đối chiếu
    grade_row = query_db(
        "SELECT AVG(total_score) as avg_score FROM grades WHERE student_id = ? AND course_id = ?",
        (student_id, course_id),
        one=True
    )
    avg_grade = grade_row['avg_score'] if grade_row and grade_row['avg_score'] is not None else None

    topic_items = []
    total_mastery = 0.0
    mastered_cnt = 0
    in_progress_cnt = 0
    needs_review_cnt = 0
    not_started_cnt = 0

    recommended_topic = None

    for t in topics:
        tid = t['id']
        prog = progress_map.get(tid)
        if prog:
            m_score = float(prog['mastery_score'])
            status = prog['status']
            notes = prog['notes'] or ''
            last_studied = prog['last_studied_at']
        else:
            # Khởi tạo mặc định nếu sinh viên chưa có bản ghi
            m_score = 0.0
            status = 'NOT_STARTED'
            notes = ''
            last_studied = None
            execute_db(
                """
                INSERT OR IGNORE INTO student_topic_progress
                (student_id, topic_id, course_id, mastery_score, status)
                VALUES (?, ?, ?, 0.0, 'NOT_STARTED')
                """,
                (student_id, tid, course_id)
            )

        total_mastery += m_score
        if status == 'MASTERED' or m_score >= 80.0:
            mastered_cnt += 1
            badge_class = 'success'
            status_label = 'Đã thông thạo'
        elif status == 'IN_PROGRESS' or (m_score >= 40.0 and m_score < 80.0):
            in_progress_cnt += 1
            badge_class = 'primary'
            status_label = 'Đang học'
        elif status == 'NEEDS_REVIEW':
            needs_review_cnt += 1
            badge_class = 'warning'
            status_label = 'Cần ôn tập'
        else:
            not_started_cnt += 1
            badge_class = 'secondary'
            status_label = 'Chưa bắt đầu'

        topic_data = {
            'id': tid,
            'chapter_num': t['chapter_num'],
            'title': t['title'],
            'description': t['description'],
            'order_index': t['order_index'],
            'prerequisite_topic_id': t['prerequisite_topic_id'],
            'mastery_score': m_score,
            'status': status,
            'status_label': status_label,
            'badge_class': badge_class,
            'notes': notes,
            'last_studied_at': last_studied
        }
        topic_items.append(topic_data)

        # Tìm chủ đề tiếp theo cần tập trung học
        if recommended_topic is None and (status in ['NOT_STARTED', 'IN_PROGRESS', 'NEEDS_REVIEW'] or m_score < 80.0):
            recommended_topic = topic_data

    total_topics = len(topics)
    overall_mastery = round(total_mastery / total_topics, 1) if total_topics > 0 else 0.0

    # Lập lời khuyên thích ứng (Adaptive Recommendation Engine)
    if overall_mastery >= 85.0:
        adaptive_advice = (
            f"🎉 Xuất sắc! Bạn đã làm chủ {overall_mastery}% kiến thức học phần. "
            "Hãy thử sức với các bài tập mở rộng, nghiên cứu tình huống nâng cao và hỗ trợ các bạn cùng lớp."
        )
    elif overall_mastery >= 65.0:
        adaptive_advice = (
            f"🚀 Tiến độ rất tích cực ({overall_mastery}%). "
            f"Tiếp tục đẩy mạnh {recommended_topic['title'] if recommended_topic else 'chủ đề tiếp theo'} "
            "và tạo Flashcard ôn tập các thuật ngữ quan trọng."
        )
    elif overall_mastery >= 40.0:
        adaptive_advice = (
            f"📈 Mức độ thông thạo hiện tại đạt {overall_mastery}%. "
            f"Đề xuất bạn ưu tiên hoàn thành {recommended_topic['title'] if recommended_topic else 'chương tiếp theo'}, "
            "dành 25 phút Pomodoro mỗi ngày để đọc tài liệu và làm bài tập trắc nghiệm."
        )
    else:
        adaptive_advice = (
            f"💡 Bạn mới bắt đầu học phần này ({overall_mastery}%). "
            f"Khuyến nghị tập trung vào {recommended_topic['title'] if recommended_topic else 'Chương 1'}, "
            "sử dụng Trợ lý AI hỏi đáp tài liệu môn học và ghi chú tóm tắt sau mỗi buổi học."
        )

    return {
        'courses': courses,
        'selected_course': selected_course,
        'topics': topic_items,
        'summary': {
            'total_topics': total_topics,
            'mastered_topics': mastered_cnt,
            'in_progress_topics': in_progress_cnt,
            'needs_review_topics': needs_review_cnt,
            'not_started_topics': not_started_cnt,
            'overall_mastery': overall_mastery,
            'avg_grade': round(avg_grade, 2) if avg_grade is not None else None
        },
        'recommended_topic': recommended_topic,
        'adaptive_advice': adaptive_advice
    }

def update_topic_progress(student_id, topic_id, mastery_score=None, status=None, notes=None):
    """
    Cập nhật tiến độ chủ đề học tập cho sinh viên.
    Kiểm tra bảo mật đảm bảo chủ đề thuộc môn học sinh viên được đăng ký.
    """
    topic = query_db("SELECT id, course_id, title FROM course_topics WHERE id = ?", (topic_id,), one=True)
    if not topic:
        return {'success': False, 'message': 'Chủ đề không tồn tại.'}

    course_id = topic['course_id']
    enrolled = query_db(
        "SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?",
        (student_id, course_id),
        one=True
    )
    if not enrolled:
        return {'success': False, 'message': 'Bạn không tham gia lớp học phần này.'}

    # Lấy thông tin hiện tại
    current = query_db(
        "SELECT * FROM student_topic_progress WHERE student_id = ? AND topic_id = ?",
        (student_id, topic_id),
        one=True
    )

    new_mastery = float(mastery_score) if mastery_score is not None else (current['mastery_score'] if current else 0.0)
    new_mastery = max(0.0, min(100.0, new_mastery))

    if status:
        new_status = status
    elif new_mastery >= 80.0:
        new_status = 'MASTERED'
    elif new_mastery >= 40.0:
        new_status = 'IN_PROGRESS'
    elif new_mastery > 0.0:
        new_status = 'IN_PROGRESS'
    else:
        new_status = current['status'] if current else 'NOT_STARTED'

    new_notes = notes if notes is not None else (current['notes'] if current else '')

    execute_db(
        """
        INSERT INTO student_topic_progress (student_id, topic_id, course_id, mastery_score, status, notes, last_studied_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(student_id, topic_id) DO UPDATE SET
            mastery_score = excluded.mastery_score,
            status = excluded.status,
            notes = excluded.notes,
            last_studied_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        """,
        (student_id, topic_id, course_id, new_mastery, new_status, new_notes)
    )

    log_activity(
        student_id,
        course_id,
        'TOPIC_PROGRESS_UPDATE',
        topic_id,
        {'topic_title': topic['title'], 'mastery_score': new_mastery, 'status': new_status}
    )

    return {
        'success': True,
        'message': f"Đã cập nhật tiến độ '{topic['title']}' thành công.",
        'mastery_score': new_mastery,
        'status': new_status
    }

def get_teacher_adaptive_overview(teacher_id, course_id=None, is_admin=False):
    """
    Góc nhìn của Giảng viên: Thống kê mức độ thông thạo từng chủ đề của cả lớp,
    chỉ ra các điểm nghẽn học tập (Learning Bottlenecks) cần giảng giải thêm.
    """
    if is_admin:
        courses = query_db("SELECT id, code, name, semester, academic_year FROM courses ORDER BY code ASC")
    else:
        courses = query_db(
            "SELECT id, code, name, semester, academic_year FROM courses WHERE teacher_id = ? ORDER BY code ASC",
            (teacher_id,)
        )

    if not courses:
        return {'courses': [], 'selected_course': None, 'topic_stats': [], 'students': [], 'alerts': []}

    if not course_id:
        course_id = courses[0]['id']
    else:
        course_id = int(course_id)

    selected_course = next((c for c in courses if c['id'] == course_id), courses[0])
    course_id = selected_course['id']

    # Đảm bảo môn học có các chủ đề
    topics = ensure_course_topics(course_id)

    # Thống kê từng chủ đề theo toàn thể sinh viên trong lớp
    topic_stats = []
    alerts = []

    for t in topics:
        tid = t['id']
        stat = query_db(
            """
            SELECT 
                COUNT(p.id) as total_tracked,
                AVG(p.mastery_score) as avg_mastery,
                SUM(CASE WHEN p.status = 'MASTERED' OR p.mastery_score >= 80 THEN 1 ELSE 0 END) as mastered_cnt,
                SUM(CASE WHEN p.status = 'IN_PROGRESS' OR (p.mastery_score >= 40 AND p.mastery_score < 80) THEN 1 ELSE 0 END) as in_progress_cnt,
                SUM(CASE WHEN p.status = 'NEEDS_REVIEW' THEN 1 ELSE 0 END) as needs_review_cnt,
                SUM(CASE WHEN p.status = 'NOT_STARTED' OR p.mastery_score = 0 THEN 1 ELSE 0 END) as not_started_cnt
            FROM enrollments e
            LEFT JOIN student_topic_progress p ON e.student_id = p.student_id AND p.topic_id = ?
            WHERE e.course_id = ?
            """,
            (tid, course_id),
            one=True
        )

        avg_m = round(stat['avg_mastery'] or 0.0, 1)
        topic_info = {
            'id': tid,
            'chapter_num': t['chapter_num'],
            'title': t['title'],
            'description': t['description'],
            'avg_mastery': avg_m,
            'mastered_cnt': stat['mastered_cnt'] or 0,
            'in_progress_cnt': stat['in_progress_cnt'] or 0,
            'needs_review_cnt': stat['needs_review_cnt'] or 0,
            'not_started_cnt': stat['not_started_cnt'] or 0,
            'total_students': stat['total_tracked'] or 0
        }
        topic_stats.append(topic_info)

        if avg_m < 50.0 and (stat['total_tracked'] or 0) > 0:
            alerts.append(f"Chủ đề '{t['title']}' có mức thông thạo trung bình thấp ({avg_m}%). Giảng viên nên dành thêm thời gian củng cố hoặc đăng tài liệu bổ trợ.")

    # Danh sách sinh viên và mức độ tiến độ của từng em
    students_data = query_db(
        """
        SELECT 
            u.id as student_id,
            u.full_name,
            st.student_code,
            AVG(COALESCE(p.mastery_score, 0.0)) as overall_mastery,
            SUM(CASE WHEN p.status = 'MASTERED' OR p.mastery_score >= 80 THEN 1 ELSE 0 END) as mastered_count,
            COUNT(t.id) as total_topics
        FROM enrollments e
        JOIN users u ON e.student_id = u.id
        LEFT JOIN students st ON u.id = st.user_id
        LEFT JOIN course_topics t ON t.course_id = e.course_id
        LEFT JOIN student_topic_progress p ON p.student_id = u.id AND p.topic_id = t.id
        WHERE e.course_id = ?
        GROUP BY u.id
        ORDER BY overall_mastery ASC, u.full_name ASC
        """,
        (course_id,)
    )

    students = []
    for s in students_data:
        m_val = round(s['overall_mastery'] or 0.0, 1)
        if m_val < 50.0:
            status_text = 'Cần hỗ trợ'
            badge_type = 'danger'
        elif m_val < 75.0:
            status_text = 'Đang tiến bộ'
            badge_type = 'warning'
        else:
            status_text = 'Làm chủ tốt'
            badge_type = 'success'

        students.append({
            'student_id': s['student_id'],
            'full_name': s['full_name'],
            'student_code': s['student_code'],
            'overall_mastery': m_val,
            'mastered_count': s['mastered_count'] or 0,
            'total_topics': s['total_topics'] or len(topics),
            'status_text': status_text,
            'badge_type': badge_type
        })

    return {
        'courses': courses,
        'selected_course': selected_course,
        'topic_stats': topic_stats,
        'students': students,
        'alerts': alerts
    }
