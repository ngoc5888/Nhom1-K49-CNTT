import json
from flask import request
from database import execute_db, query_db

# Sensitive keys to scrub from details
SENSITIVE_KEYS = {'password', 'password_hash', 'api_key', 'token', 'secret'}

def sanitize_data(data):
    """Recursively scrub sensitive keys like passwords or API keys from audit logs."""
    if isinstance(data, dict):
        clean = {}
        for k, v in data.items():
            if any(s in k.lower() for s in SENSITIVE_KEYS):
                clean[k] = "[REDACTED]"
            elif isinstance(v, (dict, list)):
                clean[k] = sanitize_data(v)
            else:
                clean[k] = v
        return clean
    elif isinstance(data, list):
        return [sanitize_data(item) for item in data]
    return data

def log_audit(user_id=None, user_email='', user_role='', action='', target_type='', target_id='', details=None, ip_address=None):
    """
    Record a system audit log entry.
    """
    try:
        if ip_address is None:
            try:
                ip_address = request.remote_addr or '127.0.0.1'
            except Exception:
                ip_address = '127.0.0.1'

        details_str = ''
        if details is not None:
            if isinstance(details, (dict, list)):
                clean_details = sanitize_data(details)
                details_str = json.dumps(clean_details, ensure_ascii=False)
            else:
                details_str = str(details)

        execute_db("""
            INSERT INTO audit_logs (user_id, user_email, user_role, action, target_type, target_id, details, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, user_email or '', user_role or '', action, target_type, str(target_id or ''), details_str, ip_address))
    except Exception as e:
        # Non-blocking: audit log failure should not crash core operation
        print(f"[AUDIT_LOG_ERROR] Could not write audit log: {e}")

def get_audit_logs(limit=50, offset=0, action_filter=None, role_filter=None, search=None):
    """Retrieve audit logs with optional filters and pagination."""
    query = "SELECT * FROM audit_logs WHERE 1=1"
    params = []

    if action_filter:
        query += " AND action = ?"
        params.append(action_filter)

    if role_filter:
        query += " AND user_role = ?"
        params.append(role_filter)

    if search:
        query += " AND (user_email LIKE ? OR action LIKE ? OR target_type LIKE ? OR details LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s, s])

    query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    return query_db(query, tuple(params))
