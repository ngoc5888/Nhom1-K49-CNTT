import os
import sys
import subprocess
import time
import re
from database import query_db, execute_db
from services.activity_service import track_activity

# ==========================================
# 1. CODING PROBLEM MANAGEMENT
# ==========================================

def get_coding_problems(course_id=None):
    """Lấy danh sách các bài tập lập trình trực tuyến"""
    sql = """
        SELECT p.*, c.name as course_name, c.code as course_code, u.full_name as author_name,
               (SELECT COUNT(*) FROM coding_test_cases WHERE problem_id = p.id) as test_case_count,
               (SELECT COUNT(*) FROM coding_submissions WHERE problem_id = p.id) as submission_count
        FROM coding_problems p
        JOIN courses c ON p.course_id = c.id
        LEFT JOIN users u ON p.created_by = u.id
        WHERE 1=1
    """
    params = []
    if course_id:
        sql += " AND p.course_id = ?"
        params.append(course_id)
    sql += " ORDER BY p.id DESC"
    return query_db(sql, tuple(params))

def get_coding_problem_detail(problem_id, is_teacher=False):
    """Lấy chi tiết bài tập lập trình kèm test cases (ẩn test case bí mật với sinh viên)"""
    p = query_db("""
        SELECT p.*, c.name as course_name, c.code as course_code
        FROM coding_problems p
        JOIN courses c ON p.course_id = c.id
        WHERE p.id = ?
    """, (problem_id,), one=True)
    if not p:
        return None

    data = dict(p)
    if is_teacher:
        cases = query_db("SELECT * FROM coding_test_cases WHERE problem_id = ? ORDER BY id ASC", (problem_id,))
    else:
        cases = query_db("SELECT id, problem_id, input_data, expected_output, is_hidden, points FROM coding_test_cases WHERE problem_id = ? AND is_hidden = 0 ORDER BY id ASC", (problem_id,))
    data['test_cases'] = [dict(c) for c in cases]
    return data

def create_coding_problem(course_id, title, description, difficulty='EASY', language='python',
                          starter_code='', time_limit_seconds=2.0, memory_limit_mb=128, test_cases=None, created_by=1):
    """Tạo mới một bài tập lập trình kèm bộ test case"""
    if not title or not description:
        return {'success': False, 'message': 'Tiêu đề và đề bài không được để trống.'}

    pid = execute_db("""
        INSERT INTO coding_problems 
        (course_id, title, description, difficulty, language, starter_code, time_limit_seconds, memory_limit_mb, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (course_id, title.strip(), description.strip(), difficulty or 'EASY', language or 'python',
          starter_code or '# Viết mã nguồn của bạn tại đây\n', float(time_limit_seconds or 2.0),
          int(memory_limit_mb or 128), created_by))

    if test_cases:
        for tc in test_cases:
            inp = tc.get('input_data', '').strip()
            exp = tc.get('expected_output', '').strip()
            is_hid = 1 if tc.get('is_hidden') else 0
            pts = float(tc.get('points', 1.0))
            execute_db("""
                INSERT INTO coding_test_cases (problem_id, input_data, expected_output, is_hidden, points)
                VALUES (?, ?, ?, ?, ?)
            """, (pid, inp, exp, is_hid, pts))

    track_activity(created_by, course_id, 'CODING_PROBLEM_CREATE', pid)
    return {'success': True, 'problem_id': pid, 'message': 'Đã tạo bài tập lập trình thành công!'}

def seed_default_coding_problems(course_id, created_by=1):
    """Khởi tạo bài tập lập trình mẫu chuẩn hóa nếu môn học chưa có bài nào"""
    existing = query_db("SELECT COUNT(*) as c FROM coding_problems WHERE course_id = ?", (course_id,), one=True)['c']
    if existing > 0:
        return

    # Bài 1: Tính tổng số chẵn
    p1_desc = """Cho danh sách các số nguyên cách nhau bởi dấu cách.
Hãy tính và in ra màn hình tổng của tất cả các số chẵn trong danh sách. Nếu không có số chẵn nào, in ra 0.

Đầu vào (Input):
Dòng duy nhất chứa các số nguyên cách nhau bởi dấu cách (ví dụ: `1 2 3 4 5 6`).

Đầu ra (Output):
Một số nguyên duy nhất là tổng các số chẵn (ví dụ: `12`)."""

    p1_starter = """# Đọc dữ liệu từ input chuẩn
line = input().strip()
if line:
    nums = [int(x) for x in line.split()]
    # Viết logic tính tổng số chẵn tại đây
    ans = sum(x for x in nums if x % 2 == 0)
    print(ans)
else:
    print(0)
"""
    p1_cases = [
        {'input_data': '1 2 3 4 5 6', 'expected_output': '12', 'is_hidden': 0},
        {'input_data': '1 3 5 7', 'expected_output': '0', 'is_hidden': 0},
        {'input_data': '10 20 30', 'expected_output': '60', 'is_hidden': 1},
        {'input_data': '0 -2 -4 5', 'expected_output': '-6', 'is_hidden': 1}
    ]
    create_coding_problem(course_id, "Tính tổng các số chẵn trong mảng", p1_desc, "EASY", "python", p1_starter, 2.0, 128, p1_cases, created_by)

    # Bài 2: Đảo ngược chuỗi và kiểm tra Palindrome
    p2_desc = """Cho một chuỗi ký tự s. Hãy kiểm tra xem chuỗi đó có phải là chuỗi đối xứng (Palindrome) hay không.
Bỏ qua khoảng trắng và không phân biệt chữ hoa, chữ thường.

Đầu vào (Input):
Chuỗi ký tự s.

Đầu ra (Output):
In ra `YES` nếu đối xứng, ngược lại in ra `NO`."""

    p2_starter = """s = input().strip()
# Chuẩn hóa chuỗi và kiểm tra đối xứng
clean_s = ''.join(c.lower() for c in s if c.isalnum())
if clean_s == clean_s[::-1]:
    print("YES")
else:
    print("NO")
"""
    p2_cases = [
        {'input_data': 'madam', 'expected_output': 'YES', 'is_hidden': 0},
        {'input_data': 'hello', 'expected_output': 'NO', 'is_hidden': 0},
        {'input_data': 'A man a plan a canal Panama', 'expected_output': 'YES', 'is_hidden': 1},
        {'input_data': 'race a car', 'expected_output': 'NO', 'is_hidden': 1}
    ]
    create_coding_problem(course_id, "Kiểm tra chuỗi đối xứng (Palindrome)", p2_desc, "MEDIUM", "python", p2_starter, 2.0, 128, p2_cases, created_by)

# ==========================================
# 2. SECURE SANDBOX EXECUTION ENGINE
# ==========================================

DISALLOWED_TOKENS = [
    r'\bimport\s+os\b',
    r'\bimport\s+sys\b',
    r'\bimport\s+subprocess\b',
    r'\bimport\s+shutil\b',
    r'\bimport\s+socket\b',
    r'\bimport\s+requests\b',
    r'\bimport\s+urllib\b',
    r'\bfrom\s+os\b',
    r'\bfrom\s+sys\b',
    r'\bfrom\s+subprocess\b',
    r'\b__import__\b',
    r'\beval\s*\(',
    r'\bexec\s*\(',
    r'\bopen\s*\('
]

def scan_security(code, language='python'):
    """Quét mã nguồn phát hiện các lời gọi hàm hoặc module nguy hiểm bị cấm trong Sandbox"""
    if language == 'python':
        for pattern in DISALLOWED_TOKENS:
            if re.search(pattern, code):
                return False, f"Vi phạm bảo mật Sandbox: Mã nguồn chứa lệnh hoặc module không được phép thực thi (`{pattern}`)."
    return True, None

def run_python_sandbox(code, test_cases, time_limit_seconds=2.0):
    """
    Thực thi mã nguồn an toàn trong Subprocess Sandbox với giới hạn thời gian và tài nguyên nghiêm ngặt.
    """
    is_safe, sec_msg = scan_security(code, 'python')
    if not is_safe:
        return {
            'status': 'SECURITY_ERROR',
            'score': 0.0,
            'passed_count': 0,
            'total_cases': len(test_cases),
            'execution_time_ms': 0.0,
            'compiler_output': sec_msg,
            'case_results': []
        }

    total_cases = len(test_cases)
    passed_count = 0
    total_time_ms = 0.0
    case_results = []
    overall_status = 'PASSED'
    overall_output = ''

    for idx, tc in enumerate(test_cases):
        inp = tc.get('input_data', '')
        exp = tc.get('expected_output', '').strip()
        is_hidden = bool(tc.get('is_hidden', 0))

        start_t = time.time()
        try:
            # Chạy trong tiến trình con cô lập với cờ -I (isolated mode: ignore environment & user site packages)
            proc = subprocess.run(
                [sys.executable, "-I", "-c", code],
                input=inp,
                text=True,
                capture_output=True,
                timeout=time_limit_seconds
            )
            elapsed_ms = round((time.time() - start_t) * 1000, 1)
            total_time_ms += elapsed_ms

            if proc.returncode != 0:
                err_msg = proc.stderr.strip()[:300]
                case_results.append({
                    'case_num': idx + 1,
                    'passed': False,
                    'status': 'RUNTIME_ERROR',
                    'time_ms': elapsed_ms,
                    'is_hidden': is_hidden,
                    'actual': err_msg if not is_hidden else 'Gặp lỗi thực thi'
                })
                if overall_status == 'PASSED':
                    overall_status = 'RUNTIME_ERROR'
                    overall_output = err_msg
            else:
                actual = proc.stdout.strip()
                if actual == exp:
                    passed_count += 1
                    case_results.append({
                        'case_num': idx + 1,
                        'passed': True,
                        'status': 'PASSED',
                        'time_ms': elapsed_ms,
                        'is_hidden': is_hidden,
                        'actual': actual if not is_hidden else 'Khớp kết quả'
                    })
                else:
                    case_results.append({
                        'case_num': idx + 1,
                        'passed': False,
                        'status': 'WRONG_ANSWER',
                        'time_ms': elapsed_ms,
                        'is_hidden': is_hidden,
                        'actual': actual if not is_hidden else 'Không khớp đáp án',
                        'expected': exp if not is_hidden else 'Ẩn'
                    })
                    if overall_status == 'PASSED':
                        overall_status = 'FAILED'
        except subprocess.TimeoutExpired:
            elapsed_ms = round(time_limit_seconds * 1000, 1)
            total_time_ms += elapsed_ms
            case_results.append({
                'case_num': idx + 1,
                'passed': False,
                'status': 'TIME_LIMIT_EXCEEDED',
                'time_ms': elapsed_ms,
                'is_hidden': is_hidden,
                'actual': f'Quá thời gian thực thi ({time_limit_seconds}s)'
            })
            if overall_status == 'PASSED':
                overall_status = 'TIME_LIMIT_EXCEEDED'
                overall_output = f'Thời gian chạy vượt quá giới hạn {time_limit_seconds} giây.'

    final_score = round((passed_count / total_cases) * 10.0, 2) if total_cases > 0 else 0.0

    return {
        'status': overall_status if passed_count < total_cases else 'PASSED',
        'score': final_score,
        'passed_count': passed_count,
        'total_cases': total_cases,
        'execution_time_ms': round(total_time_ms, 1),
        'compiler_output': overall_output or (f'Đạt {passed_count}/{total_cases} test cases.' if passed_count == total_cases else 'Có test case thất bại.'),
        'case_results': case_results
    }

def submit_coding_solution(problem_id, student_id, code, language='python'):
    """
    Xử lý nộp bài tập lập trình: nạp toàn bộ test cases và thực thi chấm tự động trong Sandbox.
    """
    problem = query_db("SELECT * FROM coding_problems WHERE id = ?", (problem_id,), one=True)
    if not problem:
        return {'success': False, 'message': 'Không tìm thấy bài tập lập trình.'}

    test_cases = query_db("SELECT * FROM coding_test_cases WHERE problem_id = ? ORDER BY id ASC", (problem_id,))
    if not test_cases:
        # Tự động tạo 1 test case cơ bản nếu bài tập chưa có test case nào
        execute_db("""
            INSERT INTO coding_test_cases (problem_id, input_data, expected_output, is_hidden, points)
            VALUES (?, '', '0', 0, 10.0)
        """, (problem_id,))
        test_cases = query_db("SELECT * FROM coding_test_cases WHERE problem_id = ?", (problem_id,))

    # Chạy Sandbox
    res = run_python_sandbox(
        code=code,
        test_cases=[dict(c) for c in test_cases],
        time_limit_seconds=problem['time_limit_seconds'] or 2.0
    )

    # Lưu bản ghi nộp bài
    sub_id = execute_db("""
        INSERT INTO coding_submissions 
        (problem_id, student_id, code, language, status, score, passed_count, total_cases, execution_time_ms, compiler_output)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (problem_id, student_id, code, language or 'python', res['status'], res['score'],
          res['passed_count'], res['total_cases'], res['execution_time_ms'], res['compiler_output']))

    track_activity(student_id, problem['course_id'], 'CODING_SUBMISSION', sub_id, {
        'problem_id': problem_id,
        'status': res['status'],
        'score': res['score']
    })

    res['submission_id'] = sub_id
    res['success'] = True
    return res

def get_student_coding_submissions(problem_id, student_id):
    """Lấy danh sách các lần nộp bài của sinh viên đối với bài tập cụ thể"""
    return query_db("""
        SELECT * FROM coding_submissions 
        WHERE problem_id = ? AND student_id = ?
        ORDER BY submitted_at DESC, id DESC
    """, (problem_id, student_id))
