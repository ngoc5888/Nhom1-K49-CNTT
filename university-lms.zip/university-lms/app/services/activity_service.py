import json
from flask import request
from database import execute_db, query_db

def track_activity(user_id, course_id=None, event_type='', reference_id=None, metadata=None, ip_address=None):
    """
    Record a learning activity event for analytics and adaptive learning.
    """
    try:
        if ip_address is None:
            try:
                ip_address = request.remote_addr or '127.0.0.1'
            except Exception:
                ip_address = '127.0.0.1'

        metadata_str = '{}'
        if metadata is not None:
            if isinstance(metadata, (dict, list)):
                metadata_str = json.dumps(metadata, ensure_ascii=False)
            else:
                metadata_str = json.dumps({'info': str(metadata)}, ensure_ascii=False)

        execute_db("""
            INSERT INTO learning_activities (user_id, course_id, event_type, reference_id, metadata_json, ip_address)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, course_id, event_type, reference_id, metadata_str, ip_address))
    except Exception as e:
        print(f"[ACTIVITY_LOG_ERROR] Could not track activity: {e}")

log_activity = track_activity

def get_user_activities(user_id, limit=20, offset=0):
    """Retrieve recent learning activities for a specific student."""
    return query_db("""
        SELECT la.*, c.name as course_name, c.code as course_code
        FROM learning_activities la
        LEFT JOIN courses c ON la.course_id = c.id
        WHERE la.user_id = ?
        ORDER BY la.created_at DESC
        LIMIT ? OFFSET ?
    """, (user_id, limit, offset))

def get_course_activities(course_id, limit=50):
    """Retrieve activities within a specific course."""
    return query_db("""
        SELECT la.*, u.full_name, u.email, u.role
        FROM learning_activities la
        JOIN users u ON la.user_id = u.id
        WHERE la.course_id = ?
        ORDER BY la.created_at DESC
        LIMIT ?
    """, (course_id, limit))
