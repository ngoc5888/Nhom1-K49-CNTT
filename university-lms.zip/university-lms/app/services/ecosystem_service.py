import json
import re
from datetime import datetime, timedelta
from app.database import query_db, execute_db

# =====================================================================
# 1. SMART CALENDAR SUBSYSTEM
# =====================================================================

def get_user_calendar_events(user_id, role, start_date=None, end_date=None, course_id=None):
    """
    Tổng hợp lịch học, lịch thi, deadline bài tập và lịch cá nhân của người dùng.
    """
    events = []

    # 1.1. Lấy danh sách lớp học phần người dùng tham gia
    if role == 'student':
        course_rows = query_db("""
            SELECT c.id, c.code, c.name, c.schedule_info
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            WHERE e.student_id = ?
        """, (user_id,))
    elif role == 'teacher':
        course_rows = query_db("""
            SELECT id, code, name, schedule_info
            FROM courses
            WHERE teacher_id = ?
        """, (user_id,))
    else: # admin
        course_rows = query_db("SELECT id, code, name, schedule_info FROM courses LIMIT 50")

    course_dict = {c['id']: c for c in course_rows}
    c_ids = list(course_dict.keys())

    # Lọc theo course_id nếu có
    if course_id:
        c_ids = [c for c in c_ids if c == int(course_id)]

    # 1.2. Deadline Bài tập (Assignments)
    if c_ids:
        placeholders = ','.join('?' * len(c_ids))
        assign_query = f"""
            SELECT a.id, a.course_id, a.title, a.description, a.due_date, c.code as course_code, c.name as course_name
            FROM assignments a
            JOIN courses c ON a.course_id = c.id
            WHERE a.course_id IN ({placeholders})
        """
        assignments = query_db(assign_query, tuple(c_ids))
        for a in assignments:
            if a['due_date']:
                due_str = str(a['due_date']).replace(' ', 'T')
                if len(due_str) == 10:
                    due_str += "T23:59:00"
                events.append({
                    'id': f"assign_{a['id']}",
                    'title': f"Hạn nộp: {a['title']} ({a['course_code']})",
                    'description': a['description'] or 'Hạn chót nộp bài tập trên hệ thống LMS.',
                    'start': due_str,
                    'end': due_str,
                    'event_type': 'assignment',
                    'color': '#f43f5e', # rose-500
                    'course_id': a['course_id'],
                    'course_code': a['course_code'],
                    'course_name': a['course_name'],
                    'url': f"/student/assignments" if role == 'student' else f"/teacher/assignments"
                })

    # 1.3. Lịch Thi & Kiểm tra (Exams)
    if c_ids:
        exam_query = f"""
            SELECT ex.id, ex.course_id, ex.title, ex.description, ex.duration_minutes, ex.created_at,
                   c.code as course_code, c.name as course_name
            FROM exams ex
            JOIN courses c ON ex.course_id = c.id
            WHERE ex.course_id IN ({placeholders})
        """
        exams = query_db(exam_query, tuple(c_ids))
        for ex in exams:
            start_t = str(ex['created_at']).replace(' ', 'T')
            events.append({
                'id': f"exam_{ex['id']}",
                'title': f"Kiểm tra: {ex['title']} ({ex['course_code']})",
                'description': f"Thời lượng: {ex['duration_minutes']} phút.",
                'start': start_t,
                'end': start_t,
                'event_type': 'exam',
                'color': '#a855f7', # purple-500
                'course_id': ex['course_id'],
                'course_code': ex['course_code'],
                'course_name': ex['course_name'],
                'url': f"/student/exams" if role == 'student' else f"/teacher/exams"
            })

    # 1.4. Lịch Sự kiện Cá nhân & Bổ sung (calendar_events)
    cal_events = query_db("""
        SELECT ce.*, c.code as course_code, c.name as course_name
        FROM calendar_events ce
        LEFT JOIN courses c ON ce.course_id = c.id
        WHERE ce.user_id = ?
        ORDER BY ce.start_time ASC
    """, (user_id,))
    for ce in cal_events:
        events.append({
            'id': f"custom_{ce['id']}",
            'raw_id': ce['id'],
            'title': ce['title'],
            'description': ce['description'],
            'start': str(ce['start_time']).replace(' ', 'T'),
            'end': str(ce['end_time']).replace(' ', 'T') if ce['end_time'] else str(ce['start_time']).replace(' ', 'T'),
            'event_type': ce['event_type'],
            'color': ce['color'] or '#6366f1',
            'course_id': ce['course_id'],
            'course_code': ce['course_code'] or '',
            'course_name': ce['course_name'] or '',
            'is_all_day': bool(ce['is_all_day']),
            'url': ''
        })

    return events

def create_calendar_event(user_id, title, start_time, end_time=None, course_id=None, description='', event_type='personal', color='#6366f1'):
    """Tạo sự kiện lịch cá nhân mới"""
    if not title or not start_time:
        return {'success': False, 'message': 'Tiêu đề và thời gian bắt đầu không được để trống.'}

    eid = execute_db("""
        INSERT INTO calendar_events (user_id, course_id, title, description, event_type, start_time, end_time, color)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_id, course_id, title.strip(), description.strip(), event_type, start_time, end_time, color))
    return {'success': True, 'event_id': eid, 'message': 'Đã tạo sự kiện lịch thành công!'}

def delete_calendar_event(event_id, user_id):
    """Xóa sự kiện lịch của người dùng"""
    ev = query_db("SELECT id, user_id FROM calendar_events WHERE id = ?", (event_id,), one=True)
    if not ev:
        return {'success': False, 'message': 'Sự kiện không tồn tại.'}
    if ev['user_id'] != user_id:
        return {'success': False, 'message': 'Không có quyền xóa sự kiện này.'}

    execute_db("DELETE FROM calendar_events WHERE id = ?", (event_id,))
    return {'success': True, 'message': 'Đã xóa sự kiện thành công!'}

def export_calendar_ics(user_id, role):
    """Xuất lịch dưới định dạng chuẩn iCalendar (.ics) tương thích Google Calendar & Outlook"""
    events = get_user_calendar_events(user_id, role)
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//University LMS//Smart Learning Ecosystem//VI",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "X-WR-CALNAME:Lịch Học & Sự kiện LMS"
    ]

    for ev in events:
        lines.append("BEGIN:VEVENT")
        # Format start time YYYYMMDDTHHMMSSZ
        try:
            s_clean = re.sub(r'[-:]', '', ev['start'].replace('T', ''))[:15]
            if len(s_clean) == 8:
                s_clean += "T000000"
            lines.append(f"DTSTART:{s_clean}")
            if ev.get('end'):
                e_clean = re.sub(r'[-:]', '', ev['end'].replace('T', ''))[:15]
                if len(e_clean) == 8:
                    e_clean += "T235959"
                lines.append(f"DTEND:{e_clean}")
        except Exception:
            lines.append(f"DTSTART:{datetime.now().strftime('%Y%m%dT080000')}")

        clean_title = ev['title'].replace('\n', ' ')
        clean_desc = (ev.get('description') or '').replace('\n', ' ')
        lines.append(f"SUMMARY:{clean_title}")
        lines.append(f"DESCRIPTION:{clean_desc}")
        lines.append(f"UID:{ev['id']}@lms.university.edu")
        lines.append(f"STATUS:CONFIRMED")
        lines.append("END:VEVENT")

    lines.append("END:VCALENDAR")
    return "\r\n".join(lines)


# =====================================================================
# 2. DISCUSSION FORUM SUBSYSTEM
# =====================================================================

def can_access_course_forum(user_id, course_id, role):
    """Kiểm tra quyền truy cập diễn đàn môn học"""
    if role == 'admin':
        return True
    if role == 'teacher':
        t_course = query_db("SELECT id FROM courses WHERE id = ? AND teacher_id = ?", (course_id, user_id), one=True)
        return t_course is not None
    # student
    enr = query_db("SELECT id FROM enrollments WHERE course_id = ? AND student_id = ?", (course_id, user_id), one=True)
    return enr is not None

def get_course_discussions(course_id, search=None, tag=None):
    """Lấy danh sách các chủ đề thảo luận của lớp học phần"""
    sql = """
        SELECT d.*, u.full_name as author_name, u.role as author_role, u.avatar as author_avatar,
               (SELECT COUNT(*) FROM discussion_comments c WHERE c.discussion_id = d.id) as comment_count,
               (SELECT COUNT(*) FROM discussion_comments c WHERE c.discussion_id = d.id AND c.is_accepted_answer = 1) as has_accepted_answer
        FROM course_discussions d
        JOIN users u ON d.user_id = u.id
        WHERE d.course_id = ?
    """
    params = [course_id]

    if search:
        sql += " AND (d.title LIKE ? OR d.content LIKE ?)"
        s = f"%{search.strip()}%"
        params.extend([s, s])

    sql += " ORDER BY d.is_pinned DESC, d.created_at DESC"
    rows = query_db(sql, tuple(params))

    items = []
    for r in rows:
        d = dict(r)
        try:
            d['tags'] = json.loads(d['tags_json'] or '[]')
        except Exception:
            d['tags'] = []
        if tag and tag not in d['tags']:
            continue
        items.append(d)
    return items

def create_discussion_topic(course_id, user_id, title, content, is_pinned=0, tags=None):
    """Tạo chủ đề thảo luận mới trong lớp học phần"""
    if not title or not content:
        return {'success': False, 'message': 'Tiêu đề và nội dung thảo luận không được để trống.'}

    tags_list = tags if isinstance(tags, list) else ([t.strip() for t in str(tags or '').split(',') if t.strip()])
    did = execute_db("""
        INSERT INTO course_discussions (course_id, user_id, title, content, is_pinned, tags_json)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (course_id, user_id, title.strip(), content.strip(), 1 if is_pinned else 0, json.dumps(tags_list, ensure_ascii=False)))

    return {'success': True, 'discussion_id': did, 'message': 'Đã đăng chủ đề thảo luận thành công!'}

def get_discussion_detail(discussion_id):
    """Lấy chi tiết một chủ đề thảo luận kèm toàn bộ bình luận & phản hồi"""
    disc = query_db("""
        SELECT d.*, u.full_name as author_name, u.role as author_role, u.avatar as author_avatar,
               c.code as course_code, c.name as course_name
        FROM course_discussions d
        JOIN users u ON d.user_id = u.id
        JOIN courses c ON d.course_id = c.id
        WHERE d.id = ?
    """, (discussion_id,), one=True)

    if not disc:
        return None

    # Tăng lượt xem
    execute_db("UPDATE course_discussions SET view_count = view_count + 1 WHERE id = ?", (discussion_id,))

    data = dict(disc)
    data['view_count'] = (disc['view_count'] or 0) + 1
    try:
        data['tags'] = json.loads(data['tags_json'] or '[]')
    except Exception:
        data['tags'] = []

    # Lấy các bình luận
    comments = query_db("""
        SELECT cm.*, u.full_name as author_name, u.role as author_role, u.avatar as author_avatar
        FROM discussion_comments cm
        JOIN users u ON cm.user_id = u.id
        WHERE cm.discussion_id = ?
        ORDER BY cm.is_accepted_answer DESC, cm.upvotes DESC, cm.created_at ASC
    """, (discussion_id,))

    data['comments'] = [dict(c) for c in comments]
    return data

def add_discussion_comment(discussion_id, user_id, content, parent_id=None):
    """Thêm bình luận / câu trả lời cho chủ đề thảo luận"""
    if not content or not content.strip():
        return {'success': False, 'message': 'Nội dung phản hồi không được để trống.'}

    cid = execute_db("""
        INSERT INTO discussion_comments (discussion_id, user_id, content, parent_id)
        VALUES (?, ?, ?, ?)
    """, (discussion_id, user_id, content.strip(), parent_id))

    return {'success': True, 'comment_id': cid, 'message': 'Đã gửi câu trả lời thành công!'}

def toggle_accepted_answer(comment_id, reviewer_id):
    """Đánh dấu hoặc hủy câu trả lời được chấp nhận (hữu ích nhất)"""
    cm = query_db("SELECT id, discussion_id, is_accepted_answer FROM discussion_comments WHERE id = ?", (comment_id,), one=True)
    if not cm:
        return {'success': False, 'message': 'Bình luận không tồn tại.'}

    new_val = 0 if cm['is_accepted_answer'] == 1 else 1
    # Bỏ các accepted cũ trong cùng thảo luận nếu chọn cái mới
    if new_val == 1:
        execute_db("UPDATE discussion_comments SET is_accepted_answer = 0 WHERE discussion_id = ?", (cm['discussion_id'],))

    execute_db("UPDATE discussion_comments SET is_accepted_answer = ? WHERE id = ?", (new_val, comment_id))
    return {'success': True, 'is_accepted': new_val, 'message': 'Đã cập nhật trạng thái câu trả lời hữu ích!'}

def upvote_discussion(discussion_id):
    """Tăng điểm hữu ích (Upvote) cho chủ đề"""
    execute_db("UPDATE course_discussions SET upvotes = upvotes + 1 WHERE id = ?", (discussion_id,))
    v = query_db("SELECT upvotes FROM course_discussions WHERE id = ?", (discussion_id,), one=True)['upvotes']
    return {'success': True, 'upvotes': v}

def toggle_pin_discussion(discussion_id, teacher_id):
    """Giảng viên ghim / bỏ ghim chủ đề thảo luận"""
    d = query_db("SELECT id, is_pinned FROM course_discussions WHERE id = ?", (discussion_id,), one=True)
    if not d:
        return {'success': False, 'message': 'Chủ đề không tồn tại.'}
    new_pin = 0 if d['is_pinned'] == 1 else 1
    execute_db("UPDATE course_discussions SET is_pinned = ? WHERE id = ?", (new_pin, discussion_id))
    return {'success': True, 'is_pinned': new_pin, 'message': 'Đã thay đổi trạng thái ghim thông báo!'}


# =====================================================================
# 3. GROUP WORKSPACE SUBSYSTEM (KHÔNG GIAN LÀM VIỆC NHÓM)
# =====================================================================

def get_course_groups(course_id, current_user_id=None):
    """Lấy danh sách các nhóm học tập của lớp học phần"""
    groups = query_db("""
        SELECT g.*, u.full_name as leader_name,
               (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id) as member_count,
               (SELECT COUNT(*) FROM group_tasks gt WHERE gt.group_id = g.id) as total_tasks,
               (SELECT COUNT(*) FROM group_tasks gt WHERE gt.group_id = g.id AND gt.status = 'DONE') as done_tasks
        FROM course_groups g
        LEFT JOIN users u ON g.leader_id = u.id
        WHERE g.course_id = ?
        ORDER BY g.created_at ASC
    """, (course_id,))

    items = []
    user_group_id = None
    if current_user_id:
        user_m = query_db("""
            SELECT gm.group_id FROM group_members gm
            JOIN course_groups cg ON gm.group_id = cg.id
            WHERE gm.student_id = ? AND cg.course_id = ?
        """, (current_user_id, course_id), one=True)
        if user_m:
            user_group_id = user_m['group_id']

    for g in groups:
        d = dict(g)
        tot = d['total_tasks'] or 0
        done = d['done_tasks'] or 0
        d['progress_pct'] = round((done / tot) * 100, 1) if tot > 0 else 0.0
        d['is_user_member'] = (d['id'] == user_group_id)
        items.append(d)

    return {'groups': items, 'user_group_id': user_group_id}

def create_course_group(course_id, name, description='', leader_id=None, max_members=5, topic_name=''):
    """Tạo nhóm học tập / đồ án mới"""
    if not name or not name.strip():
        return {'success': False, 'message': 'Tên nhóm không được để trống.'}

    # Kiểm tra xem leader_id đã ở nhóm nào trong môn này chưa
    if leader_id:
        existing = query_db("""
            SELECT gm.id FROM group_members gm
            JOIN course_groups cg ON gm.group_id = cg.id
            WHERE gm.student_id = ? AND cg.course_id = ?
        """, (leader_id, course_id), one=True)
        if existing:
            return {'success': False, 'message': 'Bạn đã tham gia một nhóm khác trong lớp học phần này.'}

    gid = execute_db("""
        INSERT INTO course_groups (course_id, name, description, leader_id, max_members, topic_name)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (course_id, name.strip(), description.strip(), leader_id, int(max_members or 5), topic_name.strip()))

    # Tự động gán leader làm thành viên đầu tiên
    if leader_id:
        execute_db("""
            INSERT INTO group_members (group_id, student_id, role)
            VALUES (?, ?, 'leader')
        """, (gid, leader_id))

    return {'success': True, 'group_id': gid, 'message': f"Đã thành lập nhóm '{name}' thành công!"}

def join_course_group(group_id, student_id):
    """Sinh viên tham gia nhóm học tập"""
    group = query_db("SELECT id, course_id, max_members, name FROM course_groups WHERE id = ?", (group_id,), one=True)
    if not group:
        return {'success': False, 'message': 'Nhóm không tồn tại.'}

    # Kiểm tra đã ở nhóm nào khác trong môn này chưa
    existing = query_db("""
        SELECT gm.id FROM group_members gm
        JOIN course_groups cg ON gm.group_id = cg.id
        WHERE gm.student_id = ? AND cg.course_id = ?
    """, (student_id, group['course_id']), one=True)
    if existing:
        return {'success': False, 'message': 'Bạn đã thuộc một nhóm khác trong môn học này.'}

    # Kiểm tra sĩ số nhóm
    cnt = query_db("SELECT COUNT(*) as c FROM group_members WHERE group_id = ?", (group_id,), one=True)['c']
    if cnt >= group['max_members']:
        return {'success': False, 'message': 'Nhóm đã đủ số lượng thành viên tối đa.'}

    execute_db("""
        INSERT INTO group_members (group_id, student_id, role)
        VALUES (?, ?, 'member')
    """, (group_id, student_id))
    return {'success': True, 'message': f"Đã tham gia nhóm '{group['name']}' thành công!"}

def leave_course_group(group_id, student_id):
    """Rời khỏi nhóm học tập"""
    execute_db("DELETE FROM group_members WHERE group_id = ? AND student_id = ?", (group_id, student_id))
    # Nếu là leader, chuyển giao hoặc set NULL
    execute_db("UPDATE course_groups SET leader_id = NULL WHERE id = ? AND leader_id = ?", (group_id, student_id))
    return {'success': True, 'message': 'Đã rời khỏi nhóm thành công!'}

def get_group_detail(group_id, current_user_id=None):
    """Lấy toàn bộ thông tin chi tiết của nhóm: thành viên, nhiệm vụ, tài liệu, tiến độ"""
    group = query_db("""
        SELECT g.*, c.name as course_name, c.code as course_code, u.full_name as leader_name
        FROM course_groups g
        JOIN courses c ON g.course_id = c.id
        LEFT JOIN users u ON g.leader_id = u.id
        WHERE g.id = ?
    """, (group_id,), one=True)

    if not group:
        return None

    data = dict(group)

    # Thành viên
    members = query_db("""
        SELECT gm.*, u.full_name, u.email, u.avatar
        FROM group_members gm
        JOIN users u ON gm.student_id = u.id
        WHERE gm.group_id = ?
        ORDER BY gm.role DESC, gm.joined_at ASC
    """, (group_id,))
    data['members'] = [dict(m) for m in members]

    # Kiểm tra quyền thành viên
    data['is_member'] = any(m['student_id'] == current_user_id for m in data['members'])
    data['is_leader'] = (group['leader_id'] == current_user_id)

    # Nhiệm vụ (Tasks)
    tasks = query_db("""
        SELECT gt.*, u.full_name as assignee_name
        FROM group_tasks gt
        LEFT JOIN users u ON gt.assigned_to = u.id
        WHERE gt.group_id = ?
        ORDER BY gt.due_date ASC, gt.id DESC
    """, (group_id,))
    data['tasks'] = [dict(t) for t in tasks]

    # Tính toán tiến độ
    total_tasks = len(data['tasks'])
    done_tasks = len([t for t in data['tasks'] if t['status'] == 'DONE'])
    data['total_tasks'] = total_tasks
    data['done_tasks'] = done_tasks
    data['progress_pct'] = round((done_tasks / total_tasks) * 100, 1) if total_tasks > 0 else 0.0

    # Tài nguyên (Resources)
    resources = query_db("""
        SELECT gr.*, u.full_name as uploader_name
        FROM group_resources gr
        JOIN users u ON gr.uploaded_by = u.id
        WHERE gr.group_id = ?
        ORDER BY gr.created_at DESC
    """, (group_id,))
    data['resources'] = [dict(r) for r in resources]

    return data

def create_group_task(group_id, title, description='', assigned_to=None, due_date=None, priority='MEDIUM', created_by=None):
    """Tạo và phân công nhiệm vụ trong nhóm"""
    if not title or not title.strip():
        return {'success': False, 'message': 'Tiêu đề nhiệm vụ không được để trống.'}

    tid = execute_db("""
        INSERT INTO group_tasks (group_id, title, description, assigned_to, due_date, priority, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (group_id, title.strip(), description.strip(), assigned_to or None, due_date or None, priority, created_by))
    return {'success': True, 'task_id': tid, 'message': 'Đã thêm nhiệm vụ mới cho nhóm!'}

def update_group_task_status(task_id, status, progress_pct=None):
    """Cập nhật trạng thái nhiệm vụ (TODO, IN_PROGRESS, REVIEW, DONE)"""
    valid_status = ['TODO', 'IN_PROGRESS', 'REVIEW', 'DONE']
    if status not in valid_status:
        return {'success': False, 'message': 'Trạng thái không hợp lệ.'}

    pct = 100.0 if status == 'DONE' else (progress_pct if progress_pct is not None else (50.0 if status == 'IN_PROGRESS' else 0.0))
    execute_db("""
        UPDATE group_tasks
        SET status = ?, progress_pct = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (status, pct, task_id))
    return {'success': True, 'message': 'Đã cập nhật trạng thái nhiệm vụ!'}

def add_group_resource(group_id, uploaded_by, title, resource_type='link', url_or_path='', notes=''):
    """Thêm tài liệu hoặc liên kết chia sẻ cho nhóm"""
    if not title or not url_or_path:
        return {'success': False, 'message': 'Tiêu đề và đường dẫn tài liệu không được để trống.'}

    rid = execute_db("""
        INSERT INTO group_resources (group_id, uploaded_by, title, resource_type, url_or_path, notes)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (group_id, uploaded_by, title.strip(), resource_type, url_or_path.strip(), notes.strip()))
    return {'success': True, 'resource_id': rid, 'message': 'Đã chia sẻ tài nguyên cho nhóm!'}


# =====================================================================
# 4. INTEROPERABILITY SUBSYSTEM (xAPI, QTI 2.1, OPEN BADGES JSON-LD)
# =====================================================================

def generate_xapi_statement(actor_email, actor_name, verb_id, verb_display, object_id, object_name, object_type='activity', result=None):
    """
    Sinh xAPI Statement (Experience API / ADL Tin Can) chuẩn quốc tế.
    Dùng cho Learning Record Store (LRS) và phân tích hành vi học tập.
    """
    statement = {
        "actor": {
            "name": actor_name,
            "mbox": f"mailto:{actor_email}",
            "objectType": "Agent"
        },
        "verb": {
            "id": verb_id,
            "display": {
                "vi": verb_display,
                "en-US": verb_display
            }
        },
        "object": {
            "id": object_id,
            "definition": {
                "name": {
                    "vi": object_name
                },
                "type": f"http://adlnet.gov/expapi/activities/{object_type}"
            },
            "objectType": "Activity"
        },
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    if result:
        statement["result"] = result
    return statement

def export_exam_to_qti_xml(exam_id):
    """
    Xuất đề thi ra định dạng IMS QTI 2.1 (Question and Test Interoperability XML).
    Tương thích với các hệ thống LMS lớn như Canvas, Moodle, Blackboard.
    """
    exam = query_db("SELECT * FROM exams WHERE id = ?", (exam_id,), one=True)
    if not exam:
        return None

    questions = query_db("SELECT * FROM questions WHERE exam_id = ?", (exam_id,))
    xml_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<assessmentItem xmlns="http://www.imsglobal.org/xsd/imsqti_v2p1" identifier="exam_{exam_id}" title="{exam["title"]}">',
        '  <responseDeclaration identifier="RESPONSE" cardinality="single" baseType="identifier"/>',
        '  <outcomeDeclaration identifier="SCORE" cardinality="single" baseType="float"/>',
        f'  <itemBody>',
        f'    <rubricBlock><p>{exam["description"] or "Đề thi chính thức hệ thống LMS"}</p></rubricBlock>'
    ]

    for q in questions:
        opts = []
        try:
            opts = json.loads(q['options_json'] or '[]')
        except Exception:
            opts = ["A", "B", "C", "D"]

        xml_lines.append(f'    <div class="question" id="q_{q["id"]}">')
        xml_lines.append(f'      <prompt>{q["question_text"]}</prompt>')
        xml_lines.append(f'      <choiceInteraction responseIdentifier="RESPONSE_{q["id"]}" shuffle="true" maxChoices="1">')
        for idx, opt in enumerate(opts):
            xml_lines.append(f'        <simpleChoice identifier="CHOICE_{idx}">{opt}</simpleChoice>')
        xml_lines.append('      </choiceInteraction>')
        xml_lines.append('    </div>')

    xml_lines.append('  </itemBody>')
    xml_lines.append('</assessmentItem>')
    return "\n".join(xml_lines)

def export_badge_open_badges_json_ld(student_badge_id, base_url="http://localhost:5000"):
    """
    Xuất Huy hiệu số theo chuẩn W3C Verifiable Credentials / Open Badges 2.0 JSON-LD.
    Có thể xác thực chéo (Cross-verification) trên các nền tảng tuyển dụng toàn cầu.
    """
    sb = query_db("""
        SELECT sb.*, b.code, b.name, b.description, b.criteria, b.icon,
               u.full_name as student_name, u.email as student_email
        FROM student_badges sb
        JOIN digital_badges b ON sb.badge_id = b.id
        JOIN users u ON sb.student_id = u.id
        WHERE sb.id = ?
    """, (student_badge_id,), one=True)

    if not sb:
        return None

    badge_data = {
        "@context": "https://w3id.org/openbadges/v2",
        "type": "Assertion",
        "id": f"{base_url}/api/v1/interop/badges/{sb['id']}",
        "recipient": {
            "type": "email",
            "hashed": False,
            "identity": sb['student_email'],
            "name": sb['student_name']
        },
        "issuedOn": sb['awarded_at'],
        "badge": {
            "type": "BadgeClass",
            "id": f"{base_url}/api/v1/interop/badge-class/{sb['badge_id']}",
            "name": sb['name'],
            "description": sb['description'],
            "image": f"{base_url}/static/badges/{sb['code']}.png",
            "criteria": {
                "narrative": sb['criteria']
            },
            "issuer": {
                "type": "Issuer",
                "id": f"{base_url}",
                "name": "University LMS Smart Learning Ecosystem",
                "url": f"{base_url}"
            }
        },
        "evidence": sb['evidence_text'],
        "verification": {
            "type": "HostedBadge"
        }
    }
    return badge_data
