import json
from database import query_db
from services.predictive_service import scan_and_sync_course_risks, get_at_risk_students

def get_admin_learning_analytics(academic_year=None, semester=None, department_id=None,
                                major_id=None, subject_id=None, student_class_id=None, course_id=None):
    """
    Computes real training & learning analytics based on actual database records.
    """
    # Base filter builder for courses
    c_where = ["1=1"]
    c_params = []

    if academic_year:
        c_where.append("c.academic_year = ?")
        c_params.append(academic_year)
    if semester:
        c_where.append("c.semester LIKE ?")
        c_params.append(f"%{semester}%")
    if department_id:
        c_where.append("sub.department_id = ?")
        c_params.append(int(department_id))
    if subject_id:
        c_where.append("c.subject_id = ?")
        c_params.append(int(subject_id))
    if course_id:
        c_where.append("c.id = ?")
        c_params.append(int(course_id))

    c_clause = " AND ".join(c_where)

    # 1. Group A: Overview
    total_students = query_db("SELECT COUNT(*) as c FROM users WHERE role = 'student' AND is_active = 1", one=True)['c']
    total_teachers = query_db("SELECT COUNT(*) as c FROM users WHERE role = 'teacher' AND is_active = 1", one=True)['c']

    courses_query = f"""
        SELECT c.id, c.name, c.code, c.subject_id, c.teacher_id, c.semester, c.academic_year, sub.name as subject_name
        FROM courses c
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE {c_clause}
    """
    filtered_courses = query_db(courses_query, tuple(c_params))
    total_courses_count = len(filtered_courses)
    course_ids = [c['id'] for c in filtered_courses]

    if course_ids:
        c_in = f"({','.join(map(str, course_ids))})"
        total_enrollments = query_db(f"SELECT COUNT(*) as c FROM enrollments WHERE course_id IN {c_in}", one=True)['c']
        active_learners = query_db(f"SELECT COUNT(DISTINCT student_id) as c FROM enrollments WHERE course_id IN {c_in}", one=True)['c']

        # Completion rate: students with grades >= 4.0 vs total graded
        graded_count = query_db(f"SELECT COUNT(*) as c FROM grades WHERE course_id IN {c_in}", one=True)['c']
        passed_count = query_db(f"SELECT COUNT(*) as c FROM grades WHERE course_id IN {c_in} AND letter_grade != 'F'", one=True)['c']
        completion_rate = round((passed_count / graded_count * 100), 1) if graded_count > 0 else 0.0

        # 2. Group B: Academic Results & Distribution
        grades_rows = query_db(f"SELECT total_score, letter_grade FROM grades WHERE course_id IN {c_in}")
        scores = [g['total_score'] for g in grades_rows if g['total_score'] is not None and g['total_score'] > 0]
        avg_score = round(sum(scores) / len(scores), 2) if scores else 0.0

        letter_dist = {'A': 0, 'B+': 0, 'B': 0, 'C+': 0, 'C': 0, 'D+': 0, 'D': 0, 'F': 0}
        for g in grades_rows:
            lg = g['letter_grade']
            if lg in letter_dist:
                letter_dist[lg] += 1

        pass_rate = round((passed_count / graded_count * 100), 1) if graded_count > 0 else 0.0
        fail_rate = round((100.0 - pass_rate), 1) if graded_count > 0 else 0.0

        # Term comparison
        term_compare = query_db(f"""
            SELECT c.semester, ROUND(AVG(g.total_score), 2) as avg_score, COUNT(g.id) as count
            FROM grades g
            JOIN courses c ON g.course_id = c.id
            WHERE c.id IN {c_in} AND g.total_score > 0
            GROUP BY c.semester
            ORDER BY c.semester
            LIMIT 5
        """)

        # 3. Group C: Learning Activities
        material_access_count = query_db(f"""
            SELECT COUNT(*) as c FROM learning_activities
            WHERE course_id IN {c_in} AND event_type IN ('VIEW_COURSE', 'DOWNLOAD_MATERIAL')
        """, one=True)['c']

        total_assignments = query_db(f"SELECT COUNT(*) as c FROM assignments WHERE course_id IN {c_in}", one=True)['c']
        submitted_assignments = query_db(f"""
            SELECT COUNT(*) as c FROM submissions s
            JOIN assignments a ON s.assignment_id = a.id
            WHERE a.course_id IN {c_in}
        """, one=True)['c']
        submission_rate = round((submitted_assignments / (total_assignments * active_learners) * 100), 1) if (total_assignments * active_learners) > 0 else 0.0

        exam_attempts = query_db(f"""
            SELECT COUNT(*) as c FROM exam_results er
            JOIN exams ex ON er.exam_id = ex.id
            WHERE ex.course_id IN {c_in}
        """, one=True)['c']

        # 4. Group D: Course & Subject Risk Analysis
        low_score_subjects = query_db(f"""
            SELECT sub.name as subject_name, sub.code as subject_code,
                   ROUND(AVG(g.total_score), 2) as avg_score,
                   SUM(CASE WHEN g.letter_grade = 'F' THEN 1 ELSE 0 END) as fail_count,
                   COUNT(g.id) as total_graded
            FROM grades g
            JOIN courses c ON g.course_id = c.id
            JOIN subjects sub ON c.subject_id = sub.id
            WHERE c.id IN {c_in}
            GROUP BY sub.id
            HAVING total_graded >= 3
            ORDER BY avg_score ASC
            LIMIT 5
        """)

    else:
        total_enrollments = 0
        active_learners = 0
        completion_rate = 0.0
        avg_score = 0.0
        letter_dist = {'A': 0, 'B+': 0, 'B': 0, 'C+': 0, 'C': 0, 'D+': 0, 'D': 0, 'F': 0}
        pass_rate = 0.0
        fail_rate = 0.0
        term_compare = []
        material_access_count = 0
        total_assignments = 0
        submitted_assignments = 0
        submission_rate = 0.0
        exam_attempts = 0
        low_score_subjects = []

    # Question difficulty analysis across exams
    hard_questions = query_db("""
        SELECT q.id, q.question_text, ex.title as exam_name, c.name as course_name, q.exam_id
        FROM questions q
        JOIN exams ex ON q.exam_id = ex.id
        JOIN courses c ON ex.course_id = c.id
        LIMIT 5
    """)

    # At-risk counts
    scan_and_sync_course_risks()
    at_risk_list = get_at_risk_students(limit=10)
    total_needs_support = query_db("SELECT COUNT(*) as c FROM student_interventions WHERE risk_level = 'NEEDS_SUPPORT'", one=True)['c']
    total_monitoring = query_db("SELECT COUNT(*) as c FROM student_interventions WHERE risk_level = 'MONITORING'", one=True)['c']

    # AI Insights generation
    ai_insights = generate_ai_insights({
        "total_courses": total_courses_count,
        "total_enrollments": total_enrollments,
        "avg_score": avg_score,
        "pass_rate": pass_rate,
        "fail_rate": fail_rate,
        "needs_support_count": total_needs_support,
        "monitoring_count": total_monitoring,
        "low_score_subjects": [dict(s) for s in low_score_subjects]
    })

    return {
        "overview": {
            "total_students": total_students,
            "total_teachers": total_teachers,
            "total_courses": total_courses_count,
            "total_enrollments": total_enrollments,
            "active_learners": active_learners,
            "completion_rate": completion_rate
        },
        "academic": {
            "avg_score": avg_score,
            "pass_rate": pass_rate,
            "fail_rate": fail_rate,
            "letter_dist": letter_dist,
            "term_compare": [dict(t) for t in term_compare]
        },
        "activities": {
            "material_access_count": material_access_count,
            "total_assignments": total_assignments,
            "submitted_assignments": submitted_assignments,
            "submission_rate": submission_rate,
            "exam_attempts": exam_attempts
        },
        "risk_analysis": {
            "low_score_subjects": [dict(s) for s in low_score_subjects],
            "hard_questions": [dict(q) for q in hard_questions],
            "needs_support_count": total_needs_support,
            "monitoring_count": total_monitoring,
            "at_risk_list": at_risk_list
        },
        "ai_insights": ai_insights
    }

def get_teacher_learning_analytics(teacher_id, course_id=None):
    """
    Analytics specifically for courses taught by a given teacher.
    """
    my_courses = query_db("SELECT id, name, code, semester, academic_year FROM courses WHERE teacher_id = ? ORDER BY id DESC", (teacher_id,))
    my_course_ids = [c['id'] for c in my_courses]

    if not my_course_ids:
        return {
            "my_courses": [],
            "selected_course": None,
            "stats": {},
            "grades_dist": {},
            "at_risk_students": [],
            "ai_insights": []
        }

    selected_cid = int(course_id) if course_id and int(course_id) in my_course_ids else my_course_ids[0]
    selected_course = query_db("SELECT c.*, sub.name as subject_name, sub.credits FROM courses c JOIN subjects sub ON c.subject_id = sub.id WHERE c.id = ?", (selected_cid,), one=True)

    # Course stats
    total_enrolled = query_db("SELECT COUNT(*) as c FROM enrollments WHERE course_id = ?", (selected_cid,), one=True)['c']
    total_assignments = query_db("SELECT COUNT(*) as c FROM assignments WHERE course_id = ?", (selected_cid,), one=True)['c']
    total_submissions = query_db("""
        SELECT COUNT(*) as c FROM submissions s JOIN assignments a ON s.assignment_id = a.id WHERE a.course_id = ?
    """, (selected_cid,), one=True)['c']

    grades = query_db("SELECT * FROM grades WHERE course_id = ?", (selected_cid,))
    scores = [g['total_score'] for g in grades if g['total_score'] is not None and g['total_score'] > 0]
    avg_score = round(sum(scores) / len(scores), 2) if scores else 0.0

    letter_dist = {'A': 0, 'B+': 0, 'B': 0, 'C+': 0, 'C': 0, 'D+': 0, 'D': 0, 'F': 0}
    for g in grades:
        lg = g['letter_grade']
        if lg in letter_dist:
            letter_dist[lg] += 1

    passed_count = sum(1 for g in grades if g['letter_grade'] != 'F')
    pass_rate = round((passed_count / len(grades) * 100), 1) if grades else 0.0

    # At-risk students in this course
    scan_and_sync_course_risks(selected_cid)
    at_risk_students = get_at_risk_students(course_id=selected_cid)

    # Questions analysis
    exam_questions = query_db("""
        SELECT q.*, ex.title as exam_title
        FROM questions q
        JOIN exams ex ON q.exam_id = ex.id
        WHERE ex.course_id = ?
    """, (selected_cid,))

    # AI teacher insights
    ai_insights = generate_ai_insights({
        "course_name": selected_course['name'],
        "total_enrolled": total_enrolled,
        "avg_score": avg_score,
        "pass_rate": pass_rate,
        "needs_support_count": sum(1 for s in at_risk_students if s['risk_level'] == 'NEEDS_SUPPORT'),
        "monitoring_count": sum(1 for s in at_risk_students if s['risk_level'] == 'MONITORING'),
        "submission_rate": round((total_submissions / (total_assignments * total_enrolled) * 100), 1) if (total_assignments * total_enrolled) > 0 else 0.0
    }, is_teacher=True)

    return {
        "my_courses": [dict(c) for c in my_courses],
        "selected_course": dict(selected_course),
        "stats": {
            "total_enrolled": total_enrolled,
            "total_assignments": total_assignments,
            "total_submissions": total_submissions,
            "avg_score": avg_score,
            "pass_rate": pass_rate
        },
        "grades_dist": letter_dist,
        "at_risk_students": at_risk_students,
        "exam_questions": [dict(q) for q in exam_questions],
        "ai_insights": ai_insights
    }

def generate_ai_insights(data, is_teacher=False):
    """
    Generate professional, transparent AI analytical insights strictly from real metrics.
    """
    insights = []
    if is_teacher:
        c_name = data.get("course_name", "Lớp học phần")
        avg = data.get("avg_score", 0.0)
        pass_rate = data.get("pass_rate", 0.0)
        ns_count = data.get("needs_support_count", 0)
        mon_count = data.get("monitoring_count", 0)
        sub_rate = data.get("submission_rate", 0.0)

        if avg >= 7.0:
            insights.append({
                "type": "success",
                "icon": "fa-chart-line",
                "title": "Hiệu quả học tập tích cực",
                "content": f"Điểm trung bình lớp '{c_name}' đạt mức khá giỏi ({avg}/10). Tỷ lệ qua môn đạt {pass_rate}%."
            })
        else:
            insights.append({
                "type": "warning",
                "icon": "fa-triangle-exclamation",
                "title": "Cần chú ý củng cố kiến thức",
                "content": f"Điểm trung bình lớp hiện tại là {avg}/10. Giảng viên nên dành thời gian giải đáp các bài tập thực hành khó trước kỳ thi cuối kỳ."
            })

        if ns_count > 0:
            insights.append({
                "type": "danger",
                "icon": "fa-user-clock",
                "title": f"Cảnh báo: {ns_count} sinh viên có nguy cơ cao",
                "content": f"Có {ns_count} sinh viên đang có điểm dưới 4.0 hoặc bỏ lỡ bài tập. Đề xuất: Giảng viên nhắn tin trao đổi trực tiếp hoặc phụ đạo thêm."
            })
        elif mon_count > 0:
            insights.append({
                "type": "info",
                "icon": "fa-eye",
                "title": f"{mon_count} sinh viên cần theo dõi tiến độ",
                "content": f"Một số sinh viên có dấu hiệu chững lại ở điểm giữa kỳ hoặc thiếu 1 bài nộp. Hãy gửi lời nhắc nhở đến các em."
            })

        if sub_rate < 70.0:
            insights.append({
                "type": "warning",
                "icon": "fa-file-signature",
                "title": "Tỷ lệ nộp bài tập chưa cao",
                "content": f"Tỷ lệ hoàn thành bài tập mới đạt {sub_rate}%. Cần gia hạn hạn chót hoặc giải thích rõ yêu cầu đề bài hơn."
            })
    else:
        avg = data.get("avg_score", 0.0)
        pass_rate = data.get("pass_rate", 0.0)
        fail_rate = data.get("fail_rate", 0.0)
        ns_count = data.get("needs_support_count", 0)
        low_subjs = data.get("low_score_subjects", [])

        insights.append({
            "type": "primary",
            "icon": "fa-university",
            "title": "Tổng quan chất lượng đào tạo",
            "content": f"Toàn trường có {data.get('total_courses', 0)} lớp học phần với {data.get('total_enrollments', 0)} lượt ghi danh. Điểm trung bình đạt {avg}/10, tỷ lệ đạt học phần đạt {pass_rate}%."
        })

        if ns_count > 0:
            insights.append({
                "type": "warning",
                "icon": "fa-users-gear",
                "title": "Chỉ số can thiệp học vụ",
                "content": f"Hệ thống phát hiện {ns_count} lượt sinh viên cần can thiệp hỗ trợ sớm (điểm < 4.0 hoặc vắng nộp bài). Khuyến nghị gửi danh sách cho Khoa chuyên môn."
            })

        if low_subjs:
            worst = low_subjs[0]
            insights.append({
                "type": "info",
                "icon": "fa-book-open-reader",
                "title": "Phân tích môn học có kết quả thấp",
                "content": f"Môn '{worst['subject_name']}' đang có điểm trung bình thấp nhất ({worst['avg_score']}/10) với {worst['fail_count']} lượt điểm F. Cần xem xét lại cấu trúc đề cương hoặc tăng cường trợ giảng."
            })

    return insights
