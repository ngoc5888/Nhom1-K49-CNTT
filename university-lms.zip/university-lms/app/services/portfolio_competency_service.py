import json
from datetime import datetime
from database import query_db, execute_db
from services.activity_service import track_activity

# ==========================================
# 1. COMPETENCY CATALOG & MAPPINGS
# ==========================================

def seed_default_competencies_if_empty():
    """Khởi tạo danh mục chuẩn năng lực theo chuẩn CNTT và Kỹ năng chung"""
    count = query_db("SELECT COUNT(*) as c FROM competencies", one=True)['c']
    if count > 0:
        return

    default_skills = [
        # Nhóm CNTT
        ("SKILL_PROG", "Lập trình & Thuật toán", "CNTT", "Viết mã nguồn chuẩn mực, cấu trúc dữ liệu, giải thuật và kiểm thử đơn vị.", 5, "Giải quyết được các bài toán lập trình và test cases trong Sandbox.", "fa-code"),
        ("SKILL_DATA", "Phân tích dữ liệu & Khai phá", "CNTT", "Xử lý số liệu thống kê, trực quan hóa và trích xuất tri thức từ dữ liệu lớn.", 5, "Đạt điểm bài tập phân tích dữ liệu và mô hình hóa.", "fa-chart-pie"),
        ("SKILL_DB", "Thiết kế & Tối ưu Cơ sở dữ liệu", "CNTT", "Mô hình ERD, chuẩn hóa lược đồ 3NF, viết truy vấn SQL nâng cao và indexing.", 5, "Thiết kế CSDL đạt chuẩn và điểm kiểm tra CSDL >= 7.5.", "fa-database"),
        ("SKILL_WEB", "Phát triển Ứng dụng Web", "CNTT", "Kiến trúc hệ thống Web, RESTful API, responsive UI và xác thực an toàn.", 5, "Hoàn thành đồ án web và triển khai ứng dụng.", "fa-globe"),
        ("SKILL_TEST", "Kiểm thử Phần mềm & QA", "CNTT", "Thiết kế bộ kiểm thử test case, kiểm thử tự động và đảm bảo chất lượng phần mềm.", 5, "Viết và thực thi thành công bộ test case cho đồ án.", "fa-check-double"),
        ("SKILL_SEC", "An toàn thông tin & Bảo mật", "CNTT", "Nguyên lý bảo mật mạng, chống injection, mã hóa và phân quyền RBAC.", 5, "Vận dụng tốt các nguyên tắc bảo mật trong mã nguồn.", "fa-shield-halved"),
        ("SKILL_PROBLEM_SOLVING", "Giải quyết vấn đề Kỹ thuật", "CNTT", "Tư duy logic, phân tích nguyên nhân gốc rễ và tối ưu hóa giải pháp.", 5, "Vượt qua các câu hỏi tình huống mức HARD trong CAT.", "fa-lightbulb"),

        # Nhóm Kỹ năng chung
        ("SKILL_COMM", "Giao tiếp Chuyên nghiệp", "Kỹ năng chung", "Trình bày ý tưởng kỹ thuật rõ ràng, viết báo cáo mạch lạc và lắng nghe tích cực.", 5, "Điểm trình bày trong Rubric đạt mức Tốt trở lên.", "fa-comments"),
        ("SKILL_TEAM", "Làm việc nhóm & Phối hợp", "Kỹ năng chung", "Phối hợp hiệu quả, phân công trách nhiệm và quản lý phiên bản chung.", 5, "Hoàn thành các giai đoạn đồ án nhóm đúng tiến độ.", "fa-users"),
        ("SKILL_PRES", "Thuyết trình & Báo cáo", "Kỹ năng chung", "Tự tin báo cáo sản phẩm, sử dụng slide trực quan và phản biện học thuật.", 5, "Báo cáo nghiệm thu đồ án đạt kết quả cao.", "fa-person-chalkboard"),
        ("SKILL_CRIT", "Tư duy Phản biện & Đổi mới", "Kỹ năng chung", "Phân tích đa chiều, đặt câu hỏi logic và đề xuất sáng kiến cải tiến.", 5, "Đưa ra giải pháp tối ưu trong các bài tập mở rộng.", "fa-brain"),
        ("SKILL_TIME", "Quản lý Thời gian & Tập trung", "Kỹ năng chung", "Lập kế hoạch cá nhân, duy trì chuỗi học Pomodoro và nộp bài đúng hạn.", 5, "Duy trì chuỗi học tập (Streak) và nộp bài trước deadline.", "fa-clock")
    ]

    for code, name, cat, desc, max_lvl, crit, icon in default_skills:
        execute_db("""
            INSERT OR IGNORE INTO competencies (code, name, category, description, max_level, criteria, icon)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (code, name, cat, desc, max_lvl, crit, icon))

def get_all_competencies(category=None):
    """Lấy danh sách các kỹ năng chuẩn hóa"""
    seed_default_competencies_if_empty()
    sql = "SELECT * FROM competencies WHERE 1=1"
    params = []
    if category:
        sql += " AND category = ?"
        params.append(category)
    sql += " ORDER BY category ASC, id ASC"
    return query_db(sql, tuple(params))

def create_competency(code, name, category, description='', max_level=5, criteria='', icon='fa-award'):
    """Tạo mới một chuẩn kỹ năng"""
    if not code or not name:
        return {'success': False, 'message': 'Mã và tên kỹ năng không được để trống.'}

    clean_code = code.strip().upper()
    existing = query_db("SELECT id FROM competencies WHERE code = ?", (clean_code,), one=True)
    if existing:
        return {'success': True, 'competency_id': existing['id'], 'message': 'Kỹ năng đã tồn tại.'}

    cid = execute_db("""
        INSERT INTO competencies (code, name, category, description, max_level, criteria, icon)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (clean_code, name.strip(), category, description.strip(), int(max_level or 5), criteria.strip(), icon or 'fa-award'))
    return {'success': True, 'competency_id': cid, 'message': 'Đã thêm kỹ năng chuẩn hóa thành công!'}

def map_competency_to_target(competency_id, target_type, target_id, passing_score=7.0):
    """Liên kết kỹ năng vào môn học / bài tập / đề thi"""
    mid = execute_db("""
        INSERT INTO competency_mappings (competency_id, target_type, target_id, passing_score)
        VALUES (?, ?, ?, ?)
    """, (competency_id, target_type, target_id, float(passing_score or 7.0)))
    return {'success': True, 'mapping_id': mid, 'message': 'Đã liên kết kỹ năng thành công!'}

def get_competency_mappings(target_type=None, target_id=None):
    """Lấy danh sách các liên kết kỹ năng"""
    sql = """
        SELECT m.*, c.code as comp_code, c.name as comp_name, c.category as comp_category, c.icon as comp_icon
        FROM competency_mappings m
        JOIN competencies c ON m.competency_id = c.id
        WHERE 1=1
    """
    params = []
    if target_type:
        sql += " AND m.target_type = ?"
        params.append(target_type)
    if target_id:
        sql += " AND m.target_id = ?"
        params.append(target_id)
    return query_db(sql, tuple(params))

# ==========================================
# 2. STUDENT COMPETENCIES PROFILE & RADAR
# ==========================================

def get_student_competency_profile(student_id):
    """
    Xây dựng Bản đồ Năng lực cá nhân của sinh viên dựa trên:
    - Bảng `student_competencies`
    - Điểm số học phần (`grades`)
    - Điểm bài tập & Rubric (`submissions`)
    - Điểm bài kiểm tra (`exam_results`)
    - Kết quả lập trình trực tuyến (`coding_submissions`)
    - Chuỗi học tập Pomodoro (`study_sessions`)
    """
    seed_default_competencies_if_empty()
    all_competencies = get_all_competencies()

    # Lấy các bản ghi đã được ghi nhận hoặc xác minh
    comp_records = query_db("""
        SELECT sc.*, c.code, c.name, c.category, c.icon, c.description, c.criteria
        FROM student_competencies sc
        JOIN competencies c ON sc.competency_id = c.id
        WHERE sc.student_id = ?
    """, (student_id,))
    comp_map = {r['competency_id']: dict(r) for r in comp_records}

    # Lấy dữ liệu học tập thực tế của sinh viên để đánh giá tự động có căn cứ
    avg_grade = query_db("SELECT AVG(total_score) as avg_s FROM grades WHERE student_id = ?", (student_id,), one=True)['avg_s'] or 0.0
    passed_courses_cnt = query_db("SELECT COUNT(*) as c FROM grades WHERE student_id = ? AND total_score >= 5.0", (student_id,), one=True)['c']
    good_courses_cnt = query_db("SELECT COUNT(*) as c FROM grades WHERE student_id = ? AND total_score >= 7.5", (student_id,), one=True)['c']
    coding_passed_cnt = query_db("SELECT COUNT(*) as c FROM coding_submissions WHERE student_id = ? AND status = 'PASSED'", (student_id,), one=True)['c']
    high_submissions_cnt = query_db("SELECT COUNT(*) as c FROM submissions WHERE student_id = ? AND score >= 8.0", (student_id,), one=True)['c']
    study_streak_days = query_db("SELECT COUNT(DISTINCT DATE(created_at)) as c FROM study_sessions WHERE student_id = ?", (student_id,), one=True)['c'] or 0

    profile_items = []
    achieved_count = 0
    in_progress_count = 0
    needs_improvement_count = 0

    cat_scores = {'CNTT': [], 'Kỹ năng chung': [], 'Chuyên ngành': []}

    for comp in all_competencies:
        cid = comp['id']
        code = comp['code']
        cat = comp['category']

        if cid in comp_map:
            c_data = comp_map[cid]
            lvl = c_data['current_level']
            pct = c_data['progress_pct']
            status = c_data['status']
            ev_list = json.loads(c_data['evidence_json'] or '[]')
            verified = bool(c_data['verified_by'])
        else:
            # Tự động tính toán mức độ năng lực ban đầu dựa trên dữ liệu học tập thực
            lvl = 1
            pct = 20.0
            status = 'NEEDS_IMPROVEMENT'
            ev_list = []
            verified = False

            if code == 'SKILL_PROG':
                if coding_passed_cnt >= 2 or good_courses_cnt >= 2:
                    lvl, pct, status = 4, 85.0, 'ACHIEVED'
                    ev_list.append(f"Vượt qua {coding_passed_cnt} bài toán lập trình Sandbox điểm tuyệt đối.")
                elif coding_passed_cnt >= 1 or passed_courses_cnt >= 1:
                    lvl, pct, status = 3, 60.0, 'IN_PROGRESS'
                    ev_list.append("Đã hoàn thành bài tập lập trình cơ bản.")

            elif code == 'SKILL_DB':
                if good_courses_cnt >= 1 or avg_grade >= 7.5:
                    lvl, pct, status = 4, 80.0, 'ACHIEVED'
                    ev_list.append(f"Điểm tổng kết học phần cơ sở dữ liệu đạt chuẩn: {round(avg_grade, 1)}/10.")
                elif passed_courses_cnt >= 1:
                    lvl, pct, status = 2, 50.0, 'IN_PROGRESS'

            elif code in ['SKILL_WEB', 'SKILL_DATA', 'SKILL_TEST', 'SKILL_SEC']:
                if high_submissions_cnt >= 2 or good_courses_cnt >= 2:
                    lvl, pct, status = 3, 70.0, 'IN_PROGRESS'
                    ev_list.append("Có bài tập và sản phẩm thực hành đạt từ 8.0 trở lên.")
                elif passed_courses_cnt >= 1:
                    lvl, pct, status = 2, 45.0, 'IN_PROGRESS'

            elif code == 'SKILL_TIME':
                if study_streak_days >= 3:
                    lvl, pct, status = 4, 80.0, 'ACHIEVED'
                    ev_list.append(f"Duy trì thói quen học tập liên tục {study_streak_days} ngày qua Pomodoro.")
                elif study_streak_days >= 1:
                    lvl, pct, status = 2, 50.0, 'IN_PROGRESS'

            elif code in ['SKILL_COMM', 'SKILL_TEAM', 'SKILL_PRES']:
                if high_submissions_cnt >= 1:
                    lvl, pct, status = 3, 65.0, 'IN_PROGRESS'
                    ev_list.append("Hoàn thành báo cáo đồ án và nộp bài đúng tiến độ.")
                else:
                    lvl, pct, status = 2, 40.0, 'NEEDS_IMPROVEMENT'

            else:
                if avg_grade >= 8.0:
                    lvl, pct, status = 3, 65.0, 'IN_PROGRESS'
                else:
                    lvl, pct, status = 1, 30.0, 'NEEDS_IMPROVEMENT'

            # Lưu bản ghi ban đầu
            execute_db("""
                INSERT OR IGNORE INTO student_competencies 
                (student_id, competency_id, current_level, status, progress_pct, evidence_json)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (student_id, cid, lvl, status, pct, json.dumps(ev_list, ensure_ascii=False)))

        if status == 'ACHIEVED':
            achieved_count += 1
        elif status == 'IN_PROGRESS':
            in_progress_count += 1
        else:
            needs_improvement_count += 1

        cat_scores.setdefault(cat, []).append(pct)

        profile_items.append({
            'competency_id': cid,
            'code': code,
            'name': comp['name'],
            'category': cat,
            'description': comp['description'],
            'icon': comp['icon'],
            'level': lvl,
            'current_level': lvl,
            'max_level': comp['max_level'],
            'progress_pct': pct,
            'status': status,
            'evidence': ev_list,
            'evidence_list': ev_list,
            'verified': verified
        })

    # Tính điểm radar trung bình theo từng nhóm kỹ năng
    avg_scores = [round(sum(vals)/len(vals), 1) if vals else 0.0 for vals in cat_scores.values()]
    radar_data = {
        'labels': list(cat_scores.keys()),
        'scores': avg_scores,
        'values': avg_scores,
        'target': [100.0] * len(cat_scores)
    }

    return {
        'items': profile_items,
        'summary': {
            'total': len(all_competencies),
            'achieved': achieved_count,
            'in_progress': in_progress_count,
            'needs_improvement': needs_improvement_count,
            'overall_score': round(sum(p['progress_pct'] for p in profile_items) / len(profile_items), 1) if profile_items else 0.0
        },
        'radar_data': radar_data
    }

def update_or_verify_student_competency(student_id, competency_id, level, status, evidence_text=None, verified_by=None):
    """Giảng viên hoặc Admin cập nhật, xác thực minh chứng năng lực cho sinh viên"""
    comp = query_db("SELECT id, name FROM competencies WHERE id = ?", (competency_id,), one=True)
    if not comp:
        return {'success': False, 'message': 'Không tìm thấy kỹ năng chỉ định.'}

    level = int(level or 1)
    status = status if status in ['ACHIEVED', 'IN_PROGRESS', 'NEEDS_IMPROVEMENT'] else 'IN_PROGRESS'
    pct = 100.0 if status == 'ACHIEVED' else (60.0 if status == 'IN_PROGRESS' else 30.0)

    # Lấy minh chứng hiện có
    curr = query_db("SELECT evidence_json FROM student_competencies WHERE student_id = ? AND competency_id = ?", (student_id, competency_id), one=True)
    ev_list = json.loads(curr['evidence_json'] or '[]') if curr else []
    if evidence_text and evidence_text.strip():
        ev_list.append(evidence_text.strip())

    execute_db("""
        INSERT INTO student_competencies 
        (student_id, competency_id, current_level, status, progress_pct, evidence_json, verified_by, verified_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(student_id, competency_id) DO UPDATE SET
            current_level = excluded.current_level,
            status = excluded.status,
            progress_pct = excluded.progress_pct,
            evidence_json = excluded.evidence_json,
            verified_by = excluded.verified_by,
            verified_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
    """, (student_id, competency_id, level, status, pct, json.dumps(ev_list, ensure_ascii=False), verified_by))

    if verified_by:
        track_activity(verified_by, None, 'COMPETENCY_VERIFIED', competency_id, {'student_id': student_id, 'status': status})

    return {'success': True, 'status': status, 'level': level, 'message': f"Đã xác thực và cập nhật kỹ năng '{comp['name']}' thành công!"}

# ==========================================
# 3. DIGITAL PORTFOLIO MANAGEMENT
# ==========================================

def get_or_create_student_portfolio(student_id):
    """Lấy hoặc tự động khởi tạo Portfolio số cho sinh viên"""
    port = query_db("SELECT * FROM student_portfolios WHERE student_id = ?", (student_id,), one=True)
    if not port:
        user = query_db("SELECT full_name, email FROM users WHERE id = ?", (student_id,), one=True)
        execute_db("""
            INSERT OR IGNORE INTO student_portfolios (student_id, headline, bio, is_public)
            VALUES (?, 'Sinh viên CNTT nhiệt huyết & sáng tạo', 'Chào mừng bạn đến với Hồ sơ năng lực số của tôi!', 1)
        """, (student_id,))
        port = query_db("SELECT * FROM student_portfolios WHERE student_id = ?", (student_id,), one=True)

    data = dict(port)
    try:
        data['social_links'] = json.loads(data['social_links_json'] or '{}')
    except Exception:
        data['social_links'] = {}

    items = query_db("""
        SELECT * FROM portfolio_items 
        WHERE portfolio_id = ? 
        ORDER BY is_pinned DESC, order_index ASC, id DESC
    """, (port['id'],))

    item_list = []
    for it in items:
        d = dict(it)
        try:
            d['skills'] = json.loads(d['skills_json'] or '[]')
        except Exception:
            d['skills'] = []
        item_list.append(d)

    data['items'] = item_list
    return data

def update_portfolio_profile(student_id, headline, bio, social_links=None, is_public=1):
    """Cập nhật thông tin giới thiệu và cài đặt hiển thị hồ sơ cá nhân"""
    soc_json = json.dumps(social_links or {}, ensure_ascii=False) if isinstance(social_links, dict) else '{}'
    execute_db("""
        UPDATE student_portfolios 
        SET headline = ?, bio = ?, social_links_json = ?, is_public = ?, updated_at = CURRENT_TIMESTAMP
        WHERE student_id = ?
    """, (headline.strip(), bio.strip(), soc_json, 1 if is_public else 0, student_id))
    return {'success': True, 'message': 'Đã cập nhật Hồ sơ năng lực cá nhân thành công!'}

def add_portfolio_item(portfolio_id, item_type, title, description='', image_url='', link_url='', skills=None, is_pinned=0):
    """Thêm dự án / bài tập tiêu biểu / chứng nhận vào Portfolio"""
    if not title:
        return {'success': False, 'message': 'Tiêu đề mục không được để trống.'}

    skills_json = json.dumps(skills or [], ensure_ascii=False) if isinstance(skills, list) else '[]'
    item_id = execute_db("""
        INSERT INTO portfolio_items 
        (portfolio_id, item_type, title, description, image_url, link_url, skills_json, is_pinned)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (portfolio_id, item_type or 'project', title.strip(), description.strip(), image_url.strip(), link_url.strip(), skills_json, 1 if is_pinned else 0))

    return {'success': True, 'item_id': item_id, 'message': 'Đã thêm mục vào Portfolio thành công!'}

def delete_portfolio_item(portfolio_id, item_id):
    """Xóa mục khỏi Portfolio (đảm bảo quyền sở hữu)"""
    execute_db("DELETE FROM portfolio_items WHERE id = ? AND portfolio_id = ?", (item_id, portfolio_id))
    return {'success': True, 'message': 'Đã xóa mục khỏi Portfolio.'}

def get_public_portfolio_by_user_id(student_id):
    """Xem hồ sơ công khai (dành cho Nhà tuyển dụng / Người ngoài)"""
    port = query_db("""
        SELECT p.*, u.full_name, u.email, u.avatar, st.student_code, d.name as department_name, m.name as major_name
        FROM student_portfolios p
        JOIN users u ON p.student_id = u.id
        LEFT JOIN students st ON u.id = st.user_id
        LEFT JOIN departments d ON st.department_id = d.id
        LEFT JOIN majors m ON st.major_id = m.id
        WHERE p.student_id = ?
    """, (student_id,), one=True)

    if not port or port['is_public'] == 0:
        return None

    # Tăng lượt xem
    execute_db("UPDATE student_portfolios SET view_count = view_count + 1 WHERE id = ?", (port['id'],))

    data = dict(port)
    data['view_count'] = (port['view_count'] or 0) + 1
    try:
        data['social_links'] = json.loads(data['social_links_json'] or '{}')
    except Exception:
        data['social_links'] = {}

    items = query_db("""
        SELECT * FROM portfolio_items 
        WHERE portfolio_id = ? 
        ORDER BY is_pinned DESC, order_index ASC, id DESC
    """, (port['id'],))

    item_list = []
    for it in items:
        d = dict(it)
        try:
            d['skills'] = json.loads(d['skills_json'] or '[]')
        except Exception:
            d['skills'] = []
        item_list.append(d)

    data['items'] = item_list
    data['competency_profile'] = get_student_competency_profile(student_id)
    data['badges'] = get_student_badges(student_id)
    return data

# ==========================================
# 4. DIGITAL BADGES SYSTEM
# ==========================================

def seed_default_badges_if_empty():
    """Khởi tạo danh mục huy hiệu số chuẩn hóa"""
    count = query_db("SELECT COUNT(*) as c FROM digital_badges", one=True)['c']
    if count > 0:
        return

    default_badges = [
        ("BADGE_COURSE_MASTER", "Làm chủ Học phần", "Hoàn thành lớp học phần với điểm tổng kết xuất sắc (từ 8.5 trở lên).", "fa-graduation-cap", "from-blue-600 to-indigo-600", "academic", "Điểm tổng kết >= 8.5"),
        ("BADGE_CODING_CHAMP", "Quán quân Lập trình", "Vượt qua 100% test cases của bài toán lập trình trực tuyến trong Sandbox.", "fa-laptop-code", "from-emerald-500 to-teal-600", "skill", "Đạt điểm 10/10 bài tập code"),
        ("BADGE_STREAK_HERO", "Chiến binh Bền bỉ", "Duy trì chuỗi ngày tập trung học tập liên tục (Streak) từ 3 ngày trở lên.", "fa-fire-flame-curved", "from-amber-500 to-orange-600", "streak", "Streak ngày >= 3 ngày"),
        ("BADGE_ACADEMIC_STAR", "Ngôi sao Học thuật", "Đạt điểm A/A+ trong các bài kiểm tra trực tuyến chính thức.", "fa-star", "from-yellow-400 to-amber-500", "achievement", "Điểm thi đạt loại A"),
        ("BADGE_PROJECT_HERO", "Kỹ sư Đồ án Tiêu biểu", "Hoàn thành đồ án học phần được đánh giá xuất sắc qua Rubric chuẩn.", "fa-trophy", "from-purple-600 to-pink-600", "project", "Điểm Rubric đồ án >= 9.0"),
        ("BADGE_COMPETENCY_MASTER", "Chuyên gia Kỹ năng Số", "Đạt mức độ Thành thạo (ACHIEVED) ở ít nhất 3 kỹ năng cốt lõi.", "fa-certificate", "from-rose-500 to-red-600", "skill", "Có >= 3 kỹ năng đạt ACHIEVED")
    ]

    for code, name, desc, icon, grad, cat, crit in default_badges:
        execute_db("""
            INSERT OR IGNORE INTO digital_badges (code, name, description, icon, color_gradient, category, criteria)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (code, name, desc, icon, grad, cat, crit))

def get_all_badges():
    """Lấy danh sách tất cả huy hiệu số trong hệ thống"""
    seed_default_badges_if_empty()
    return query_db("SELECT * FROM digital_badges ORDER BY id ASC")

def has_student_badge(student_id, badge_code_or_id):
    """Kiểm tra sinh viên đã sở hữu huy hiệu này hay chưa"""
    if isinstance(badge_code_or_id, int) or (isinstance(badge_code_or_id, str) and badge_code_or_id.isdigit()):
        row = query_db("SELECT id FROM student_badges WHERE student_id = ? AND badge_id = ?", (student_id, int(badge_code_or_id)), one=True)
    else:
        row = query_db("""
            SELECT sb.id FROM student_badges sb
            JOIN digital_badges b ON sb.badge_id = b.id
            WHERE sb.student_id = ? AND b.code = ?
        """, (student_id, str(badge_code_or_id)), one=True)
    return row is not None

def award_badge_to_student(badge_id=None, student_id=None, course_id=None, evidence_text='', issued_by=None, badge_code=None):
    """Cấp phát huy hiệu số kèm minh chứng hợp lệ (hỗ trợ cả badge_id hoặc badge_code)"""
    if isinstance(student_id, str) and not student_id.isdigit() and isinstance(badge_id, int):
        badge_code = student_id
        student_id = badge_id
        badge_id = None

    target = badge_id if badge_id is not None else badge_code
    if isinstance(target, int) or (isinstance(target, str) and target.isdigit()):
        badge = query_db("SELECT id, name, code FROM digital_badges WHERE id = ?", (int(target),), one=True)
    else:
        badge = query_db("SELECT id, name, code FROM digital_badges WHERE code = ?", (str(target),), one=True)

    if not badge:
        return {'success': False, 'message': 'Huy hiệu không tồn tại.'}

    bid = badge['id']
    existing = query_db("""
        SELECT id FROM student_badges 
        WHERE badge_id = ? AND student_id = ? AND (course_id = ? OR (course_id IS NULL AND ? IS NULL))
    """, (bid, student_id, course_id, course_id), one=True)

    if existing:
        return {'success': True, 'message': 'Sinh viên đã nhận (đã sở hữu) huy hiệu này.', 'badge_id': bid}

    sbid = execute_db("""
        INSERT INTO student_badges (badge_id, student_id, course_id, evidence_text, issued_by)
        VALUES (?, ?, ?, ?, ?)
    """, (bid, student_id, course_id, evidence_text.strip(), issued_by))

    track_activity(student_id, course_id, 'BADGE_AWARDED', sbid, {'badge_name': badge['name'], 'evidence': evidence_text})
    return {'success': True, 'student_badge_id': sbid, 'message': f"Đã trao tặng Huy hiệu '{badge['name']}' thành công!", 'badge_id': bid}

def get_student_badges(student_id):
    """Lấy danh sách các huy hiệu số sinh viên đã đạt được kèm minh chứng"""
    seed_default_badges_if_empty()
    return query_db("""
        SELECT sb.*, b.code, b.name, b.description, b.icon, b.color_gradient, b.category,
               c.name as course_name, c.code as course_code, u.full_name as issuer_name
        FROM student_badges sb
        JOIN digital_badges b ON sb.badge_id = b.id
        LEFT JOIN courses c ON sb.course_id = c.id
        LEFT JOIN users u ON sb.issued_by = u.id
        WHERE sb.student_id = ?
        ORDER BY sb.awarded_at DESC, sb.id DESC
    """, (student_id,))

def check_and_auto_award_badges(student_id):
    """
    Tự động kiểm tra điều kiện và cấp phát huy hiệu dựa trên dữ liệu học tập thực tế.
    Không cấp huy hiệu ảo khi chưa đạt tiêu chuẩn.
    """
    seed_default_badges_if_empty()
    badges = {b['code']: b for b in query_db("SELECT * FROM digital_badges")}

    awarded = []

    # 1. Kiểm tra điểm học phần xuất sắc (>= 8.5) -> BADGE_COURSE_MASTER
    high_grades = query_db("""
        SELECT g.*, c.name as course_name, c.code as course_code
        FROM grades g
        JOIN courses c ON g.course_id = c.id
        WHERE g.student_id = ? AND g.total_score >= 8.5
    """, (student_id,))
    for g in high_grades:
        if 'BADGE_COURSE_MASTER' in badges:
            res = award_badge_to_student(
                badge_id=badges['BADGE_COURSE_MASTER']['id'],
                student_id=student_id,
                course_id=g['course_id'],
                evidence_text=f"Điểm tổng kết môn {g['course_name']} ({g['course_code']}) đạt {g['total_score']}/10."
            )
            if res.get('success'):
                awarded.append(badges['BADGE_COURSE_MASTER']['name'])

    # 2. Kiểm tra làm bài tập lập trình đạt điểm tuyệt đối 10/10 -> BADGE_CODING_CHAMP
    coding_perfect = query_db("""
        SELECT cs.*, cp.title as problem_title, cp.course_id
        FROM coding_submissions cs
        JOIN coding_problems cp ON cs.problem_id = cp.id
        WHERE cs.student_id = ? AND cs.status = 'PASSED' AND cs.score >= 10.0
        LIMIT 1
    """, (student_id,), one=True)
    if coding_perfect and 'BADGE_CODING_CHAMP' in badges:
        res = award_badge_to_student(
            badge_id=badges['BADGE_CODING_CHAMP']['id'],
            student_id=student_id,
            course_id=coding_perfect['course_id'],
            evidence_text=f"Vượt qua 100% test cases bài toán '{coding_perfect['problem_title']}'."
        )
        if res.get('success'):
            awarded.append(badges['BADGE_CODING_CHAMP']['name'])

    # 3. Kiểm tra chuỗi học tập Pomodoro từ 3 ngày trở lên -> BADGE_STREAK_HERO
    streak_cnt = query_db("""
        SELECT COUNT(DISTINCT DATE(created_at)) as c 
        FROM study_sessions WHERE student_id = ?
    """, (student_id,), one=True)['c'] or 0
    if streak_cnt >= 3 and 'BADGE_STREAK_HERO' in badges:
        res = award_badge_to_student(
            badge_id=badges['BADGE_STREAK_HERO']['id'],
            student_id=student_id,
            evidence_text=f"Duy trì chuỗi ngày học tập và tập trung Pomodoro tích lũy {streak_cnt} ngày."
        )
        if res.get('success'):
            awarded.append(badges['BADGE_STREAK_HERO']['name'])

    # 4. Kiểm tra bài thi loại A -> BADGE_ACADEMIC_STAR
    exam_high = query_db("""
        SELECT er.*, e.title as exam_title, e.course_id
        FROM exam_results er
        JOIN exams e ON er.exam_id = e.id
        WHERE er.student_id = ? AND (er.score >= 8.5)
        LIMIT 1
    """, (student_id,), one=True)
    if exam_high and 'BADGE_ACADEMIC_STAR' in badges:
        res = award_badge_to_student(
            badge_id=badges['BADGE_ACADEMIC_STAR']['id'],
            student_id=student_id,
            course_id=exam_high['course_id'],
            evidence_text=f"Đạt điểm xuất sắc ({exam_high['score']}/10) trong kỳ thi '{exam_high['exam_title']}'."
        )
        if res.get('success'):
            awarded.append(badges['BADGE_ACADEMIC_STAR']['name'])

    return {'success': True, 'awarded_badges': awarded}
