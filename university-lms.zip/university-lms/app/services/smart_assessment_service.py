import json
import re
from datetime import datetime
from database import query_db, execute_db
from services.activity_service import track_activity
from services.ai_gateway import call_ai

# ==========================================
# 1. INTELLIGENT QUESTION BANK
# ==========================================

def get_question_bank(course_id=None, chapter_num=None, difficulty=None, tag=None, search=None):
    """Lấy danh sách câu hỏi trong ngân hàng với bộ lọc đa tiêu chí"""
    sql = """
        SELECT qb.*, c.code as course_code, c.name as course_name, u.full_name as author_name
        FROM question_bank qb
        LEFT JOIN courses c ON qb.course_id = c.id
        LEFT JOIN users u ON qb.created_by = u.id
        WHERE 1=1
    """
    params = []

    if course_id:
        sql += " AND qb.course_id = ?"
        params.append(course_id)

    if chapter_num:
        sql += " AND qb.chapter_num = ?"
        params.append(chapter_num)

    if difficulty:
        sql += " AND qb.difficulty = ?"
        params.append(difficulty)

    if tag:
        sql += " AND qb.tags_json LIKE ?"
        params.append(f"%{tag}%")

    if search:
        sql += " AND (qb.question_text LIKE ? OR qb.explanation LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])

    sql += " ORDER BY qb.chapter_num ASC, qb.id DESC"
    rows = query_db(sql, tuple(params))
    
    result = []
    for r in rows:
        d = dict(r)
        try:
            d['options'] = json.loads(d['options_json'])
        except Exception:
            d['options'] = []
        try:
            d['correct_answers'] = json.loads(d['correct_answers_json'])
        except Exception:
            d['correct_answers'] = [0]
        try:
            d['tags'] = json.loads(d['tags_json'])
        except Exception:
            d['tags'] = []
        try:
            d['skills'] = json.loads(d['skills_json'])
        except Exception:
            d['skills'] = []
        result.append(d)
    return result

def create_bank_question(course_id, question_text, options, correct_answers, 
                         chapter_num=1, topic_id=None, difficulty='MEDIUM', 
                         points=1.0, tags=None, skills=None, explanation='', created_by=1):
    """Thêm mới câu hỏi vào Ngân hàng câu hỏi thông minh"""
    if not question_text or not options:
        return {'success': False, 'message': 'Nội dung câu hỏi và các phương án trả lời không được để trống.'}

    options_json = json.dumps(options if isinstance(options, list) else [options], ensure_ascii=False)
    correct_json = json.dumps(correct_answers if isinstance(correct_answers, list) else [int(correct_answers)], ensure_ascii=False)
    tags_json = json.dumps(tags if isinstance(tags, list) else ([tags] if tags else []), ensure_ascii=False)
    skills_json = json.dumps(skills if isinstance(skills, list) else ([skills] if skills else []), ensure_ascii=False)

    qid = execute_db("""
        INSERT INTO question_bank 
        (course_id, chapter_num, topic_id, question_text, question_type, options_json, correct_answers_json,
         difficulty, points, tags_json, skills_json, explanation, created_by)
        VALUES (?, ?, ?, ?, 'single', ?, ?, ?, ?, ?, ?, ?, ?)
    """, (course_id, chapter_num or 1, topic_id, question_text.strip(), options_json, correct_json,
          difficulty or 'MEDIUM', float(points or 1.0), tags_json, skills_json, explanation.strip(), created_by))

    track_activity(created_by, course_id, 'QUESTION_BANK_CREATE', qid, {'difficulty': difficulty})
    return {'success': True, 'question_id': qid, 'message': 'Đã lưu câu hỏi vào Ngân hàng thành công!'}

def delete_bank_question(question_id, user_id=None):
    """Xóa câu hỏi khỏi ngân hàng câu hỏi"""
    q = query_db("SELECT id, course_id FROM question_bank WHERE id = ?", (question_id,), one=True)
    if not q:
        return {'success': False, 'message': 'Câu hỏi không tồn tại.'}

    execute_db("DELETE FROM question_bank WHERE id = ?", (question_id,))
    if user_id:
        track_activity(user_id, q['course_id'], 'QUESTION_BANK_DELETE', question_id)
    return {'success': True, 'message': 'Đã xóa câu hỏi khỏi ngân hàng thành công.'}

def seed_default_question_bank_if_empty(course_id, created_by):
    """Khởi tạo một số câu hỏi mẫu cho môn học nếu ngân hàng câu hỏi môn này còn trống"""
    existing = query_db("SELECT COUNT(*) as c FROM question_bank WHERE course_id = ?", (course_id,), one=True)['c']
    if existing > 0:
        return

    course = query_db("SELECT name FROM courses WHERE id = ?", (course_id,), one=True)
    c_name = course['name'] if course else "Học phần"

    sample_questions = [
        # Chương 1
        (1, f"Khái niệm cốt lõi và mục tiêu cơ bản của học phần '{c_name}' là gì?",
         ["Nền tảng lý thuyết và công cụ ứng dụng giải quyết bài toán thực tế", "Chỉ học thuộc lòng các định nghĩa", "Không có ứng dụng trong thực tế", "Chỉ dùng cho mục đích nghiên cứu thuần túy"],
         [0], "EASY", ["Lý thuyết", "Cốt lõi"], ["Ghi nhớ"], "Khái niệm nền tảng đóng vai trò kim chỉ nam cho toàn bộ học phần."),
        (1, f"Thuộc tính nào sau đây thể hiện tính toàn vẹn và chuẩn mực trong '{c_name}'?",
         ["Tính nhất quán và bảo mật", "Tùy tiện thay đổi không kiểm soát", "Bỏ qua các bước xác thực", "Không cần ghi vết nhật ký"],
         [0], "MEDIUM", ["Nguyên lý", "Toàn vẹn"], ["Phân tích"], "Mọi hệ thống chuẩn mực đều yêu cầu tính nhất quán và bảo mật cao."),
        # Chương 2
        (2, f"Trong quy trình thiết kế và hiện thực '{c_name}', giai đoạn nào cần làm đầu tiên?",
         ["Khảo sát yêu cầu và mô hình hóa bài toán", "Viết mã nguồn ngay lập tức", "Bàn giao sản phẩm khi chưa test", "Triển khai lên máy chủ thật"],
         [0], "MEDIUM", ["Thiết kế", "Quy trình"], ["Áp dụng"], "Cần khảo sát kỹ yêu cầu trước khi tiến hành kiến trúc và cài đặt."),
        (2, f"Phương pháp nào giúp giảm thiểu rủi ro khi cài đặt kiến trúc cốt lõi của '{c_name}'?",
         ["Module hóa và phân chia trách nhiệm rõ ràng (Separation of Concerns)", "Viết tất cả logic vào một file duy nhất", "Không cần viết tài liệu", "Bỏ qua xử lý lỗi ngoại lệ"],
         [0], "MEDIUM", ["Kiến trúc", "Tối ưu"], ["Phân tích"], "Module hóa giúp cô lập lỗi và tăng khả năng bảo trì."),
        # Chương 3
        (3, f"Khi đối mặt với bài toán hiệu năng cao trong '{c_name}', giải pháp nào mang lại hiệu quả tối ưu?",
         ["Sử dụng cơ chế đệm (Caching) và lập chỉ mục phù hợp", "Tăng thêm sleep time trong code", "Truy vấn toàn bộ cơ sở dữ liệu mỗi request", "Bỏ qua xác thực quyền"],
         [0], "HARD", ["Hiệu năng", "Nâng cao"], ["Đánh giá"], "Caching và Indexing là 2 trụ cột tối ưu tốc độ xử lý dữ liệu lớn."),
        (3, f"Giải pháp xử lý lỗi ngoại lệ chuẩn mực khi gặp sự cố bất thường là gì?",
         ["Bắt ngoại lệ, ghi log chi tiết và trả về phản hồi an toàn cho người dùng", "Dừng chương trình ngay lập tức và in traceback ra màn hình người dùng", "Bỏ qua không cần xử lý", "Xóa database để làm lại"],
         [0], "HARD", ["Xử lý lỗi", "Bảo mật"], ["Giải quyết vấn đề"], "Hệ thống cần bẫy lỗi để tránh lộ thông tin nội bộ và đảm bảo tính sẵn sàng.")
    ]

    for chap, q_text, opts, ans, diff, tags, skills, exp in sample_questions:
        create_bank_question(
            course_id=course_id,
            question_text=q_text,
            options=opts,
            correct_answers=ans,
            chapter_num=chap,
            difficulty=diff,
            points=1.0,
            tags=tags,
            skills=skills,
            explanation=exp,
            created_by=created_by
        )

def get_question_bank_stats(course_id=None):
    """Thống kê tổng quan ngân hàng câu hỏi"""
    base_sql = "FROM question_bank WHERE 1=1"
    params = []
    if course_id:
        base_sql += " AND course_id = ?"
        params.append(course_id)

    total = query_db(f"SELECT COUNT(*) as c {base_sql}", tuple(params), one=True)['c']
    easy = query_db(f"SELECT COUNT(*) as c {base_sql} AND difficulty = 'EASY'", tuple(params), one=True)['c']
    medium = query_db(f"SELECT COUNT(*) as c {base_sql} AND difficulty = 'MEDIUM'", tuple(params), one=True)['c']
    hard = query_db(f"SELECT COUNT(*) as c {base_sql} AND difficulty = 'HARD'", tuple(params), one=True)['c']

    return {
        'total': total,
        'easy': easy,
        'medium': medium,
        'hard': hard
    }

# ==========================================
# 2. AI QUESTION GENERATION (TEACHER APPROVAL WORKFLOW)
# ==========================================

def generate_ai_questions(course_id, chapter_num=1, count=5, difficulty='MEDIUM', prompt_hint='', teacher_id=1):
    """
    Sinh câu hỏi trắc nghiệm bằng AI từ tài liệu hoặc chủ đề học phần.
    Các câu hỏi sinh ra ở trạng thái 'chờ duyệt' (unapproved), giảng viên xem trước,
    chỉnh sửa, duyệt và lưu vào Ngân hàng. Tuyệt đối không tự ý đưa thẳng vào đề thi chính thức.
    """
    course = query_db("SELECT id, code, name FROM courses WHERE id = ?", (course_id,), one=True)
    c_name = course['name'] if course else "Học phần"

    ai_prompt = f"""Bạn là chuyên gia sư phạm đại học môn '{c_name}'.
Hãy tạo {count} câu hỏi trắc nghiệm khách quan cho Chương {chapter_num}.
Mức độ khó: {difficulty} (EASY, MEDIUM hoặc HARD).
Yêu cầu bổ sung: {prompt_hint or 'Bám sát trọng tâm kiến thức và kỹ năng thực hành cốt lõi.'}

ĐỊNH DẠNG BẮT BUỘC (trả về DUY NHẤT một mảng JSON hợp lệ):
[
  {{
    "question": "Nội dung câu hỏi ngắn gọn, tường minh?",
    "options": ["Phương án A", "Phương án B", "Phương án C", "Phương án D"],
    "correct_index": 0,
    "explanation": "Giải thích chi tiết tại sao phương án này đúng",
    "difficulty": "{difficulty}",
    "tags": ["Lý thuyết", "Chương {chapter_num}"],
    "skills": ["Ghi nhớ", "Hiểu"]
  }}
]"""

    response = call_ai(
        prompt=ai_prompt,
        user_id=teacher_id,
        role='teacher',
        service_name='quiz_gen'
    )

    generated_questions = []
    resp_text = response.get('content') or response.get('text')
    if response.get('success') and resp_text:
        try:
            raw_text = resp_text.strip()
            json_match = re.search(r'\[.*\]', raw_text, re.DOTALL)
            data_str = json_match.group(0) if json_match else raw_text
            items = json.loads(data_str)
            for item in items:
                if item.get('question') and item.get('options') and len(item['options']) >= 2:
                    generated_questions.append({
                        'question': item['question'].strip(),
                        'options': item['options'],
                        'correct_index': int(item.get('correct_index', 0)),
                        'explanation': item.get('explanation', ''),
                        'difficulty': item.get('difficulty', difficulty),
                        'tags': item.get('tags', [f"Chương {chapter_num}"]),
                        'skills': item.get('skills', ["Phân tích"])
                    })
        except Exception as e:
            generated_questions = []

    # Fallback chất lượng cao nếu AI ngoại tuyến hoặc không có key
    if not generated_questions:
        templates = [
            (f"Nhiệm vụ chính yếu trong Chương {chapter_num} của môn '{c_name}' là gì?",
             ["Làm chủ các khái niệm và kỹ năng cốt lõi được định nghĩa trong chương", "Bỏ qua các bước thực hành", "Học vẹt định lý mà không cần hiểu", "Chỉ làm bài tập trắc nghiệm"],
             0, "Giúp người học có nền tảng vững vàng cho các chương chuyên sâu."),
            (f"Đặc điểm tiêu biểu của mô hình giải quyết vấn đề trong Chương {chapter_num} là gì?",
             ["Tính module hóa, rõ ràng và có thể kiểm chứng được", "Tính phức tạp không cần thiết", "Không tuân thủ chuẩn coding", "Khó tái sử dụng"],
             0, "Khả năng module hóa và kiểm thử là tiêu chuẩn hàng đầu."),
            (f"Biện pháp tối ưu hóa quy trình làm việc được khuyến nghị trong Chương {chapter_num} là gì?",
             ["Tự động hóa kiểm thử và phân tích luồng dữ liệu", "Làm thủ công hoàn toàn", "Bỏ qua bước thiết kế", "Viết mã nguồn không qua kiểm duyệt"],
             0, "Tự động hóa giúp giảm thiểu sai sót do con người."),
            (f"Trong trường hợp xảy ra xung đột dữ liệu, phương án giải quyết tối ưu theo giáo trình là gì?",
             ["Áp dụng cơ chế khóa phân tán hoặc transaction có tính toàn vẹn (ACID)", "Xóa bỏ một bên dữ liệu ngẫu nhiên", "Tắt toàn bộ hệ thống", "Bỏ qua không ghi nhận"],
             0, "Tính toàn vẹn ACID ngăn chặn tình trạng dữ liệu mâu thuẫn."),
            (f"Tiêu chuẩn đánh giá mức độ thông thạo kiến thức Chương {chapter_num} gồm những gì?",
             ["Khả năng giải thích bản chất và áp dụng giải bài toán thực tế độc lập", "Chỉ cần thi qua môn", "Không cần nhớ cú pháp cơ bản", "Học trước quên sau"],
             0, "Mức độ hiểu sâu thể hiện qua năng lực giải quyết bài toán độc lập.")
        ]
        for q_t, opts, c_idx, exp in templates[:count]:
            generated_questions.append({
                'question': q_t,
                'options': opts,
                'correct_index': c_idx,
                'explanation': exp,
                'difficulty': difficulty,
                'tags': [f"Chương {chapter_num}", "Ôn tập"],
                'skills': ["Hiểu", "Áp dụng"]
            })

    return {
        'success': True,
        'count': len(generated_questions),
        'questions': generated_questions,
        'message': f"Đã sinh {len(generated_questions)} câu hỏi tiềm năng. Giảng viên vui lòng duyệt trước khi lưu vào Ngân hàng."
    }

# ==========================================
# 3. ASSESSMENT MATRIX & AUTO EXAM GENERATOR
# ==========================================

def create_assessment_matrix(course_id, title, description, items, created_by):
    """Tạo mới Ma trận đề thi chuẩn hóa"""
    if not title:
        return {'success': False, 'message': 'Tiêu đề ma trận không được để trống.'}

    matrix_id = execute_db("""
        INSERT INTO assessment_matrices (course_id, title, description, total_questions, total_points, created_by)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (course_id, title.strip(), description.strip(), len(items) if items else 10, 10.0, created_by))

    total_q = 0
    for item in items:
        e_cnt = int(item.get('easy_count', 0))
        m_cnt = int(item.get('medium_count', 0))
        h_cnt = int(item.get('hard_count', 0))
        pts = float(item.get('points_per_question', 1.0))
        total_q += (e_cnt + m_cnt + h_cnt)

        execute_db("""
            INSERT INTO matrix_items (matrix_id, chapter_num, topic_title, easy_count, medium_count, hard_count, points_per_question, skill_evaluated)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (matrix_id, item.get('chapter_num', 1), item.get('topic_title', 'Chương kiến thức'),
              e_cnt, m_cnt, h_cnt, pts, item.get('skill_evaluated', 'Hiểu - Áp dụng')))

    execute_db("UPDATE assessment_matrices SET total_questions = ? WHERE id = ?", (total_q, matrix_id))
    track_activity(created_by, course_id, 'MATRIX_CREATE', matrix_id)
    return {'success': True, 'matrix_id': matrix_id, 'message': 'Đã tạo Ma trận đề thi thành công!'}

def get_assessment_matrices(course_id=None):
    """Lấy danh sách ma trận đề thi"""
    sql = """
        SELECT m.*, c.name as course_name, c.code as course_code, u.full_name as author_name
        FROM assessment_matrices m
        JOIN courses c ON m.course_id = c.id
        LEFT JOIN users u ON m.created_by = u.id
        WHERE 1=1
    """
    params = []
    if course_id:
        sql += " AND m.course_id = ?"
        params.append(course_id)
    sql += " ORDER BY m.id DESC"
    return query_db(sql, tuple(params))

def get_assessment_matrix_detail(matrix_id):
    """Lấy chi tiết ma trận đề thi kèm các mục phân bổ"""
    matrix = query_db("""
        SELECT m.*, c.name as course_name, c.code as course_code
        FROM assessment_matrices m
        JOIN courses c ON m.course_id = c.id
        WHERE m.id = ?
    """, (matrix_id,), one=True)
    if not matrix:
        return None

    items = query_db("SELECT * FROM matrix_items WHERE matrix_id = ? ORDER BY chapter_num ASC", (matrix_id,))
    d = dict(matrix)
    d['items'] = [dict(it) for it in items]
    return d

def generate_exam_from_matrix(matrix_id, exam_title, duration_minutes=45, created_by=1):
    """
    Tự động lắp ghép đề thi chính thức từ Ma trận đề thi và Ngân hàng câu hỏi.
    Tạo bản ghi mới trong bảng `exams` và `questions`.
    """
    matrix = get_assessment_matrix_detail(matrix_id)
    if not matrix:
        return {'success': False, 'message': 'Không tìm thấy ma trận đề thi chỉ định.'}

    course_id = matrix['course_id']
    title = exam_title.strip() if exam_title else f"Đề thi tạo từ ma trận: {matrix['title']}"

    # Đảm bảo môn học có câu hỏi trong ngân hàng
    seed_default_question_bank_if_empty(course_id, created_by)

    # 1. Tạo Exam mới
    exam_id = execute_db("""
        INSERT INTO exams (course_id, title, description, duration_minutes, max_score, created_by)
        VALUES (?, ?, ?, ?, 10.0, ?)
    """, (course_id, title, f"Đề thi chuẩn hóa tự động lắp ghép theo Ma trận #{matrix_id}", duration_minutes or 45, created_by))

    # 2. Quét ma trận và chọn câu hỏi từ Question Bank
    selected_questions = []
    for it in matrix['items']:
        chap = it['chapter_num']
        # Chọn câu hỏi theo từng mức độ
        reqs = [
            ('EASY', it['easy_count']),
            ('MEDIUM', it['medium_count']),
            ('HARD', it['hard_count'])
        ]
        for diff, count in reqs:
            if count > 0:
                rows = query_db("""
                    SELECT * FROM question_bank 
                    WHERE course_id = ? AND chapter_num = ? AND difficulty = ?
                    ORDER BY usage_count ASC, RANDOM()
                    LIMIT ?
                """, (course_id, chap, diff, count))

                for r in rows:
                    selected_questions.append(r)
                    execute_db("UPDATE question_bank SET usage_count = usage_count + 1 WHERE id = ?", (r['id'],))

    # Nếu ngân hàng chưa đủ số lượng chính xác, lấy bù các câu hỏi khác trong môn
    needed = matrix['total_questions'] - len(selected_questions)
    if needed > 0:
        fillers = query_db("""
            SELECT * FROM question_bank 
            WHERE course_id = ? AND id NOT IN ({})
            ORDER BY RANDOM() LIMIT ?
        """.format(','.join([str(q['id']) for q in selected_questions]) if selected_questions else '0'),
        (course_id, needed))
        for f in fillers:
            selected_questions.append(f)

    # 3. Lưu câu hỏi vào bảng questions của đề thi
    pts_per_q = round(10.0 / len(selected_questions), 2) if selected_questions else 1.0
    for q in selected_questions:
        execute_db("""
            INSERT INTO questions (exam_id, question_text, question_type, options_json, correct_answers_json, points)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (exam_id, q['question_text'], q['question_type'], q['options_json'], q['correct_answers_json'], pts_per_q))

    track_activity(created_by, course_id, 'EXAM_GENERATED_FROM_MATRIX', exam_id, {'matrix_id': matrix_id, 'questions_count': len(selected_questions)})
    return {
        'success': True,
        'exam_id': exam_id,
        'questions_count': len(selected_questions),
        'message': f"Đã tự động tạo đề thi '{title}' với {len(selected_questions)} câu hỏi từ ngân hàng chuẩn hóa!"
    }

# ==========================================
# 4. ADAPTIVE PRACTICE TESTING (CHẾ ĐỘ LUYỆN TẬP THÍCH ỨNG)
# ==========================================

def start_adaptive_practice(student_id, course_id, total_questions=10):
    """
    Bắt đầu một phiên luyện tập thích ứng cho sinh viên.
    Độ khó bắt đầu ở mức MEDIUM. Thuật toán sẽ tự động điều chỉnh độ khó theo từng câu trả lời.
    """
    # Đảm bảo có câu hỏi
    seed_default_question_bank_if_empty(course_id, student_id)

    session_id = execute_db("""
        INSERT INTO adaptive_test_sessions (student_id, course_id, current_difficulty, total_questions, answered_count, correct_count, status)
        VALUES (?, ?, 'MEDIUM', ?, 0, 0, 'IN_PROGRESS')
    """, (student_id, course_id, total_questions or 10))

    # Lấy câu hỏi đầu tiên mức MEDIUM
    first_q = query_db("""
        SELECT * FROM question_bank WHERE course_id = ? AND difficulty = 'MEDIUM' ORDER BY RANDOM() LIMIT 1
    """, (course_id,), one=True)

    if not first_q:
        first_q = query_db("SELECT * FROM question_bank WHERE course_id = ? ORDER BY RANDOM() LIMIT 1", (course_id,), one=True)

    track_activity(student_id, course_id, 'ADAPTIVE_TEST_START', session_id)
    return {
        'session_id': session_id,
        'current_difficulty': 'MEDIUM',
        'current_step': 1,
        'total_questions': total_questions,
        'question': {
            'id': first_q['id'],
            'question_text': first_q['question_text'],
            'options': json.loads(first_q['options_json']),
            'difficulty': first_q['difficulty']
        } if first_q else None
    }

def submit_adaptive_practice_answer(session_id, question_id, selected_answer_idx, response_time=10):
    """
    Xử lý câu trả lời trong phiên thi thích ứng.
    Thuật toán thích ứng CAT (Computerized Adaptive Testing):
    - Đúng -> Tăng độ khó (EASY -> MEDIUM -> HARD)
    - Sai -> Giảm độ khó (HARD -> MEDIUM -> EASY)
    """
    sess = query_db("SELECT * FROM adaptive_test_sessions WHERE id = ?", (session_id,), one=True)
    if not sess or sess['status'] != 'IN_PROGRESS':
        return {'success': False, 'message': 'Phiên luyện tập không hợp lệ hoặc đã kết thúc.'}

    q = query_db("SELECT * FROM question_bank WHERE id = ?", (question_id,), one=True)
    if not q:
        return {'success': False, 'message': 'Không tìm thấy câu hỏi.'}

    correct_answers = json.loads(q['correct_answers_json'])
    is_correct = 1 if int(selected_answer_idx) in correct_answers else 0

    # Lưu câu trả lời
    execute_db("""
        INSERT INTO adaptive_test_answers (session_id, question_id, selected_answer, is_correct, difficulty_at_step, response_time_seconds)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (session_id, question_id, str(selected_answer_idx), is_correct, sess['current_difficulty'], int(response_time or 10)))

    new_answered = sess['answered_count'] + 1
    new_correct = sess['correct_count'] + (1 if is_correct else 0)

    # Điều chỉnh độ khó thích ứng
    current_diff = sess['current_difficulty']
    if is_correct:
        if current_diff == 'EASY':
            next_diff = 'MEDIUM'
        elif current_diff == 'MEDIUM':
            next_diff = 'HARD'
        else:
            next_diff = 'HARD'
    else:
        if current_diff == 'HARD':
            next_diff = 'MEDIUM'
        elif current_diff == 'MEDIUM':
            next_diff = 'EASY'
        else:
            next_diff = 'EASY'

    # Kiểm tra hoàn thành phiên thi
    if new_answered >= sess['total_questions']:
        mastery_pct = round((new_correct / sess['total_questions']) * 100.0, 1)
        recs = []
        if mastery_pct >= 80:
            recs.append("Xuất sắc! Bạn đã làm chủ kiến thức học phần với độ chính xác cao ngay cả ở các câu hỏi độ khó HARD.")
        elif mastery_pct >= 50:
            recs.append("Khá tốt! Bạn vững các câu hỏi EASY và MEDIUM, cần trau dồi thêm các bài toán phân tích chuyên sâu.")
        else:
            recs.append("Cần cố gắng! Đề xuất ôn lại lý thuyết nền tảng Chương 1 và Chương 2 trước khi thử lại.")

        execute_db("""
            UPDATE adaptive_test_sessions 
            SET status = 'COMPLETED', answered_count = ?, correct_count = ?, final_mastery_pct = ?,
                current_difficulty = ?, recommendations_json = ?, completed_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (new_answered, new_correct, mastery_pct, next_diff, json.dumps(recs, ensure_ascii=False), session_id))

        return {
            'is_finished': True,
            'is_correct': bool(is_correct),
            'explanation': q['explanation'],
            'mastery_pct': mastery_pct,
            'correct_count': new_correct,
            'total_questions': sess['total_questions'],
            'recommendations': recs
        }
    else:
        # Cập nhật tiến độ
        execute_db("""
            UPDATE adaptive_test_sessions 
            SET answered_count = ?, correct_count = ?, current_difficulty = ?
            WHERE id = ?
        """, (new_answered, new_correct, next_diff, session_id))

        # Chọn câu hỏi tiếp theo chưa được trả lời trong phiên
        answered_qids = [r['question_id'] for r in query_db("SELECT question_id FROM adaptive_test_answers WHERE session_id = ?", (session_id,))]
        not_in_clause = ','.join(map(str, answered_qids)) if answered_qids else '0'

        next_q = query_db(f"""
            SELECT * FROM question_bank 
            WHERE course_id = ? AND difficulty = ? AND id NOT IN ({not_in_clause})
            ORDER BY RANDOM() LIMIT 1
        """, (sess['course_id'], next_diff), one=True)

        if not next_q:
            # Nếu hết câu ở độ khó đó, chọn câu bất kỳ chưa làm
            next_q = query_db(f"""
                SELECT * FROM question_bank 
                WHERE course_id = ? AND id NOT IN ({not_in_clause})
                ORDER BY RANDOM() LIMIT 1
            """, (sess['course_id'],), one=True)

        return {
            'is_finished': False,
            'is_correct': bool(is_correct),
            'explanation': q['explanation'],
            'current_step': new_answered + 1,
            'total_questions': sess['total_questions'],
            'next_difficulty': next_diff,
            'next_question': {
                'id': next_q['id'],
                'question_text': next_q['question_text'],
                'options': json.loads(next_q['options_json']),
                'difficulty': next_q['difficulty']
            } if next_q else None
        }

def get_adaptive_practice_report(session_id):
    """Lấy báo cáo chi tiết kết quả phiên luyện tập thích ứng"""
    sess = query_db("""
        SELECT s.*, c.name as course_name, c.code as course_code
        FROM adaptive_test_sessions s
        JOIN courses c ON s.course_id = c.id
        WHERE s.id = ?
    """, (session_id,), one=True)
    if not sess:
        return None

    answers = query_db("""
        SELECT a.*, q.question_text, q.explanation, q.options_json
        FROM adaptive_test_answers a
        JOIN question_bank q ON a.question_id = q.id
        WHERE a.session_id = ?
        ORDER BY a.id ASC
    """, (session_id,))

    ans_list = []
    for r in answers:
        d = dict(r)
        d['options'] = json.loads(d['options_json'])
        ans_list.append(d)

    data = dict(sess)
    data['answers'] = ans_list
    data['recommendations'] = json.loads(data['recommendations_json'] or '[]')
    return data

# ==========================================
# 5. PROCESS-BASED ASSESSMENT (ĐÁNH GIÁ THEO TIẾN TRÌNH)
# ==========================================

def record_submission_version(assignment_id, student_id, file_path='', notes='', stage_name='Nộp bài tiến trình'):
    """Ghi nhận phiên bản bài làm mới của sinh viên theo từng giai đoạn / milestone"""
    last_ver = query_db("""
        SELECT MAX(version) as mv FROM process_submissions_history 
        WHERE assignment_id = ? AND student_id = ?
    """, (assignment_id, student_id), one=True)['mv'] or 0
    next_ver = last_ver + 1

    hid = execute_db("""
        INSERT INTO process_submissions_history (assignment_id, student_id, version, file_path, notes, stage_name)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (assignment_id, student_id, next_ver, file_path or '', notes.strip(), stage_name))

    # Cập nhật hoặc tạo bản ghi trong bảng submissions chính
    execute_db("""
        INSERT INTO submissions (assignment_id, student_id, file_path, notes, submitted_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(assignment_id, student_id) DO UPDATE SET
            file_path = excluded.file_path,
            notes = excluded.notes,
            submitted_at = CURRENT_TIMESTAMP
    """, (assignment_id, student_id, file_path or '', notes.strip()))

    track_activity(student_id, None, 'ASSIGNMENT_VERSION_SUBMIT', hid, {'version': next_ver, 'assignment_id': assignment_id})
    return {'success': True, 'version': next_ver, 'history_id': hid, 'message': f'Đã ghi nhận bài nộp phiên bản v{next_ver} thành công.'}

def get_submission_history(assignment_id, student_id):
    """Lấy toàn bộ lịch sử các phiên bản bài nộp của sinh viên"""
    return query_db("""
        SELECT * FROM process_submissions_history 
        WHERE assignment_id = ? AND student_id = ?
        ORDER BY version DESC
    """, (assignment_id, student_id))

def grade_submission_stage(history_id, stage_score, teacher_feedback, teacher_id):
    """Giảng viên đánh giá và cho điểm theo từng giai đoạn tiến trình"""
    execute_db("""
        UPDATE process_submissions_history 
        SET stage_score = ?, teacher_feedback = ?
        WHERE id = ?
    """, (float(stage_score), teacher_feedback.strip(), history_id))

    hist = query_db("SELECT * FROM process_submissions_history WHERE id = ?", (history_id,), one=True)
    if hist:
        # Đồng bộ điểm mới nhất vào bảng submissions
        execute_db("""
            UPDATE submissions 
            SET score = ?, feedback = ?, graded_at = CURRENT_TIMESTAMP
            WHERE assignment_id = ? AND student_id = ?
        """, (float(stage_score), teacher_feedback.strip(), hist['assignment_id'], hist['student_id']))

    return {'success': True, 'message': 'Đã lưu đánh giá tiến trình thành công!'}

# ==========================================
# 6. RUBRIC ASSESSMENT (ĐÁNH GIÁ THEO TIÊU CHÍ)
# ==========================================

def create_rubric(assignment_id, title, description, criteria_list, created_by):
    """Tạo Rubric đánh giá đa tiêu chí cho bài tập"""
    if not title or not criteria_list:
        return {'success': False, 'message': 'Tiêu đề và danh sách tiêu chí không được để trống.'}

    rubric_id = execute_db("""
        INSERT INTO rubrics (assignment_id, title, description, created_by)
        VALUES (?, ?, ?, ?)
    """, (assignment_id, title.strip(), description.strip(), created_by))

    total_weight = 0.0
    for crit in criteria_list:
        w = float(crit.get('weight_pct', 25.0))
        total_weight += w
        levels_json = json.dumps(crit.get('levels', [
            {"name": "Xuất sắc", "points": 10},
            {"name": "Đạt yêu cầu", "points": 7},
            {"name": "Cần cải thiện", "points": 4}
        ]), ensure_ascii=False)

        execute_db("""
            INSERT INTO rubric_criteria (rubric_id, criterion_name, description, weight_pct, max_points, levels_json)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (rubric_id, crit.get('criterion_name', 'Tiêu chí'), crit.get('description', ''),
              w, float(crit.get('max_points', 10.0)), levels_json))

    return {'success': True, 'rubric_id': rubric_id, 'message': f'Đã thiết lập Rubric đánh giá ({len(criteria_list)} tiêu chí, tổng trọng số: {total_weight}%).'}

def get_rubric_for_assignment(assignment_id):
    """Lấy Rubric và các tiêu chí của một bài tập"""
    rubric = query_db("SELECT * FROM rubrics WHERE assignment_id = ? ORDER BY id DESC LIMIT 1", (assignment_id,), one=True)
    if not rubric:
        return None

    criteria = query_db("SELECT * FROM rubric_criteria WHERE rubric_id = ? ORDER BY id ASC", (rubric['id'],))
    crit_list = []
    for c in criteria:
        cd = dict(c)
        try:
            cd['levels'] = json.loads(cd['levels_json'])
        except Exception:
            cd['levels'] = []
        crit_list.append(cd)

    d = dict(rubric)
    d['criteria'] = crit_list
    return d

def grade_with_rubric(rubric_id, submission_id, evaluations, evaluator_id):
    """
    Chấm bài bằng Rubric: tính toán chính xác tổng điểm theo trọng số từng tiêu chí.
    Công thức: Total = SUM((awarded_points / max_points) * weight_pct)
    """
    criteria = {c['id']: c for c in query_db("SELECT * FROM rubric_criteria WHERE rubric_id = ?", (rubric_id,))}
    
    total_score = 0.0
    total_weight = 0.0

    # Xóa các đánh giá cũ nếu có
    execute_db("DELETE FROM rubric_evaluations WHERE rubric_id = ? AND submission_id = ?", (rubric_id, submission_id))

    for ev in evaluations:
        cid = int(ev.get('criterion_id'))
        if cid in criteria:
            crit = criteria[cid]
            pts = float(ev.get('awarded_points', 0.0))
            max_pts = float(crit['max_points'] or 10.0)
            weight = float(crit['weight_pct'] or 25.0)
            fb = ev.get('feedback', '').strip()

            execute_db("""
                INSERT INTO rubric_evaluations (rubric_id, submission_id, evaluator_id, criterion_id, awarded_points, feedback)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (rubric_id, submission_id, evaluator_id, cid, pts, fb))

            # Tỉ lệ điểm của tiêu chí
            score_ratio = min(1.0, max(0.0, pts / max_pts))
            total_score += score_ratio * (weight / 10.0) # Quy chuẩn về thang điểm 10
            total_weight += weight

    final_score = round(min(10.0, total_score), 2)

    # Cập nhật điểm chính thức vào bảng submissions
    execute_db("""
        UPDATE submissions 
        SET score = ?, feedback = 'Đã chấm theo Rubric tiêu chuẩn.', graded_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (final_score, submission_id))

    return {
        'success': True,
        'final_score': final_score,
        'total_weight': total_weight,
        'message': f'Đã lưu kết quả chấm Rubric thành công! Tổng điểm đạt: {final_score}/10.'
    }
