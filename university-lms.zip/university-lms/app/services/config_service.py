import os
from database import get_setting, set_setting, query_db

# Load environment variable with fallback to database setting, then hardcoded default
def get_config(key, default=None):
    # 1. Environment variable
    env_val = os.environ.get(key.upper())
    if env_val is not None:
        return env_val
    # 2. Database system_settings
    db_val = get_setting(key.lower(), None)
    if db_val is not None:
        return db_val
    return default

def is_feature_enabled(feature_name, default=True):
    val = get_config(f"feature_{feature_name}_enabled", "1" if default else "0")
    return str(val).strip().lower() in ('1', 'true', 'yes', 'on')

def get_all_system_configs():
    rows = query_db("SELECT key, value, updated_at FROM system_settings ORDER BY key")
    return {r['key']: r['value'] for r in rows}

def update_system_config(key, value):
    set_setting(key.lower(), str(value))
