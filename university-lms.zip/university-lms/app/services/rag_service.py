import os
import re
import json
from database import query_db, execute_db
from services.ai_gateway import call_ai

def chunk_text(text, chunk_size=350, overlap=50):
    """Splits raw text into overlapping chunks."""
    words = text.split()
    chunks = []
    if not words:
        return chunks
    i = 0
    while i < len(words):
        chunk_words = words[i:i + chunk_size]
        chunks.append(" ".join(chunk_words))
        i += (chunk_size - overlap)
    return chunks

def extract_keywords(text):
    """Extract simple alphanumeric keywords for ranking."""
    words = re.findall(r'\b[a-zA-ZÀ-ỹ0-9_]{3,}\b', text.lower())
    stop_words = {'cho', 'các', 'của', 'trong', 'với', 'được', 'những', 'này', 'theo', 'trên', 'hoặc', 'và', 'là', 'có', 'thì'}
    return list(set(w for w in words if w not in stop_words))[:20]

def index_material_document(material_id):
    """
    Index a course material into ai_document_chunks.
    If the file exists locally, reads its content; otherwise indexes title and description.
    """
    material = query_db("SELECT * FROM materials WHERE id = ?", (material_id,), one=True)
    if not material:
        return 0

    # Delete previous chunks if re-indexing
    execute_db("DELETE FROM ai_document_chunks WHERE material_id = ?", (material_id,))

    content_parts = [material['title'], material['description'] or '']

    # Try reading file if available
    file_path = material['file_path']
    # Resolve relative to static or full
    real_path = file_path
    if file_path.startswith('/static/'):
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        real_path = os.path.join(base_dir, file_path.lstrip('/'))

    if os.path.exists(real_path) and os.path.isfile(real_path):
        try:
            if real_path.endswith(('.txt', '.md', '.py', '.sql', '.html')):
                with open(real_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content_parts.append(f.read())
            else:
                # Binary/PDF placeholder representation
                content_parts.append(f"Tài liệu môn học: {material['title']}. Định dạng {material['file_type']}. Nội dung hướng dẫn học phần và ôn tập.")
        except Exception:
            pass

    full_text = "\n\n".join(p for p in content_parts if p)
    chunks = chunk_text(full_text)
    if not chunks:
        chunks = [full_text]

    for idx, c in enumerate(chunks):
        kws = extract_keywords(c)
        execute_db("""
            INSERT INTO ai_document_chunks (material_id, course_id, chunk_index, content, keywords_json, char_count)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (material['id'], material['course_id'], idx + 1, c, json.dumps(kws, ensure_ascii=False), len(c)))

    return len(chunks)

def ensure_course_materials_indexed(course_id):
    """Ensure all materials in a course have chunks indexed."""
    mats = query_db("SELECT id FROM materials WHERE course_id = ?", (course_id,))
    for m in mats:
        count = query_db("SELECT COUNT(*) as c FROM ai_document_chunks WHERE material_id = ?", (m['id'],), one=True)['c']
        if count == 0:
            index_material_document(m['id'])

def search_relevant_chunks(course_id, query_text, top_k=3):
    """
    Search relevant document chunks scoped strictly to the specified course_id.
    """
    ensure_course_materials_indexed(course_id)
    chunks = query_db("""
        SELECT adc.*, m.title as material_title, m.file_type
        FROM ai_document_chunks adc
        JOIN materials m ON adc.material_id = m.id
        WHERE adc.course_id = ?
    """, (course_id,))

    query_kws = set(extract_keywords(query_text))
    scored = []
    for c in chunks:
        c_kws = set(json.loads(c['keywords_json']) if c['keywords_json'] else [])
        overlap = len(query_kws.intersection(c_kws))
        # Direct word in content boost
        content_lower = c['content'].lower()
        query_words = query_text.lower().split()
        for w in query_words:
            if len(w) > 3 and w in content_lower:
                overlap += 1.5
        scored.append((overlap, c))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [item[1] for item in scored[:top_k] if item[0] > 0]

def query_rag_learning_assistant(user_id, role, course_id, user_question, ip='127.0.0.1'):
    """
    RAG Assistant: Enforces RBAC course enrollment check, finds chunks, and calls AI Gateway.
    """
    # 1. Strict Security Access Control:
    if role == 'student':
        enrolled = query_db("SELECT id FROM enrollments WHERE course_id = ? AND student_id = ?", (course_id, user_id), one=True)
        if not enrolled:
            return {
                "success": False,
                "status": "FORBIDDEN",
                "content": "Bảo mật: Bạn không có quyền truy cập vào tài liệu của lớp học phần này.",
                "sources": []
            }
    elif role == 'teacher':
        owned = query_db("SELECT id FROM courses WHERE id = ? AND teacher_id = ?", (course_id, user_id), one=True)
        if not owned:
            return {
                "success": False,
                "status": "FORBIDDEN",
                "content": "Bảo mật: Bạn không phụ trách lớp học phần này.",
                "sources": []
            }

    course = query_db("SELECT name, code FROM courses WHERE id = ?", (course_id,), one=True)
    course_name = course['name'] if course else f"Môn học #{course_id}"

    # 2. Retrieve scoped chunks
    matched_chunks = search_relevant_chunks(course_id, user_question, top_k=3)

    sources = []
    context_str = ""
    if matched_chunks:
        for idx, ch in enumerate(matched_chunks):
            sources.append({
                "material_title": ch['material_title'],
                "file_type": ch['file_type'],
                "chunk_index": ch['chunk_index'],
                "snippet": ch['content'][:180] + ("..." if len(ch['content']) > 180 else "")
            })
            context_str += f"\n[TRÍCH DẪN NGUỒN {idx+1}: {ch['material_title']} (Đoạn {ch['chunk_index']})]:\n{ch['content']}\n"
    else:
        context_str = "KHÔNG TÌM THẤY ĐOẠN TÀI LIỆU NÀO PHÙ HỢP TRONG LỚP HỌC PHẦN."

    # 3. Construct system prompt
    system_instruction = (
        f"Bạn là Trợ lý Học tập AI thông minh cho học phần '{course_name}'. "
        "Hãy giải thích rõ ràng, chi tiết, sư phạm, khuyến khích tư duy. "
        "QUY TẮC RAG BẮT BUỘC: Nếu câu hỏi yêu cầu kiến thức từ tài liệu học phần, "
        "bạn phải trả lời dựa trên phần [TRÍCH DẪN NGUỒN] được cung cấp dưới đây. "
        "Nếu không có nguồn phù hợp, hãy nói rõ: 'Hiện tại tài liệu trong lớp chưa có thông tin chi tiết về phần này, nhưng theo kiến thức chung...'."
    )

    full_prompt = f"TÀI LIỆU HỌC PHẦN:\n{context_str}\n\nCÂU HỎI CỦA SINH VIÊN:\n{user_question}"

    ai_res = call_ai(
        prompt=full_prompt,
        system_instruction=system_instruction,
        user_id=user_id,
        role=role,
        service_name='rag',
        ip=ip
    )

    ai_res['sources'] = sources
    return ai_res
