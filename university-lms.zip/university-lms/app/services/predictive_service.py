import json
from database import query_db, execute_db

def evaluate_student_risk(student_id, course_id):
    """
    Transparent, explainable risk assessment for a student in a course.
    Returns: dict with risk_level, reasons, metrics, suggested_action.
    """
    # 1. Fetch grade record if exists
    grade = query_db("""
        SELECT * FROM grades WHERE course_id = ? AND student_id = ?
    """, (course_id, student_id), one=True)

    # 2. Fetch assignments & submissions
    assignments = query_db("SELECT id, title, max_points FROM assignments WHERE course_id = ?", (course_id,))
    total_assignments = len(assignments)
    submitted_count = 0
    missing_assignments = []

    for a in assignments:
        sub = query_db("SELECT id, score FROM submissions WHERE assignment_id = ? AND student_id = ?", (a['id'], student_id), one=True)
        if sub:
            submitted_count += 1
        else:
            missing_assignments.append(a['title'])

    # 3. Fetch exam results
    exam_results = query_db("""
        SELECT er.*, ex.title FROM exam_results er
        JOIN exams ex ON er.exam_id = ex.id
        WHERE ex.course_id = ? AND er.student_id = ?
    """, (course_id, student_id))

    avg_exam_score = None
    if exam_results:
        avg_exam_score = round(sum(r['score'] for r in exam_results) / len(exam_results), 1)

    # 4. Fetch activity count
    act_count = query_db("""
        SELECT COUNT(*) as c FROM learning_activities WHERE course_id = ? AND user_id = ?
    """, (course_id, student_id), one=True)['c']

    # 5. Compile metrics
    total_score = grade['total_score'] if grade else None
    a1_score = grade['assignment_score'] if grade else None
    a2_score = grade['midterm_score'] if grade else None
    a3_score = grade['final_score'] if grade else None
    letter = grade['letter_grade'] if grade else None

    metrics = {
        "total_score": total_score,
        "a1_score": a1_score,
        "a2_score": a2_score,
        "a3_score": a3_score,
        "letter_grade": letter,
        "total_assignments": total_assignments,
        "submitted_assignments": submitted_count,
        "missing_count": len(missing_assignments),
        "avg_exam_score": avg_exam_score,
        "activities_count": act_count
    }

    reasons = []
    risk_level = "NORMAL"

    # Evaluation Rules
    if total_score is not None and total_score > 0 and total_score < 4.0:
        risk_level = "NEEDS_SUPPORT"
        reasons.append(f"Điểm tổng kết hiện tại ({total_score}) dưới ngưỡng đạt (4.0/10)")
    elif total_score is not None and 4.0 <= total_score < 5.5:
        risk_level = "MONITORING"
        reasons.append(f"Điểm tổng kết ({total_score}) ở mức trung bình yếu")

    if a2_score is not None and a2_score > 0 and a2_score < 4.5:
        if risk_level != "NEEDS_SUPPORT":
            risk_level = "NEEDS_SUPPORT"
        reasons.append(f"Điểm kiểm tra giữa kỳ thấp ({a2_score}/10)")

    if len(missing_assignments) >= 2:
        risk_level = "NEEDS_SUPPORT"
        reasons.append(f"Bỏ lỡ {len(missing_assignments)} bài tập ({', '.join(missing_assignments[:2])})")
    elif len(missing_assignments) == 1:
        if risk_level == "NORMAL":
            risk_level = "MONITORING"
        reasons.append(f"Chưa hoàn thành bài tập: '{missing_assignments[0]}'")

    if avg_exam_score is not None and avg_exam_score < 4.5:
        if risk_level != "NEEDS_SUPPORT":
            risk_level = "MONITORING"
        reasons.append(f"Điểm thi trắc nghiệm trung bình chưa đạt ({avg_exam_score}/10)")

    if risk_level == "NORMAL" and act_count == 0 and total_assignments > 0:
        risk_level = "MONITORING"
        reasons.append("Chưa có lượt tương tác hoặc truy cập học liệu trong lớp")

    # Suggested actions
    if risk_level == "NEEDS_SUPPORT":
        suggested_action = "Gặp trao đổi học thuật cá nhân, hướng dẫn làm lại bài tập và củng cố kiến thức nền tảng."
    elif risk_level == "MONITORING":
        suggested_action = "Nhắc nhở hoàn thành bài tập còn thiếu và gợi ý đọc tài liệu trọng tâm."
    else:
        suggested_action = "Tiếp tục duy trì tiến độ và kết quả học tập tốt."

    return {
        "risk_level": risk_level,
        "reasons": reasons,
        "metrics": metrics,
        "suggested_action": suggested_action
    }

def scan_and_sync_course_risks(course_id=None):
    """
    Scan enrollments and upsert into student_interventions.
    """
    if course_id:
        enrollments = query_db("SELECT course_id, student_id FROM enrollments WHERE course_id = ?", (course_id,))
    else:
        enrollments = query_db("SELECT course_id, student_id FROM enrollments")

    for en in enrollments:
        cid = en['course_id']
        sid = en['student_id']
        eval_res = evaluate_student_risk(sid, cid)

        execute_db("""
            INSERT INTO student_interventions (student_id, course_id, risk_level, reasons_json, metrics_json, suggested_action, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(student_id, course_id) DO UPDATE SET
                risk_level = excluded.risk_level,
                reasons_json = excluded.reasons_json,
                metrics_json = excluded.metrics_json,
                suggested_action = excluded.suggested_action,
                updated_at = CURRENT_TIMESTAMP
        """, (sid, cid, eval_res['risk_level'], json.dumps(eval_res['reasons'], ensure_ascii=False),
              json.dumps(eval_res['metrics'], ensure_ascii=False), eval_res['suggested_action']))

def get_at_risk_students(course_id=None, risk_level=None, status=None, limit=100):
    """
    Retrieve at-risk students with details.
    """
    query = """
        SELECT si.*, u.full_name as student_name, u.email as student_email,
               s.student_code, sc.name as class_name, c.name as course_name, c.code as course_code
        FROM student_interventions si
        JOIN users u ON si.student_id = u.id
        LEFT JOIN students s ON u.id = s.user_id
        LEFT JOIN student_classes sc ON s.student_class_id = sc.id
        JOIN courses c ON si.course_id = c.id
        WHERE 1=1
    """
    params = []
    if course_id:
        query += " AND si.course_id = ?"
        params.append(course_id)
    if risk_level:
        query += " AND si.risk_level = ?"
        params.append(risk_level)
    if status:
        query += " AND si.status = ?"
        params.append(status)

    query += " ORDER BY CASE si.risk_level WHEN 'NEEDS_SUPPORT' THEN 1 WHEN 'MONITORING' THEN 2 ELSE 3 END, si.id DESC LIMIT ?"
    params.append(limit)

    rows = query_db(query, tuple(params))
    res = []
    for r in rows:
        d = dict(r)
        d['reasons'] = json.loads(d['reasons_json']) if d['reasons_json'] else []
        d['metrics'] = json.loads(d['metrics_json']) if d['metrics_json'] else {}
        res.append(d)
    return res

def update_intervention_status(intervention_id, status, notes='', teacher_id=None):
    """Update teacher intervention review status."""
    execute_db("""
        UPDATE student_interventions
        SET status = ?, teacher_notes = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (status, notes, teacher_id, intervention_id))
