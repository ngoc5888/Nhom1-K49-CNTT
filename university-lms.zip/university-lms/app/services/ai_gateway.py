import os
import json
import urllib.request
import urllib.error
from database import query_db, execute_db, get_setting
from services.config_service import get_config

def get_ai_settings():
    """Retrieve current AI configuration."""
    api_enabled = get_config('AI_API_ENABLED', '0') == '1'
    api_key = get_config('AI_API_KEY', '') or ''
    provider = get_config('AI_PROVIDER', 'gemini')
    model = get_config('AI_MODEL', 'gemini-1.5-flash')
    temperature = float(get_config('AI_TEMPERATURE', '0.7'))
    daily_limit = int(get_config('AI_DAILY_TOKEN_LIMIT', '50000'))
    return {
        "enabled": api_enabled,
        "api_key": api_key.strip(),
        "provider": provider,
        "model": model,
        "temperature": temperature,
        "daily_limit": daily_limit
    }

def check_user_daily_limit(user_id, daily_limit):
    """Check if user has exceeded their daily token limit."""
    res = query_db("""
        SELECT COALESCE(SUM(total_tokens), 0) as used_today
        FROM ai_usage_logs
        WHERE user_id = ? AND date(created_at) = date('now')
    """, (user_id,), one=True)
    used = res['used_today'] if res else 0
    return used, used >= daily_limit

def log_ai_usage(user_id, role, service_name, model, prompt_tokens, completion_tokens, status, error_msg='', ip='127.0.0.1'):
    """Record an AI usage transaction."""
    total = prompt_tokens + completion_tokens
    try:
        execute_db("""
            INSERT INTO ai_usage_logs (user_id, user_role, service_name, model_used, prompt_tokens, completion_tokens, total_tokens, status, error_message, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, role, service_name, model, prompt_tokens, completion_tokens, total, status, error_msg[:250], ip))
    except Exception as e:
        print(f"[AI_USAGE_LOG_ERROR] {e}")

def call_ai(prompt, system_instruction=None, user_id=None, role='student', service_name='chat', ip='127.0.0.1'):
    """
    Central AI Gateway caller. Handles configuration, limits, network request, and logging.
    Returns: dict with {success: bool, status: str, content: str, tokens: int, error: str}
    """
    cfg = get_ai_settings()

    # 1. Check if AI is enabled and API key is present
    if not cfg['enabled'] or not cfg['api_key']:
        msg = ("Dịch vụ AI hiện đang tắt hoặc chưa được cấu hình Google Gemini API Key. "
               "Quản trị viên có thể vào trang Quản lý AI & Usage (/admin/ai-usage) "
               "hoặc thiết lập biến môi trường AI_API_KEY trong file .env để kích hoạt.")
        if user_id:
            log_ai_usage(user_id, role, service_name, cfg['model'], 0, 0, 'NO_KEY', 'API Key not configured', ip)
        return {
            "success": False,
            "status": "NO_KEY",
            "content": msg,
            "tokens": 0,
            "error": "API Key not configured"
        }

    # 2. Check token limit
    if user_id:
        used_today, exceeded = check_user_daily_limit(user_id, cfg['daily_limit'])
        if exceeded:
            msg = f"Bạn đã đạt giới hạn sử dụng AI trong ngày ({used_today}/{cfg['daily_limit']} tokens). Vui lòng thử lại vào ngày mai."
            log_ai_usage(user_id, role, service_name, cfg['model'], 0, 0, 'LIMIT_EXCEEDED', 'Daily limit reached', ip)
            return {
                "success": False,
                "status": "LIMIT_EXCEEDED",
                "content": msg,
                "tokens": 0,
                "error": "Daily token limit reached"
            }

    # 3. Call Google Gemini API
    endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{cfg['model']}:generateContent?key={cfg['api_key']}"

    contents = []
    if system_instruction:
        contents.append({
            "role": "user",
            "parts": [{"text": f"[CHỈ DẪN HỆ THỐNG]: {system_instruction}"}]
        })
        contents.append({
            "role": "model",
            "parts": [{"text": "Đã hiểu và sẵn sàng tuân thủ chỉ dẫn hệ thống."}]
        })

    contents.append({
        "role": "user",
        "parts": [{"text": prompt}]
    })

    payload = {
        "contents": contents,
        "generationConfig": {
            "temperature": cfg['temperature'],
            "maxOutputTokens": 2048
        }
    }

    req_data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        endpoint,
        data=req_data,
        headers={"Content-Type": "application/json"}
    )

    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            res_body = response.read().decode('utf-8')
            res_json = json.loads(res_body)

            candidates = res_json.get('candidates', [])
            if not candidates:
                raise ValueError("AI trả về phản hồi rỗng.")

            content_text = ""
            for part in candidates[0].get('content', {}).get('parts', []):
                content_text += part.get('text', '')

            usage = res_json.get('usageMetadata', {})
            prompt_tokens = usage.get('promptTokenCount', len(prompt.split()) * 2)
            comp_tokens = usage.get('candidatesTokenCount', len(content_text.split()) * 2)
            total_tokens = prompt_tokens + comp_tokens

            if user_id:
                log_ai_usage(user_id, role, service_name, cfg['model'], prompt_tokens, comp_tokens, 'SUCCESS', '', ip)

            return {
                "success": True,
                "status": "SUCCESS",
                "content": content_text,
                "tokens": total_tokens,
                "error": None
            }

    except urllib.error.HTTPError as e:
        err_content = e.read().decode('utf-8') if e.fp else str(e)
        err_msg = f"Lỗi kết nối Gemini API (HTTP {e.code}): {e.reason}"
        if user_id:
            log_ai_usage(user_id, role, service_name, cfg['model'], 0, 0, 'FAILED', f"HTTP {e.code}: {e.reason}", ip)
        return {
            "success": False,
            "status": "FAILED",
            "content": f"{err_msg}. Vui lòng kiểm tra lại API Key hoặc quota sử dụng.",
            "tokens": 0,
            "error": err_msg
        }
    except Exception as e:
        err_msg = f"Lỗi ngoại lệ khi gọi AI: {str(e)}"
        if user_id:
            log_ai_usage(user_id, role, service_name, cfg['model'], 0, 0, 'FAILED', str(e)[:100], ip)
        return {
            "success": False,
            "status": "FAILED",
            "content": "Không thể kết nối đến máy chủ AI vào lúc này. Các tính năng LMS khác vẫn hoạt động bình thường.",
            "tokens": 0,
            "error": err_msg
        }

def get_ai_usage_stats():
    """Compute aggregate AI metrics for Admin Dashboard."""
    total_calls = query_db("SELECT COUNT(*) as c FROM ai_usage_logs", one=True)['c']
    total_tokens = query_db("SELECT COALESCE(SUM(total_tokens), 0) as c FROM ai_usage_logs", one=True)['c']
    total_users = query_db("SELECT COUNT(DISTINCT user_id) as c FROM ai_usage_logs", one=True)['c']

    # Status counts
    success_calls = query_db("SELECT COUNT(*) as c FROM ai_usage_logs WHERE status = 'SUCCESS'", one=True)['c']
    failed_calls = query_db("SELECT COUNT(*) as c FROM ai_usage_logs WHERE status IN ('FAILED', 'NO_KEY')", one=True)['c']

    # Est cost ($0.00015 / 1k tokens approx)
    est_cost_usd = round((total_tokens / 1000.0) * 0.00015, 4)

    # Usage by role
    role_usage = query_db("""
        SELECT user_role, COUNT(*) as call_count, COALESCE(SUM(total_tokens), 0) as token_count
        FROM ai_usage_logs
        GROUP BY user_role
    """)

    # Usage by service
    service_usage = query_db("""
        SELECT service_name, COUNT(*) as call_count, COALESCE(SUM(total_tokens), 0) as token_count
        FROM ai_usage_logs
        GROUP BY service_name
    """)

    # Recent 25 logs
    recent_logs = query_db("""
        SELECT l.*, u.full_name, u.email
        FROM ai_usage_logs l
        JOIN users u ON l.user_id = u.id
        ORDER BY l.created_at DESC
        LIMIT 25
    """)

    return {
        "total_calls": total_calls,
        "total_tokens": total_tokens,
        "total_users": total_users,
        "success_calls": success_calls,
        "failed_calls": failed_calls,
        "est_cost_usd": est_cost_usd,
        "role_usage": [dict(r) for r in role_usage],
        "service_usage": [dict(s) for s in service_usage],
        "recent_logs": [dict(l) for l in recent_logs],
        "settings": get_ai_settings()
    }
