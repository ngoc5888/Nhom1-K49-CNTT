import sys
import os
import json
import time

# Set UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from __init__ import create_app
from database import query_db, execute_db, DB_PATH
from services.smart_assessment_service import (
    get_question_bank,
    create_bank_question,
    delete_bank_question,
    seed_default_question_bank_if_empty,
    get_question_bank_stats,
    generate_ai_questions,
    create_assessment_matrix,
    get_assessment_matrices,
    get_assessment_matrix_detail,
    generate_exam_from_matrix,
    start_adaptive_practice,
    submit_adaptive_practice_answer,
    get_adaptive_practice_report,
    record_submission_version,
    get_submission_history,
    grade_submission_stage,
    create_rubric,
    get_rubric_for_assignment,
    grade_with_rubric
)
from services.online_coding_service import (
    create_coding_problem,
    get_coding_problems,
    get_coding_problem_detail,
    seed_default_coding_problems,
    run_python_sandbox,
    submit_coding_solution,
    get_student_coding_submissions
)

app = create_app()
app.config['TESTING'] = True
client = app.test_client()

print("==================================================")
print("RUNNING COMPREHENSIVE PHASE 5 VERIFICATION SUITE")
print("==================================================")

# ----------------------------------------------------
# 1. Database Schema & Data Preservation
# ----------------------------------------------------
print("\n[TEST 1] Database Tables & Old Data Preservation:")
with app.app_context():
    tables_rows = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence'")
    tables = [r['name'] for r in tables_rows]
    print(f"Total Tables in DB: {len(tables)}/46")
    phase5_tables = [
        'question_bank', 'assessment_matrices', 'matrix_items',
        'adaptive_test_sessions', 'adaptive_test_answers',
        'process_submissions_history', 'rubrics', 'rubric_criteria',
        'rubric_evaluations', 'coding_problems', 'coding_test_cases', 'coding_submissions'
    ]
    for t in phase5_tables:
        assert t in tables, f"Missing table: {t}"

    u_cnt = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_cnt = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_cnt = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_cnt = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']
    assert u_cnt >= 73, f"Users count changed: {u_cnt}"
    assert c_cnt == 42, f"Courses count changed: {c_cnt}"
    assert e_cnt == 405, f"Enrollments count changed: {e_cnt}"
    assert g_cnt == 248, f"Grades count changed: {g_cnt}"
    print(f"  -> Old data 100% preserved (Users: {u_cnt}, Courses: {c_cnt}, Enrollments: {e_cnt}, Grades: {g_cnt}): PASS")

# ----------------------------------------------------
# 2. Intelligent Question Bank & AI Generation Workflow
# ----------------------------------------------------
print("\n[TEST 2] Intelligent Question Bank & Teacher AI Approval Workflow:")
with app.app_context():
    course = query_db("SELECT id, name FROM courses LIMIT 1", one=True)
    c_id = course['id']
    teacher = query_db("SELECT id FROM users WHERE role = 'teacher' LIMIT 1", one=True)
    t_id = teacher['id']

    # Seed default questions if empty
    # Clean previous test generated questions to make test idempotent
    execute_db("DELETE FROM question_bank WHERE question_text = 'Kiểm tra tính toàn vẹn của mô hình?' OR question_text LIKE '%Chương 2 của môn%'")
    seed_default_question_bank_if_empty(c_id, t_id)
    stats = get_question_bank_stats(c_id)
    assert stats['total'] >= 6
    print(f"  -> Question Bank seeded: Total = {stats['total']} (Easy: {stats['easy']}, Med: {stats['medium']}, Hard: {stats['hard']}): PASS")

    # Create custom question in bank
    res_q = create_bank_question(
        course_id=c_id,
        question_text="Kiểm tra tính toàn vẹn của mô hình?",
        options=["Đúng chuẩn", "Sai lệch", "Không rõ", "Tùy ý"],
        correct_answers=[0],
        chapter_num=1,
        difficulty='EASY',
        points=1.0,
        tags=["Kiểm thử", "Toàn vẹn"],
        skills=["Đánh giá"],
        explanation="Đáp án chuẩn xác là phương án đầu tiên.",
        created_by=t_id
    )
    assert res_q['success'] is True
    test_qid = res_q['question_id']

    # Test AI generation (returns unapproved questions for review)
    ai_gen = generate_ai_questions(c_id, chapter_num=2, count=3, difficulty='MEDIUM', teacher_id=t_id)
    assert ai_gen['success'] is True
    assert len(ai_gen['questions']) >= 3
    # Verify AI questions are not yet in question_bank until approved
    all_q_before = query_db("SELECT COUNT(*) as c FROM question_bank WHERE question_text = ?", (ai_gen['questions'][0]['question'],), one=True)['c']
    assert all_q_before == 0
    print("  -> AI Question Generation created unapproved candidates: PASS")

    # Approve one AI question into bank
    approved_q = ai_gen['questions'][0]
    app_res = create_bank_question(
        course_id=c_id,
        question_text=approved_q['question'],
        options=approved_q['options'],
        correct_answers=[approved_q['correct_index']],
        chapter_num=2,
        difficulty=approved_q['difficulty'],
        explanation=approved_q['explanation'],
        created_by=t_id
    )
    assert app_res['success'] is True
    print("  -> Teacher approved and saved AI question into Question Bank: PASS")

    # Clean up test question
    delete_bank_question(test_qid, user_id=t_id)

# ----------------------------------------------------
# 3. Assessment Matrix & 1-Click Exam Generator
# ----------------------------------------------------
print("\n[TEST 3] Assessment Matrix & Automatic Exam Assembly:")
with app.app_context():
    matrix_items = [
        {'chapter_num': 1, 'topic_title': 'Cơ sở nền tảng', 'easy_count': 1, 'medium_count': 1, 'hard_count': 0, 'points_per_question': 1.0},
        {'chapter_num': 2, 'topic_title': 'Kiến trúc cốt lõi', 'easy_count': 0, 'medium_count': 1, 'hard_count': 1, 'points_per_question': 1.0}
    ]
    mat_res = create_assessment_matrix(
        course_id=c_id,
        title="Ma trận Đề thi Chuẩn Phase 5",
        description="Ma trận kiểm tra 4 câu mẫu",
        items=matrix_items,
        created_by=t_id
    )
    assert mat_res['success'] is True
    matrix_id = mat_res['matrix_id']

    # Auto-generate Exam from matrix
    exam_res = generate_exam_from_matrix(matrix_id, exam_title="Đề thi Tự động Ma trận Phase 5", duration_minutes=40, created_by=t_id)
    assert exam_res['success'] is True
    new_exam_id = exam_res['exam_id']
    assert exam_res['questions_count'] >= 4

    # Verify questions in exams table
    exam_qs = query_db("SELECT COUNT(*) as c FROM questions WHERE exam_id = ?", (new_exam_id,), one=True)['c']
    assert exam_qs == exam_res['questions_count']
    print(f"  -> Generated Exam #{new_exam_id} with {exam_qs} questions assembled from Matrix: PASS")

# ----------------------------------------------------
# 4. Adaptive Practice Testing (CAT)
# ----------------------------------------------------
print("\n[TEST 4] Adaptive Practice Testing (Computerized Adaptive Testing):")
with app.app_context():
    student = query_db("SELECT id FROM users WHERE role = 'student' LIMIT 1", one=True)
    s_id = student['id']

    # Start adaptive practice
    start_res = start_adaptive_practice(s_id, c_id, total_questions=3)
    sess_id = start_res['session_id']
    assert start_res['current_difficulty'] == 'MEDIUM'
    assert start_res['question'] is not None
    q1 = start_res['question']

    # Submit correct answer -> should shift difficulty to HARD
    q1_row = query_db("SELECT correct_answers_json FROM question_bank WHERE id = ?", (q1['id'],), one=True)
    correct_idx = json.loads(q1_row['correct_answers_json'])[0]

    ans1_res = submit_adaptive_practice_answer(sess_id, q1['id'], selected_answer_idx=correct_idx, response_time=5)
    assert ans1_res['is_correct'] is True
    assert ans1_res['next_difficulty'] == 'HARD'
    print(f"  -> Step 1 Correct: Difficulty dynamically escalated to {ans1_res['next_difficulty']}: PASS")

    # Step 2: Answer incorrectly -> should shift difficulty down to MEDIUM
    q2 = ans1_res['next_question']
    wrong_idx = (correct_idx + 1) % len(q2['options'])
    ans2_res = submit_adaptive_practice_answer(sess_id, q2['id'], selected_answer_idx=wrong_idx, response_time=8)
    assert ans2_res['is_correct'] is False
    assert ans2_res['next_difficulty'] == 'MEDIUM'
    print(f"  -> Step 2 Incorrect: Difficulty dynamically de-escalated to {ans2_res['next_difficulty']}: PASS")

    # Step 3: Complete test
    q3 = ans2_res['next_question']
    q3_row = query_db("SELECT correct_answers_json FROM question_bank WHERE id = ?", (q3['id'],), one=True)
    c3_idx = json.loads(q3_row['correct_answers_json'])[0]
    ans3_res = submit_adaptive_practice_answer(sess_id, q3['id'], selected_answer_idx=c3_idx, response_time=6)
    assert ans3_res['is_finished'] is True
    assert 'mastery_pct' in ans3_res
    print(f"  -> Adaptive Practice Finished: Final Mastery = {ans3_res['mastery_pct']}%, Advice = {ans3_res['recommendations'][0][:40]}...: PASS")

    # Report verification
    report = get_adaptive_practice_report(sess_id)
    assert report['status'] == 'COMPLETED'
    assert len(report['answers']) == 3
    print("  -> Adaptive Practice Detailed Report verified: PASS")

# ----------------------------------------------------
# 5. Process-based & Rubric Assessment
# ----------------------------------------------------
print("\n[TEST 5] Process-based & Rubric Assessment:")
with app.app_context():
    assign = query_db("SELECT id FROM assignments LIMIT 1", one=True)
    a_id = assign['id']

    # Clean previous run records for test idempotency
    execute_db("DELETE FROM process_submissions_history WHERE assignment_id = ? AND student_id = ?", (a_id, s_id))
    execute_db("DELETE FROM rubric_evaluations WHERE submission_id IN (SELECT id FROM submissions WHERE assignment_id = ? AND student_id = ?)", (a_id, s_id))

    # Process-based: submit milestone v1 and v2
    v1_res = record_submission_version(a_id, s_id, file_path="https://github.com/student/repo/v1", notes="Bản nháp 1", stage_name="Giai đoạn Khởi tạo")
    assert v1_res['version'] == 1

    v2_res = record_submission_version(a_id, s_id, file_path="https://github.com/student/repo/v2", notes="Bản hoàn thiện mã nguồn", stage_name="Giai đoạn Báo cáo")
    assert v2_res['version'] == 2

    history = get_submission_history(a_id, s_id)
    assert len(history) >= 2
    print(f"  -> Process-based Assessment: {len(history)} submission milestones tracked (v1, v2): PASS")

    # Teacher gives milestone feedback
    grade_submission_stage(v2_res['history_id'], stage_score=8.5, teacher_feedback="Tiến độ rất tốt, đã bổ sung test case.", teacher_id=t_id)

    # Rubric assessment: Create rubric with criteria weights (40%, 30%, 30%)
    rub_crits = [
        {'criterion_name': 'Tính đúng đắn thuật toán', 'weight_pct': 40.0, 'max_points': 10.0},
        {'criterion_name': 'Kiến trúc & Tối ưu', 'weight_pct': 30.0, 'max_points': 10.0},
        {'criterion_name': 'Báo cáo & Tài liệu hóa', 'weight_pct': 30.0, 'max_points': 10.0}
    ]
    rub_res = create_rubric(a_id, "Rubric Chuẩn Hóa Phase 5", "Đánh giá 3 tiêu chí", rub_crits, created_by=t_id)
    assert rub_res['success'] is True
    rubric_id = rub_res['rubric_id']

    rubric_obj = get_rubric_for_assignment(a_id)
    assert len(rubric_obj['criteria']) == 3

    # Grade submission using Rubric:
    # Criterion 1: 10/10 (weight 40%) -> 4.0
    # Criterion 2: 8/10  (weight 30%) -> 2.4
    # Criterion 3: 9/10  (weight 30%) -> 2.7
    # Total expected score = 4.0 + 2.4 + 2.7 = 9.1
    sub = query_db("SELECT id FROM submissions WHERE assignment_id = ? AND student_id = ?", (a_id, s_id), one=True)
    ev_list = [
        {'criterion_id': rubric_obj['criteria'][0]['id'], 'awarded_points': 10.0, 'feedback': 'Tuyệt vời'},
        {'criterion_id': rubric_obj['criteria'][1]['id'], 'awarded_points': 8.0, 'feedback': 'Khá tốt'},
        {'criterion_id': rubric_obj['criteria'][2]['id'], 'awarded_points': 9.0, 'feedback': 'Đầy đủ'}
    ]
    grade_res = grade_with_rubric(rubric_id, sub['id'], ev_list, evaluator_id=t_id)
    assert grade_res['success'] is True
    assert grade_res['final_score'] == 9.1
    print(f"  -> Rubric Assessment: Weighted total calculated accurately: {grade_res['final_score']}/10: PASS")

# ----------------------------------------------------
# 6. Online Coding Assessment & Sandbox Security
# ----------------------------------------------------
print("\n[TEST 6] Online Coding Assessment & Sandbox Security Isolation:")
with app.app_context():
    # Seed coding problems
    seed_default_coding_problems(c_id, created_by=t_id)
    problems = get_coding_problems(course_id=c_id)
    assert len(problems) >= 2
    prob = problems[0]
    p_id = prob['id']
    print(f"  -> Seeded {len(problems)} coding problems for course {c_id}: PASS")

    # Security Test 1: Dangerous call with 'import os; os.system()' -> MUST BE BLOCKED
    malicious_code = "import os\nos.system('echo dangerous_action')\nprint(0)"
    sec_res = run_python_sandbox(malicious_code, [{'input_data': '', 'expected_output': '0'}])
    assert sec_res['status'] == 'SECURITY_ERROR'
    assert 'Vi phạm bảo mật' in sec_res['compiler_output']
    print("  -> Sandbox Security Test 1 (import os blocked): PASS")

    # Security Test 2: Dangerous call with 'open()' -> MUST BE BLOCKED
    file_hack_code = "f = open('lms.db', 'r')\nprint(f.read())"
    sec2_res = run_python_sandbox(file_hack_code, [{'input_data': '', 'expected_output': '0'}])
    assert sec2_res['status'] == 'SECURITY_ERROR'
    print("  -> Sandbox Security Test 2 (file access blocked): PASS")

    # Security Test 3: Infinite loop timeout protection
    timeout_code = "while True:\n    pass\n"
    to_res = run_python_sandbox(timeout_code, [{'input_data': '', 'expected_output': '0'}], time_limit_seconds=1.0)
    assert to_res['status'] == 'TIME_LIMIT_EXCEEDED'
    print("  -> Sandbox Security Test 3 (Timeout protection at 1.0s): PASS")

    # Functional Coding Test: Correct code execution
    correct_solution = prob['starter_code']
    sub_res = submit_coding_solution(p_id, s_id, correct_solution, language='python')
    assert sub_res['success'] is True
    assert sub_res['status'] == 'PASSED'
    assert sub_res['score'] == 10.0
    print(f"  -> Valid Code Submission: Passed {sub_res['passed_count']}/{sub_res['total_cases']} test cases, Score: {sub_res['score']}/10: PASS")

# ----------------------------------------------------
# 7. Route & HTTP Endpoints Test (Teacher & Student)
# ----------------------------------------------------
print("\n[TEST 7] HTTP Endpoints Verification:")
with app.app_context():
    teacher_email = query_db("SELECT email FROM users WHERE role = 'teacher' LIMIT 1", one=True)['email']
    student_email = query_db("SELECT email FROM users WHERE role = 'student' LIMIT 1", one=True)['email']

# Teacher Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = t_id
    sess['role'] = 'teacher'
    sess['email'] = teacher_email

r_qbank = client.get('/teacher/question-bank')
assert r_qbank.status_code == 200
assert "Ngân hàng câu hỏi thông minh" in r_qbank.get_data(as_text=True)
print("  -> GET /teacher/question-bank: 200 OK")

r_matrices = client.get('/teacher/assessment-matrices')
assert r_matrices.status_code == 200
assert "Ma trận đề thi chuẩn hóa" in r_matrices.get_data(as_text=True)
print("  -> GET /teacher/assessment-matrices: 200 OK")

r_coding_t = client.get(f'/teacher/courses/{c_id}/coding-assessments')
assert r_coding_t.status_code == 200
assert "Bài tập Lập trình" in r_coding_t.get_data(as_text=True)
print(f"  -> GET /teacher/courses/{c_id}/coding-assessments: 200 OK")

# Student Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = s_id
    sess['role'] = 'student'
    sess['email'] = student_email

r_adaptive_p = client.get('/student/practice/adaptive')
assert r_adaptive_p.status_code == 200
assert "Luyện thi thích ứng thông minh" in r_adaptive_p.get_data(as_text=True)
print("  -> GET /student/practice/adaptive: 200 OK")

r_coding_s = client.get('/student/coding-assessments')
assert r_coding_s.status_code == 200
assert "Bài tập Lập trình Trực tuyến" in r_coding_s.get_data(as_text=True)
print("  -> GET /student/coding-assessments: 200 OK")

r_coding_ws = client.get(f'/student/coding-assessments/{p_id}')
assert r_coding_ws.status_code == 200
assert "Python 3 Sandbox" in r_coding_ws.get_data(as_text=True)
print(f"  -> GET /student/coding-assessments/{p_id}: 200 OK")

# ----------------------------------------------------
# 8. Non-regression Test
# ----------------------------------------------------
print("\n[TEST 8] Core System Non-regression Check:")
anon = app.test_client()
assert anon.get('/login').status_code == 200
assert anon.get('/').status_code == 302
assert anon.get('/api/v1/system/health').status_code == 200
print("  -> Anonymous core routes intact: PASS")

print("\n==================================================")
print("ALL PHASE 5 VERIFICATION TESTS PASSED SUCCESSFULLY!")
print("==================================================")
