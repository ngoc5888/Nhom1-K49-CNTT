import os
import sys
import json
import sqlite3

# Ensure app path is in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from app import create_app
from app.database import get_db, query_db, execute_db
from app.services.ecosystem_service import (
    get_user_calendar_events,
    create_calendar_event,
    delete_calendar_event,
    export_calendar_ics,
    can_access_course_forum,
    get_course_discussions,
    create_discussion_topic,
    get_discussion_detail,
    add_discussion_comment,
    toggle_accepted_answer,
    upvote_discussion,
    toggle_pin_discussion,
    get_course_groups,
    create_course_group,
    join_course_group,
    leave_course_group,
    get_group_detail,
    create_group_task,
    update_group_task_status,
    add_group_resource,
    generate_xapi_statement,
    export_exam_to_qti_xml,
    export_badge_open_badges_json_ld
)

app = create_app()
client = app.test_client()

print("=" * 60)
print("RUNNING FINAL PHASE 7 SYSTEM INTEGRATION & ACCEPTANCE SUITE")
print("=" * 60)

# ----------------------------------------------------
# 1. Database Full Integrity & Schema Verification
# ----------------------------------------------------
print("\n[TEST 1] Database Tables & Old Data Preservation:")
with app.app_context():
    tables = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
    table_names = [t['name'] for t in tables]
    total_tables = len(table_names)
    print(f"Total Tables in DB: {total_tables}/60")
    assert total_tables >= 60, f"Expected at least 60 tables, found {total_tables}"

    # Phase 7 required tables
    p7_tables = [
        'calendar_events', 'course_discussions', 'discussion_comments',
        'course_groups', 'group_members', 'group_tasks', 'group_resources'
    ]
    for pt in p7_tables:
        assert pt in table_names, f"Missing Phase 7 table: {pt}"

    # PRAGMA integrity check
    integrity = query_db("PRAGMA integrity_check", one=True)
    assert integrity[0] == 'ok' or integrity['integrity_check'] == 'ok', "Database integrity check failed!"

    # Verify baseline training & academic data 100% intact
    u_count = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_count = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_count = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_count = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']

    print(f"  -> Old data 100% preserved (Users: {u_count}, Courses: {c_count}, Enrollments: {e_count}, Grades: {g_count}): PASS")
    assert u_count >= 73
    assert c_count >= 42
    assert e_count >= 405
    assert g_count >= 248

    student_user = query_db("SELECT id, email, full_name FROM users WHERE role = 'student' LIMIT 1", one=True)
    teacher_user = query_db("SELECT id, email, full_name FROM users WHERE role = 'teacher' LIMIT 1", one=True)
    admin_user = query_db("SELECT id, email, full_name FROM users WHERE role = 'admin' LIMIT 1", one=True)
    s_id = student_user['id']
    t_id = teacher_user['id']
    a_id = admin_user['id']
    course = query_db("SELECT id, code, name FROM courses LIMIT 1", one=True)
    c_id = course['id']

# ----------------------------------------------------
# 2. Smart Calendar Subsystem
# ----------------------------------------------------
print("\n[TEST 2] Smart Calendar Subsystem:")
with app.app_context():
    # 2.1 Get aggregated events
    cal_events = get_user_calendar_events(s_id, 'student')
    assert isinstance(cal_events, list)
    print(f"  -> Aggregated {len(cal_events)} calendar events (assignments, exams, sessions): PASS")

    # 2.2 Create custom personal event
    ev_res = create_calendar_event(
        user_id=s_id,
        title="Lịch tự ôn tập Python & CSDL",
        start_time="2026-11-15 09:00:00",
        end_time="2026-11-15 11:30:00",
        course_id=c_id,
        description="Ôn tập các lệnh JOIN và Indexing",
        event_type="personal",
        color="#10b981"
    )
    assert ev_res['success'] is True
    event_id = ev_res['event_id']
    print(f"  -> Created personal calendar event #{event_id}: PASS")

    # 2.3 Export iCalendar (.ics)
    ics_str = export_calendar_ics(s_id, 'student')
    assert "BEGIN:VCALENDAR" in ics_str
    assert "END:VCALENDAR" in ics_str
    assert "SUMMARY:" in ics_str
    print("  -> Exported standard iCalendar (.ics) format: PASS")

    # 2.4 Delete personal event
    del_res = delete_calendar_event(event_id, s_id)
    assert del_res['success'] is True
    print("  -> Deleted personal calendar event: PASS")

# ----------------------------------------------------
# 3. Discussion Forum Subsystem
# ----------------------------------------------------
print("\n[TEST 3] Course Discussion Forum Subsystem:")
with app.app_context():
    # 3.1 Permission check
    can_t = can_access_course_forum(t_id, c_id, 'teacher')
    can_a = can_access_course_forum(a_id, c_id, 'admin')
    assert can_a is True
    print("  -> Course forum RBAC validation: PASS")

    # 3.2 Create topic
    top_res = create_discussion_topic(
        course_id=c_id,
        user_id=t_id,
        title="Hướng dẫn làm bài tập lớn & Giải đáp thắc mắc",
        content="Các bạn sinh viên có thể thảo luận và hỏi đáp về yêu cầu kiến trúc hệ thống tại đây.",
        is_pinned=1,
        tags=["BTL", "HuongDan", "KienTruc"]
    )
    assert top_res['success'] is True
    disc_id = top_res['discussion_id']
    print(f"  -> Created discussion topic #{disc_id}: PASS")

    # 3.3 Add comment / answer
    com_res = add_discussion_comment(
        discussion_id=disc_id,
        user_id=s_id,
        content="Thưa thầy, chúng em có thể sử dụng Docker Compose cho bài tập lớn được không ạ?"
    )
    assert com_res['success'] is True
    com_id = com_res['comment_id']

    # 3.4 Teacher answer & accept
    t_com_res = add_discussion_comment(
        discussion_id=disc_id,
        user_id=t_id,
        content="Hoàn toàn được và khuyến khích nhé các em."
    )
    t_com_id = t_com_res['comment_id']
    acc_res = toggle_accepted_answer(t_com_id, t_id)
    assert acc_res['success'] is True
    assert acc_res['is_accepted'] == 1
    print("  -> Added comments and marked accepted helpful answer: PASS")

    # 3.5 Upvote & Detail retrieval
    up_res = upvote_discussion(disc_id)
    assert up_res['success'] is True
    detail = get_discussion_detail(disc_id)
    assert detail is not None
    assert len(detail['comments']) >= 2
    assert detail['is_pinned'] == 1
    print("  -> Discussion detail retrieval & upvotes verified: PASS")

# ----------------------------------------------------
# 4. Group Workspace Subsystem
# ----------------------------------------------------
print("\n[TEST 4] Collaborative Group Workspace Subsystem:")
with app.app_context():
    # Clean previous test group for idempotency
    execute_db("DELETE FROM course_groups WHERE name = 'Nhóm Test Phase 7'")

    # 4.1 Create course group
    grp_res = create_course_group(
        course_id=c_id,
        name="Nhóm Test Phase 7",
        description="Nghiên cứu ứng dụng Deep Learning trong Giáo dục",
        leader_id=s_id,
        max_members=4,
        topic_name="AI Smart Learning"
    )
    assert grp_res['success'] is True
    g_id = grp_res['group_id']
    print(f"  -> Created course group #{g_id} with leader: PASS")

    # 4.2 Add group task
    task_res = create_group_task(
        group_id=g_id,
        title="Thiết kế kiến trúc hệ thống và luồng dữ liệu",
        description="Vẽ sơ đồ BFD, DFD và thiết kế CSDL",
        assigned_to=s_id,
        due_date="2026-11-20",
        priority="HIGH",
        created_by=s_id
    )
    assert task_res['success'] is True
    t_task_id = task_res['task_id']

    # 4.3 Update task status to DONE
    up_t_res = update_group_task_status(t_task_id, 'DONE')
    assert up_t_res['success'] is True

    # 4.4 Add shared resource
    res_item = add_group_resource(
        group_id=g_id,
        uploaded_by=s_id,
        title="Tài liệu Kiến trúc Phần mềm",
        resource_type="link",
        url_or_path="https://github.com/team/docs",
        notes="Kiến trúc Clean Architecture"
    )
    assert res_item['success'] is True

    # 4.5 Verify group details
    grp_info = get_group_detail(g_id, current_user_id=s_id)
    assert grp_info is not None
    assert grp_info['is_member'] is True
    assert grp_info['is_leader'] is True
    assert len(grp_info['tasks']) >= 1
    assert grp_info['progress_pct'] == 100.0
    assert len(grp_info['resources']) >= 1
    print("  -> Group tasks, resources & progress 100% verified: PASS")

# ----------------------------------------------------
# 5. Interoperability Subsystem (xAPI, QTI 2.1, Open Badges)
# ----------------------------------------------------
print("\n[TEST 5] Interoperability Standards Compliance:")
with app.app_context():
    # 5.1 xAPI Statement
    xapi = generate_xapi_statement(
        actor_email=student_user['email'],
        actor_name=student_user['full_name'],
        verb_id="http://adlnet.gov/expapi/verbs/completed",
        verb_display="Đã hoàn thành",
        object_id=f"http://lms.university.edu/courses/{c_id}",
        object_name="Khóa học Lập trình Web",
        object_type="course",
        result={"score": {"raw": 9.5, "max": 10.0}}
    )
    assert xapi['actor']['mbox'] == f"mailto:{student_user['email']}"
    assert xapi['verb']['id'] == "http://adlnet.gov/expapi/verbs/completed"
    print("  -> Standard xAPI Statement generated: PASS")

    # 5.2 QTI 2.1 XML Exam Export
    exam = query_db("SELECT id FROM exams LIMIT 1", one=True)
    if exam:
        qti_xml = export_exam_to_qti_xml(exam['id'])
        assert "<?xml" in qti_xml
        assert "assessmentItem" in qti_xml
        print("  -> Exported IMS QTI 2.1 XML Exam Package: PASS")

    # 5.3 Open Badges 2.0 / W3C JSON-LD Export
    st_badge = query_db("SELECT id FROM student_badges LIMIT 1", one=True)
    if st_badge:
        ob_json = export_badge_open_badges_json_ld(st_badge['id'])
        assert ob_json is not None
        assert "https://w3id.org/openbadges/v2" in ob_json['@context']
        assert ob_json['type'] == "Assertion"
        assert "recipient" in ob_json
        print("  -> Exported Open Badges 2.0 JSON-LD Credential: PASS")

# ----------------------------------------------------
# 6. Graceful AI Fallback when Offline/No API Key
# ----------------------------------------------------
print("\n[TEST 6] Graceful AI Degradation & Offline Stability:")
with app.app_context():
    from app.services.ai_gateway import call_ai
    # Request AI without API key or when API is disabled
    fallback_resp = call_ai("Giải thích khái niệm cơ sở dữ liệu quan hệ", role='student')
    assert isinstance(fallback_resp, dict)
    assert 'content' in fallback_resp or 'error' in fallback_resp
    print("  -> AI Gateway Graceful Fallback & Offline handling verified: PASS")

# ----------------------------------------------------
# 7. End-to-End HTTP Route Tests Across Roles
# ----------------------------------------------------
print("\n[TEST 7] Comprehensive HTTP Endpoints Verification:")

# 7.1 Student Role Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = s_id
    sess['role'] = 'student'
    sess['email'] = student_user['email']

endpoints_student = [
    ('/student/dashboard', "Dashboard Học tập"),
    ('/student/classes', "Lớp học phần"),
    ('/calendar', "Lịch học & Công việc Thông minh"),
    ('/student/competencies', "Bản đồ Năng lực Cá nhân"),
    ('/student/portfolio', "Hồ sơ Năng lực Số"),
    ('/student/badges', "Hệ thống Huy hiệu"),
    ('/student/practice/adaptive', "Luyện thi thích ứng"),
    ('/student/coding-assessments', "Bài tập Lập trình Trực tuyến"),
    (f'/courses/{c_id}/discussions', "Diễn đàn Thảo luận"),
    (f'/courses/{c_id}/groups', "Không gian Làm việc & Đồ án Nhóm")
]
for route, label in endpoints_student:
    r = client.get(route)
    assert r.status_code == 200, f"Route {route} failed with {r.status_code}"
    print(f"  -> [Student] GET {route}: 200 OK ({label})")

# 7.2 Teacher Role Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = t_id
    sess['role'] = 'teacher'
    sess['email'] = teacher_user['email']

endpoints_teacher = [
    ('/teacher/dashboard', "Dashboard"),
    ('/teacher/classes', "Lớp học phần"),
    ('/teacher/question-bank', "Ngân hàng câu hỏi"),
    ('/teacher/assessment-matrices', "Ma trận đề thi"),
    ('/teacher/competencies', "Xác thực Năng lực"),
    ('/calendar', "Lịch giảng dạy & Deadline"),
    (f'/courses/{c_id}/discussions', "Diễn đàn")
]
for route, label in endpoints_teacher:
    r = client.get(route)
    assert r.status_code == 200, f"Route {route} failed with {r.status_code}"
    print(f"  -> [Teacher] GET {route}: 200 OK ({label})")

# 7.3 Admin Role Endpoints
with client.session_transaction() as sess:
    sess['user_id'] = a_id
    sess['role'] = 'admin'
    sess['email'] = admin_user['email']

endpoints_admin = [
    ('/admin/dashboard', "Admin Dashboard"),
    ('/admin/users', "Tài khoản"),
    ('/admin/education', "Quản lý Đào tạo"),
    ('/admin/reports', "Báo cáo"),
    ('/admin/analytics', "Learning Analytics"),
    ('/admin/ai-usage', "Quản lý AI"),
    ('/admin/competencies', "Chuẩn Năng lực"),
    ('/admin/badges', "Huy hiệu số"),
    ('/calendar', "Lịch toàn trường")
]
for route, label in endpoints_admin:
    r = client.get(route)
    assert r.status_code == 200, f"Route {route} failed with {r.status_code}"
    print(f"  -> [Admin] GET {route}: 200 OK ({label})")

# 7.4 Public & Interoperability Endpoints
client.get('/logout') # anonymous
r_ics = client.get('/calendar/export.ics')
# calendar export requires login
assert r_ics.status_code in [200, 302]

r_xapi = client.get('/api/v1/interop/xapi/statements')
assert r_xapi.status_code == 200
print("  -> GET /api/v1/interop/xapi/statements: 200 OK")

if exam:
    r_qti = client.get(f'/api/v1/interop/exams/{exam["id"]}/qti.xml')
    assert r_qti.status_code == 200
    print(f"  -> GET /api/v1/interop/exams/{exam['id']}/qti.xml: 200 OK")

# ----------------------------------------------------
# 8. Security & RBAC Enforcement
# ----------------------------------------------------
print("\n[TEST 8] Security & Role-Based Access Control (RBAC):")
# Student attempting to access Admin endpoint -> MUST BE REDIRECTED/BLOCKED
with client.session_transaction() as sess:
    sess['user_id'] = s_id
    sess['role'] = 'student'
    sess['email'] = student_user['email']

r_block_admin = client.get('/admin/dashboard')
assert r_block_admin.status_code in [302, 403]
print("  -> Student blocked from accessing Admin Dashboard: PASS")

r_block_teacher = client.get('/teacher/dashboard')
assert r_block_teacher.status_code in [302, 403]
print("  -> Student blocked from accessing Teacher Dashboard: PASS")

print("\n" + "=" * 60)
print("ALL PHASE 7 FINAL ACCEPTANCE TESTS PASSED 100% SUCCESSFULLY!")
print("=" * 60)
