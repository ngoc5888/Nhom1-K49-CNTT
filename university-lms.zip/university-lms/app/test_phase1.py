import sys
import os
import json
import sqlite3

# Set UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from __init__ import create_app
from database import query_db, get_setting, set_setting, DB_PATH
from backup_recovery import backup_database, restore_database, verify_db_integrity

app = create_app()
app.config['TESTING'] = True
client = app.test_client()

print("==================================================")
print("RUNNING COMPREHENSIVE PHASE 1 VERIFICATION SUITE")
print("==================================================")

# 1. Database Schema & Migration Verification
print("\n[TEST 1] Database Tables & Migration Check:")
with app.app_context():
    tables_rows = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence'")
    tables = [r['name'] for r in tables_rows]
    print(f"Total Tables in DB: {len(tables)}/24")
    assert 'audit_logs' in tables, "audit_logs table missing"
    assert 'learning_activities' in tables, "learning_activities table missing"
    assert 'login_history' in tables, "login_history table missing"
    print("  -> New Phase 1 tables exist: PASS")

    # Verify existing data preserved
    u_cnt = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_cnt = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_cnt = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_cnt = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']
    assert u_cnt >= 73, f"Users count changed: {u_cnt}"
    assert c_cnt == 42, f"Courses count changed: {c_cnt}"
    assert e_cnt == 405, f"Enrollments count changed: {e_cnt}"
    assert g_cnt == 248, f"Grades count changed: {g_cnt}"
    print(f"  -> Old data preserved (Users: {u_cnt}, Courses: {c_cnt}, Enrollments: {e_cnt}, Grades: {g_cnt}): PASS")

# 2. Login & Login History Check
print("\n[TEST 2] Authentication & Login History Tracking:")
client.get('/logout')
# Failed login attempt
res = client.post('/login', data={'email': 'student@example.com', 'password': 'wrongpassword'}, follow_redirects=True)
with app.app_context():
    failed_log = query_db("SELECT * FROM login_history WHERE email = 'student@example.com' AND status = 'FAILED' ORDER BY id DESC LIMIT 1", one=True)
    assert failed_log is not None, "Failed login was not recorded in login_history"
    print("  -> Failed login recorded in login_history: PASS")

# Successful login
res = client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
assert res.status_code == 200
with app.app_context():
    succ_log = query_db("SELECT * FROM login_history WHERE email = 'student@example.com' AND status = 'SUCCESS' ORDER BY id DESC LIMIT 1", one=True)
    assert succ_log is not None, "Successful login was not recorded in login_history"
    print("  -> Successful login recorded in login_history: PASS")

# 3. Learning Activity Tracking
print("\n[TEST 3] Learning Activity Tracking:")
# Student views class detail
res = client.get('/student/class/1')
assert res.status_code == 200
with app.app_context():
    student_u = query_db("SELECT id FROM users WHERE email = 'student@example.com'", one=True)
    act = query_db("SELECT * FROM learning_activities WHERE user_id = ? AND event_type = 'VIEW_COURSE' ORDER BY id DESC LIMIT 1", (student_u['id'],), one=True)
    assert act is not None, "VIEW_COURSE was not recorded in learning_activities"
    print(f"  -> Student course view activity recorded (Event: {act['event_type']}, Course ID: {act['course_id']}): PASS")

# 4. Standardized API Endpoints & RBAC Security
print("\n[TEST 4] Standardized API (/api/v1) & Security:")
# Health endpoint (public)
res = client.get('/api/v1/system/health')
assert res.status_code == 200
data = res.get_json()
assert data['success'] is True and data['data']['status'] == 'UP'
print("  -> GET /api/v1/system/health (200 OK): PASS")

# API Profile for student
res = client.get('/api/v1/auth/me')
assert res.status_code == 200
data = res.get_json()
assert data['data']['email'] == 'student@example.com' and data['data']['role'] == 'student'
print("  -> GET /api/v1/auth/me for student (200 OK): PASS")

# Student accesses paginated courses
res = client.get('/api/v1/courses?page=1&per_page=5')
assert res.status_code == 200
data = res.get_json()
assert data['success'] is True
assert 'meta' in data and data['meta']['per_page'] == 5
print(f"  -> GET /api/v1/courses paginated ({len(data['data'])} items): PASS")

# Cross-role access test: Student tries to access Admin Audit Logs API
res = client.get('/api/v1/admin/audit-logs')
assert res.status_code == 403, f"Expected 403 Forbidden for student on admin endpoint, got {res.status_code}"
print("  -> Security Test: Student blocked from /api/v1/admin/audit-logs (403 Forbidden): PASS")

# 5. Admin API & Audit Logging
print("\n[TEST 5] Admin API & System Config Audit Logging:")
client.get('/logout')
res = client.post('/login', data={'email': 'admin@example.com', 'password': 'admin123'}, follow_redirects=True)
assert res.status_code == 200

# Admin accesses audit logs API
res = client.get('/api/v1/admin/audit-logs?per_page=10')
assert res.status_code == 200
data = res.get_json()
assert data['success'] is True and len(data['data']) > 0
print(f"  -> GET /api/v1/admin/audit-logs returned {len(data['data'])} audit logs: PASS")

# Admin reads system configs
res = client.get('/api/v1/admin/system-config')
assert res.status_code == 200
configs = res.get_json()['data']
assert 'ai_model' in configs and 'ai_api_enabled' in configs
print(f"  -> GET /api/v1/admin/system-config returned {len(configs)} configs: PASS")

# Admin updates system config via API
res = client.post('/api/v1/admin/system-config', json={'ai_model': 'gemini-1.5-flash', 'feature_analytics_enabled': '1'})
assert res.status_code == 200
with app.app_context():
    admin_u = query_db("SELECT id FROM users WHERE email = 'admin@example.com'", one=True)
    audit_entry = query_db("SELECT * FROM audit_logs WHERE action = 'CHANGE_SYSTEM_SETTING' ORDER BY id DESC LIMIT 1", one=True)
    assert audit_entry is not None, "Audit log for config update was not recorded"
    print("  -> POST /api/v1/admin/system-config updated & logged in audit_logs: PASS")

# 6. Database Backup & Recovery Test
print("\n[TEST 6] Backup & Recovery Verification:")
backup_file = backup_database()
assert os.path.exists(backup_file)
ok, msg = verify_db_integrity(backup_file)
assert ok is True
print(f"  -> Backup verified with PRAGMA integrity_check ({ok}): PASS")

# Test restoring to a sandbox test path
sandbox_path = os.path.join(os.path.dirname(backup_file), 'sandbox_restore_test.db')
restore_database(backup_file, sandbox_path)
assert os.path.exists(sandbox_path)
s_ok, s_msg = verify_db_integrity(sandbox_path)
assert s_ok is True
if os.path.exists(sandbox_path):
    os.remove(sandbox_path)
print("  -> Restore to sandbox DB tested & verified 100% integrity: PASS")

# 7. Regression Test on All Existing Web Routes
print("\n[TEST 7] Regression Test on Core Application Routes:")
client.get('/logout')
for route in ['/login', '/maintenance', '/system-locked', '/forgot-password']:
    res = client.get(route)
    assert res.status_code == 200, f"Route {route} failed with {res.status_code}"

client.post('/login', data={'email': 'admin@example.com', 'password': 'admin123'}, follow_redirects=True)
for route in ['/admin/dashboard', '/admin/users', '/admin/education', '/admin/reports', '/admin/notifications']:
    res = client.get(route)
    assert res.status_code == 200, f"Admin route {route} failed with {res.status_code}"

client.get('/logout')
client.post('/login', data={'email': 'teacher@example.com', 'password': 'teacher123'}, follow_redirects=True)
for route in ['/teacher/dashboard', '/teacher/classes', '/teacher/materials', '/teacher/assignments', '/teacher/exams', '/teacher/grades']:
    res = client.get(route)
    assert res.status_code == 200, f"Teacher route {route} failed with {res.status_code}"

client.get('/logout')
client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
for route in ['/student/dashboard', '/student/classes', '/student/materials', '/student/assignments', '/student/exams', '/student/academic-results']:
    res = client.get(route)
    assert res.status_code == 200, f"Student route {route} failed with {res.status_code}"

print("  -> All core LMS routes verified (100% 200 OK): PASS")

client.get('/logout')
print("\n==================================================")
print("ALL PHASE 1 TESTS PASSED 100% WITH ZERO ERRORS!")
print("==================================================")
