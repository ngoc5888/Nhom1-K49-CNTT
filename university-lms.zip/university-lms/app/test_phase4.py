import sys
import os
import json
from datetime import date, timedelta

# Set UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from __init__ import create_app
from database import query_db, execute_db, DB_PATH
from services.adaptive_service import (
    ensure_course_topics,
    compute_student_learning_path,
    update_topic_progress,
    get_teacher_adaptive_overview
)
from services.spaced_repetition_service import (
    calculate_sm2,
    process_flashcard_review,
    get_student_flashcards,
    get_flashcard_stats,
    create_flashcard,
    delete_flashcard,
    generate_flashcards_with_ai,
    create_student_note,
    get_student_notes,
    delete_student_note,
    record_study_session,
    get_study_session_stats
)

app = create_app()
app.config['TESTING'] = True
client = app.test_client()

print("==================================================")
print("RUNNING COMPREHENSIVE PHASE 4 VERIFICATION SUITE")
print("==================================================")

# ----------------------------------------------------
# 1. Database Schema & Data Preservation
# ----------------------------------------------------
print("\n[TEST 1] Database Tables & Old Data Preservation:")
with app.app_context():
    tables_rows = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence'")
    tables = [r['name'] for r in tables_rows]
    print(f"Total Tables in DB: {len(tables)}/34")
    for t in ['course_topics', 'student_topic_progress', 'study_notes', 'study_flashcards', 'study_sessions']:
        assert t in tables, f"Missing table: {t}"

    u_cnt = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_cnt = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_cnt = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_cnt = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']
    assert u_cnt >= 73, f"Users count changed: {u_cnt}"
    assert c_cnt == 42, f"Courses count changed: {c_cnt}"
    assert e_cnt == 405, f"Enrollments count changed: {e_cnt}"
    assert g_cnt == 248, f"Grades count changed: {g_cnt}"
    print(f"  -> Old data 100% preserved (Users: {u_cnt}, Courses: {c_cnt}, Enrollments: {e_cnt}, Grades: {g_cnt}): PASS")

# ----------------------------------------------------
# 2. Adaptive Learning Service
# ----------------------------------------------------
print("\n[TEST 2] Adaptive Learning Service & Topic Seeding:")
with app.app_context():
    # Pick a course
    test_course = query_db("SELECT id, name FROM courses LIMIT 1", one=True)
    c_id = test_course['id']

    # Test topic seeding
    topics = ensure_course_topics(c_id)
    assert len(topics) == 4, f"Expected 4 topics, got {len(topics)}"
    assert topics[0]['chapter_num'] == 1
    assert topics[1]['prerequisite_topic_id'] == topics[0]['id']
    print(f"  -> Course {c_id} seeded with 4 structured chapters & prerequisite chain: PASS")

    # Pick an enrolled student
    enrollment = query_db("SELECT student_id FROM enrollments WHERE course_id = ? LIMIT 1", (c_id,), one=True)
    s_id = enrollment['student_id']

    # Compute learning path
    path = compute_student_learning_path(s_id, c_id)
    assert path['selected_course']['id'] == c_id
    assert len(path['topics']) == 4
    assert 'summary' in path
    assert 'adaptive_advice' in path
    print(f"  -> Student {s_id} learning path calculated: Overall Mastery = {path['summary']['overall_mastery']}%, Advice generated: PASS")

    # Update topic progress
    first_topic_id = topics[0]['id']
    update_res = update_topic_progress(s_id, first_topic_id, mastery_score=85.0, status='MASTERED', notes='Đã ôn xong')
    assert update_res['success'] is True
    assert update_res['mastery_score'] == 85.0

    # Re-compute learning path and verify updated progress
    path_updated = compute_student_learning_path(s_id, c_id)
    assert path_updated['topics'][0]['mastery_score'] == 85.0
    assert path_updated['summary']['mastered_topics'] >= 1
    print(f"  -> Topic progress updated & re-computed accurately: PASS")

    # RBAC Isolation: Student cannot update topic of a course they are not enrolled in
    unenrolled_course = query_db(
        "SELECT id FROM courses WHERE id NOT IN (SELECT course_id FROM enrollments WHERE student_id = ?) LIMIT 1",
        (s_id,),
        one=True
    )
    if unenrolled_course:
        unenrolled_topics = ensure_course_topics(unenrolled_course['id'])
        forbidden_res = update_topic_progress(s_id, unenrolled_topics[0]['id'], mastery_score=90.0)
        assert forbidden_res['success'] is False
        print(f"  -> RBAC security verified (unauthorized course topic blocked): PASS")

# ----------------------------------------------------
# 3. Spaced Repetition (SM-2) & Smart Study Service
# ----------------------------------------------------
print("\n[TEST 3] SM-2 Algorithm & Flashcard / Notes Service:")
with app.app_context():
    # Test SM-2 calculation mathematics
    # Rating 1 (Again) -> interval 1, repetition 0, EF decreased
    r1_rep, r1_int, r1_ef, r1_date = calculate_sm2(rating=1, repetition_count=2, ease_factor=2.5, interval_days=6)
    assert r1_rep == 0
    assert r1_int == 1
    assert r1_ef == 2.3

    # Rating 3 (Good) -> repetition + 1, normal interval progression
    r3_rep, r3_int, r3_ef, r3_date = calculate_sm2(rating=3, repetition_count=0, ease_factor=2.5, interval_days=1)
    assert r3_rep == 1
    assert r3_int == 1

    r3_rep2, r3_int2, r3_ef2, r3_date2 = calculate_sm2(rating=3, repetition_count=1, ease_factor=2.5, interval_days=1)
    assert r3_rep2 == 2
    assert r3_int2 == 6
    print("  -> SM-2 algorithm calculations verified: PASS")

    # Test Flashcard creation and review
    card_res = create_flashcard(s_id, "Front Test?", "Back Answer!", course_id=c_id, deck_name="Test Deck")
    assert card_res['success'] is True
    card_id = card_res['card_id']

    rev_res = process_flashcard_review(s_id, card_id, rating=3)
    assert rev_res['success'] is True

    # Check stats
    stats = get_flashcard_stats(s_id)
    assert stats['total_cards'] >= 1
    print(f"  -> Flashcard created and reviewed with SM-2: Total = {stats['total_cards']}: PASS")

    # Test AI Flashcard generation (using fallback if AI offline)
    ai_gen_res = generate_flashcards_with_ai(s_id, c_id, topic_prompt="Định lý toán rời rạc", count=3)
    assert ai_gen_res['success'] is True
    assert len(ai_gen_res['cards']) >= 3
    print(f"  -> AI / Smart Flashcard generation verified ({len(ai_gen_res['cards'])} cards created): PASS")

    # Test Notes CRUD
    note_res = create_student_note(s_id, "Ghi chú ôn thi", "Nội dung ghi chú mẫu", course_id=c_id, is_pinned=1)
    assert note_res['success'] is True
    note_id = note_res['note_id']

    notes = get_student_notes(s_id, course_id=c_id)
    assert any(n['id'] == note_id for n in notes)

    del_note_res = delete_student_note(s_id, note_id)
    assert del_note_res['success'] is True
    print("  -> Study Notes CRUD and pinning verified: PASS")

    # Test Study Sessions & Pomodoro
    pomo_res = record_study_session(s_id, course_id=c_id, duration_minutes=25, study_type='pomodoro', notes='Ôn tập chương 1')
    assert pomo_res['success'] is True
    pomo_stats = get_study_session_stats(s_id)
    assert pomo_stats['sessions_today'] >= 1
    print(f"  -> Pomodoro session recorded: {pomo_stats['sessions_today']} sessions today, {pomo_stats['total_hours']}h total: PASS")

    # Clean up test flashcard
    delete_flashcard(s_id, card_id)

# ----------------------------------------------------
# 4. Teacher Adaptive Overview
# ----------------------------------------------------
print("\n[TEST 4] Teacher Adaptive Learning & Bottleneck Detection:")
with app.app_context():
    # Pick a teacher with courses
    t_course = query_db("SELECT teacher_id, id FROM courses WHERE teacher_id IS NOT NULL LIMIT 1", one=True)
    t_id = t_course['teacher_id']
    t_cid = t_course['id']

    overview = get_teacher_adaptive_overview(t_id, course_id=t_cid)
    assert len(overview['courses']) >= 1
    assert len(overview['topic_stats']) == 4
    assert len(overview['students']) >= 1
    print(f"  -> Teacher overview for course {t_cid}: {len(overview['topic_stats'])} topics tracked across {len(overview['students'])} students: PASS")

# ----------------------------------------------------
# 5. Route & HTTP Endpoints Test (Student & Teacher)
# ----------------------------------------------------
print("\n[TEST 5] HTTP Endpoints Verification:")
with app.app_context():
    # Student login
    student_user = query_db("SELECT email FROM users WHERE role = 'student' LIMIT 1", one=True)
    teacher_user = query_db("SELECT email FROM users WHERE role = 'teacher' LIMIT 1", one=True)

# Test Student routes with session
with client.session_transaction() as sess:
    sess['user_id'] = s_id
    sess['role'] = 'student'
    sess['email'] = student_user['email']

r_path = client.get('/student/learning-path')
assert r_path.status_code == 200, f"Expected 200, got {r_path.status_code}"
assert "Lộ trình học tập thích ứng" in r_path.get_data(as_text=True)
print("  -> GET /student/learning-path: 200 OK")

r_study = client.get('/student/smart-study')
assert r_study.status_code == 200, f"Expected 200, got {r_study.status_code}"
assert "Góc tự học thông minh" in r_study.get_data(as_text=True)
print("  -> GET /student/smart-study: 200 OK")

# Test Teacher routes with session
with client.session_transaction() as sess:
    sess['user_id'] = t_id
    sess['role'] = 'teacher'
    sess['email'] = teacher_user['email']

r_t_adaptive = client.get('/teacher/adaptive-learning')
assert r_t_adaptive.status_code == 200, f"Expected 200, got {r_t_adaptive.status_code}"
assert "Giám sát Lộ trình & Điểm nghẽn SV" in r_t_adaptive.get_data(as_text=True)
print("  -> GET /teacher/adaptive-learning: 200 OK")

# ----------------------------------------------------
# 6. Core LMS Route Regression
# ----------------------------------------------------
print("\n[TEST 6] Core LMS Route Regression (Preserve Legacy Routes):")
anon_client = app.test_client()
assert anon_client.get('/login').status_code == 200
assert anon_client.get('/').status_code == 302
assert anon_client.get('/api/v1/system/health').status_code == 200
assert client.get('/teacher/dashboard').status_code == 200
assert client.get('/teacher/classes').status_code == 200
assert client.get('/teacher/analytics').status_code == 200
assert client.get('/teacher/ai-assistant').status_code == 200
assert client.get('/teacher/adaptive-learning').status_code == 200
print("  -> 8/8 Sample Core Routes intact: PASS")

print("\n==================================================")
print("ALL PHASE 4 VERIFICATION TESTS PASSED SUCCESSFULLY!")
print("==================================================")
