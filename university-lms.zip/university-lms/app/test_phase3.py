import sys
import os
import json

# Set UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from __init__ import create_app
from database import query_db, DB_PATH
from services.ai_gateway import call_ai, get_ai_usage_stats, get_ai_settings
from services.rag_service import index_material_document, query_rag_learning_assistant
from services.ai_teacher_service import save_generated_question_to_exam

app = create_app()
app.config['TESTING'] = True
client = app.test_client()

print("==================================================")
print("RUNNING COMPREHENSIVE PHASE 3 VERIFICATION SUITE")
print("==================================================")

# 1. Database Schema & Data Preservation
print("\n[TEST 1] Database Tables & Old Data Preservation:")
with app.app_context():
    tables_rows = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence'")
    tables = [r['name'] for r in tables_rows]
    print(f"Total Tables in DB: {len(tables)}/29")
    for t in ['ai_conversations', 'ai_messages', 'ai_document_chunks', 'ai_usage_logs']:
        assert t in tables, f"Missing table: {t}"

    u_cnt = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_cnt = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_cnt = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_cnt = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']
    assert u_cnt >= 73, f"Users count changed: {u_cnt}"
    assert c_cnt == 42, f"Courses count changed: {c_cnt}"
    assert e_cnt == 405, f"Enrollments count changed: {e_cnt}"
    assert g_cnt == 248, f"Grades count changed: {g_cnt}"
    print(f"  -> Old data 100% preserved (Users: {u_cnt}, Courses: {c_cnt}, Enrollments: {e_cnt}, Grades: {g_cnt}): PASS")

# 2. AI Gateway & Safe Fallback Behavior
print("\n[TEST 2] AI Gateway & Offline Fallback Security:")
with app.app_context():
    admin_u = query_db("SELECT id FROM users WHERE email = 'admin@example.com'", one=True)
    res = call_ai("Xin chào AI", user_id=admin_u['id'], role='admin', service_name='test')
    print(f"  -> AI Gateway Response Status: {res['status']}")
    print(f"  -> Content Preview: {res['content'][:120]}...")
    assert res['status'] in ('NO_KEY', 'SUCCESS', 'FAILED')

    # Verify usage logged
    log_entry = query_db("SELECT * FROM ai_usage_logs WHERE user_id = ? ORDER BY id DESC LIMIT 1", (admin_u['id'],), one=True)
    assert log_entry is not None, "AI call was not logged in ai_usage_logs"
    print(f"  -> AI Usage logged successfully (Service: {log_entry['service_name']}, Status: {log_entry['status']}): PASS")

# 3. RAG Document Indexing & RBAC Security Isolation
print("\n[TEST 3] RAG Document Indexing & Strict Cross-Course Security:")
with app.app_context():
    mat = query_db("SELECT id, course_id FROM materials LIMIT 1", one=True)
    assert mat is not None, "No materials in database"
    chunks_indexed = index_material_document(mat['id'])
    print(f"  -> Indexed {chunks_indexed} chunks for material #{mat['id']} in course #{mat['course_id']}")

    # Find enrolled student
    enrolled = query_db("SELECT student_id, course_id FROM enrollments WHERE course_id = ? LIMIT 1", (mat['course_id'],), one=True)
    rag_res = query_rag_learning_assistant(
        user_id=enrolled['student_id'],
        role='student',
        course_id=mat['course_id'],
        user_question="Tài liệu có nội dung gì?"
    )
    print(f"  -> Enrolled student RAG query status: {rag_res['status']}")
    assert rag_res['status'] != 'FORBIDDEN', "Enrolled student was wrongly forbidden"

    # Test cross-course access: Student queries a course they are NOT enrolled in
    fake_cid = 99999
    forbidden_res = query_rag_learning_assistant(
        user_id=enrolled['student_id'],
        role='student',
        course_id=fake_cid,
        user_question="Hack access tài liệu"
    )
    print(f"  -> Cross-course unauthorized student query status: {forbidden_res['status']}")
    assert forbidden_res['status'] == 'FORBIDDEN', "Cross-course access was not blocked!"
    print("  -> RAG Security check: Blocked unauthorized course material access: PASS")

# 4. Student AI Assistant Web Endpoints
print("\n[TEST 4] Student AI Assistant Endpoints:")
client.get('/logout')
res = client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
assert res.status_code == 200

# Assistant page
res = client.get('/student/ai-assistant')
assert res.status_code == 200
html = res.data.decode('utf-8')
assert "AI Learning Bot" in html
assert "promptInput" in html
print("  -> GET /student/ai-assistant (200 OK): PASS")

# Send chat message
res = client.post('/student/ai-assistant/chat', json={
    'message': 'Cho em hỏi quy tắc lập trình web',
    'mode': 'general'
})
assert res.status_code == 200
chat_data = res.get_json()
assert 'conversation_id' in chat_data
conv_id = chat_data['conversation_id']
print(f"  -> POST /student/ai-assistant/chat (200 OK, Conv ID: {conv_id}): PASS")

# Delete conversation
res = client.post(f'/student/ai-assistant/conversation/{conv_id}/delete', follow_redirects=True)
assert res.status_code == 200
print("  -> POST /student/ai-assistant/conversation/delete (200 OK): PASS")

# 5. Teacher AI Assistant Endpoints & Question Bank Saving
print("\n[TEST 5] Teacher AI Assistant & Question Bank Integration:")
client.get('/logout')
res = client.post('/login', data={'email': 'teacher@example.com', 'password': 'teacher123'}, follow_redirects=True)
assert res.status_code == 200

res = client.get('/teacher/ai-assistant')
assert res.status_code == 200
t_html = res.data.decode('utf-8')
assert "Trợ Lý Sư Phạm & Soạn Đề Thi Thông Minh" in t_html
print("  -> GET /teacher/ai-assistant (200 OK): PASS")

# Save AI question directly into exam question bank
with app.app_context():
    teacher_u = query_db("SELECT id FROM users WHERE email = 'teacher@example.com'", one=True)
    exam = query_db("SELECT id FROM exams WHERE created_by = ? LIMIT 1", (teacher_u['id'],), one=True)
    if not exam:
        exam = query_db("SELECT id FROM exams LIMIT 1", one=True)

    res = client.post('/teacher/ai-assistant/save-question', json={
        'exam_id': exam['id'],
        'question': 'Khóa chính (Primary Key) trong cơ sở dữ liệu có tính chất gì?',
        'options': ['Duy nhất và không được NULL', 'Có thể trùng lặp', 'Có thể NULL', 'Tùy ý'],
        'correct_index': 0,
        'points': 1.0
    })
    assert res.status_code == 200
    save_data = res.get_json()
    assert save_data['success'] is True
    print(f"  -> Saved question #{save_data['question_id']} directly into Exam #{exam['id']}: PASS")

# 6. Admin AI Usage & Governance
print("\n[TEST 6] Admin AI Usage & Settings Dashboard:")
client.get('/logout')
res = client.post('/login', data={'email': 'admin@example.com', 'password': 'admin123'}, follow_redirects=True)
assert res.status_code == 200

# View AI Usage
res = client.get('/admin/ai-usage')
assert res.status_code == 200
a_html = res.data.decode('utf-8')
assert "Giám Sát & Quản Trị Dịch Vụ AI" in a_html
assert "AI GATEWAY" in a_html
print("  -> GET /admin/ai-usage (200 OK & Governance panel present): PASS")

# Update AI settings via admin form
res = client.post('/admin/ai-usage/config', data={
    'ai_api_enabled': '0',
    'ai_api_key': '',
    'ai_model': 'gemini-1.5-flash',
    'ai_daily_token_limit': '60000',
    'ai_temperature': '0.7'
}, follow_redirects=True)
assert res.status_code == 200
print("  -> POST /admin/ai-usage/config (Settings updated & audit logged): PASS")

# Security check: Student blocked from /admin/ai-usage
client.get('/logout')
client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
res = client.get('/admin/ai-usage', follow_redirects=True)
assert "Bạn không có quyền truy cập" in res.data.decode('utf-8') or "/student/dashboard" in res.request.path
print("  -> Security Test: Student BLOCKED from /admin/ai-usage: PASS")

# 7. Regression Test on All Existing Web Routes
print("\n[TEST 7] Regression Test on Core Application Routes:")
client.get('/logout')
for route in ['/login', '/maintenance', '/system-locked', '/forgot-password']:
    res = client.get(route)
    assert res.status_code == 200

client.post('/login', data={'email': 'admin@example.com', 'password': 'admin123'}, follow_redirects=True)
for route in ['/admin/dashboard', '/admin/users', '/admin/education', '/admin/reports', '/admin/notifications', '/admin/analytics', '/admin/ai-usage']:
    res = client.get(route)
    assert res.status_code == 200

client.get('/logout')
client.post('/login', data={'email': 'teacher@example.com', 'password': 'teacher123'}, follow_redirects=True)
for route in ['/teacher/dashboard', '/teacher/classes', '/teacher/materials', '/teacher/assignments', '/teacher/exams', '/teacher/grades', '/teacher/analytics', '/teacher/ai-assistant']:
    res = client.get(route)
    assert res.status_code == 200

client.get('/logout')
client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
for route in ['/student/dashboard', '/student/classes', '/student/materials', '/student/assignments', '/student/exams', '/student/academic-results', '/student/ai-assistant']:
    res = client.get(route)
    assert res.status_code == 200

print("  -> All core LMS + Analytics + AI routes verified 100% (200 OK): PASS")

client.get('/logout')
print("\n==================================================")
print("ALL PHASE 3 TESTS PASSED 100% WITH ZERO ERRORS!")
print("==================================================")
