import os
import json
import time
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, jsonify
from database import query_db, execute_db
from auth import login_required, role_required, get_current_user
from services.audit_service import log_audit
from services.analytics_service import get_teacher_learning_analytics
from services.predictive_service import update_intervention_status
from services.ai_teacher_service import generate_quiz_questions, generate_lecture_outline, save_generated_question_to_exam
from services.adaptive_service import get_teacher_adaptive_overview
from services.smart_assessment_service import (
    get_question_bank, create_bank_question, delete_bank_question,
    seed_default_question_bank_if_empty, get_question_bank_stats,
    generate_ai_questions, create_assessment_matrix, get_assessment_matrices,
    get_assessment_matrix_detail, generate_exam_from_matrix,
    create_rubric, get_rubric_for_assignment, grade_with_rubric
)
from services.online_coding_service import (
    get_coding_problems, get_coding_problem_detail, create_coding_problem,
    seed_default_coding_problems
)

teacher_bp = Blueprint('teacher_bp', __name__, url_prefix='/teacher')

DEBUG_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'debug-45cb16.log')


def _teacher_dbg(hypothesis_id, location, message, data):
    # #region agent log
    try:
        with open(DEBUG_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(json.dumps({
                'sessionId': '45cb16',
                'runId': 'post-fix',
                'hypothesisId': hypothesis_id,
                'location': location,
                'message': message,
                'data': data,
                'timestamp': int(time.time() * 1000),
            }) + '\n')
    except Exception:
        pass
    # #endregion


def letter_from_total(total):
    return "A+" if total >= 9.0 else ("A" if total >= 8.5 else ("B+" if total >= 8.0 else ("B" if total >= 7.0 else ("C+" if total >= 6.5 else ("C" if total >= 5.5 else ("D" if total >= 4.0 else "F"))))))


def a1_from_parts(assignment_score, quiz_score):
    assignment = float(assignment_score or 0)
    quiz = float(quiz_score or 0)
    if quiz == 0 or assignment == quiz:
        return round(assignment, 2)
    return round((assignment + quiz) / 2.0, 2)

@teacher_bp.route('/dashboard')
@login_required
@role_required('teacher')
def dashboard():
    user = get_current_user()

    # 1. Total teaching classes
    classes_count = query_db("SELECT COUNT(*) as count FROM courses WHERE teacher_id = ?", (user['id'],), one=True)['count']

    # 2. Total students across classes
    total_students = query_db("""
        SELECT COUNT(DISTINCT e.student_id) as count
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        WHERE c.teacher_id = ?
    """, (user['id'],), one=True)['count']

    # 3. Total assignments created
    assignments_count = query_db("SELECT COUNT(*) as count FROM assignments WHERE created_by = ?", (user['id'],), one=True)['count']

    # 4. Ungraded submissions count
    ungraded_count = query_db("""
        SELECT COUNT(s.id) as count
        FROM submissions s
        JOIN assignments a ON s.assignment_id = a.id
        WHERE a.created_by = ? AND s.score IS NULL
    """, (user['id'],), one=True)['count']

    # 5. Recent teaching classes
    recent_classes = query_db("""
        SELECT c.*, sub.name as subject_name,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as student_count
        FROM courses c
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE c.teacher_id = ?
        ORDER BY c.id DESC LIMIT 4
    """, (user['id'],))

    # 6. Ungraded submission list preview
    pending_submissions = query_db("""
        SELECT s.*, u.full_name as student_name, a.title as assignment_title, c.name as course_name
        FROM submissions s
        JOIN users u ON s.student_id = u.id
        JOIN assignments a ON s.assignment_id = a.id
        JOIN courses c ON a.course_id = c.id
        WHERE a.created_by = ? AND s.score IS NULL
        ORDER BY s.submitted_at DESC LIMIT 5
    """, (user['id'],))

    return render_template(
        'teacher/dashboard.html',
        classes_count=classes_count,
        total_students=total_students,
        assignments_count=assignments_count,
        ungraded_count=ungraded_count,
        recent_classes=recent_classes,
        pending_submissions=pending_submissions
    )

@teacher_bp.route('/classes')
@login_required
@role_required('teacher')
def classes():
    user = get_current_user()

    courses = query_db("""
        SELECT c.*, sub.name as subject_name, sub.code as subject_code, sub.credits,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as student_count
        FROM courses c
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE c.teacher_id = ?
        ORDER BY c.id DESC
    """, (user['id'],))

    subjects = query_db("SELECT * FROM subjects ORDER BY name ASC")

    return render_template('teacher/classes.html', courses=courses, subjects=subjects)

@teacher_bp.route('/class/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_class():
    user = get_current_user()
    subject_id = request.form.get('subject_id')
    code = request.form.get('code', '').strip()
    name = request.form.get('name', '').strip()
    semester = request.form.get('semester', 'HK1 (2024-2025)').strip()
    room = request.form.get('room', 'Phòng A.101').strip()
    schedule_info = request.form.get('schedule_info', 'Thứ 2 (08:00 - 11:30)').strip()
    description = request.form.get('description', '').strip()

    if not subject_id or not code or not name:
        flash("Vui lòng điền các trường bắt buộc.", "danger")
        return redirect(url_for('teacher_bp.classes'))

    try:
        course_id = execute_db("""
            INSERT INTO courses (subject_id, teacher_id, code, name, semester, room, schedule_info, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (subject_id, user['id'], code, name, semester, room, schedule_info, description))
        flash(f"Tạo lớp học phần {name} ({code}) thành công!", "success")
    except Exception as e:
        flash(f"Lỗi tạo lớp học: Mã lớp {code} đã tồn tại hoặc dữ liệu không hợp lệ.", "danger")

    return redirect(url_for('teacher_bp.classes'))

@teacher_bp.route('/materials')
@login_required
@role_required('teacher')
def materials():
    user = get_current_user()

    materials_list = query_db("""
        SELECT m.*, c.name as course_name
        FROM materials m
        JOIN courses c ON m.course_id = c.id
        WHERE c.teacher_id = ?
        ORDER BY m.created_at DESC
    """, (user['id'],))

    my_courses = query_db("SELECT id, name, code FROM courses WHERE teacher_id = ?", (user['id'],))

    return render_template('teacher/materials.html', materials=materials_list, courses=my_courses)

@teacher_bp.route('/material/upload', methods=['POST'])
@login_required
@role_required('teacher')
def upload_material():
    user = get_current_user()
    course_id = request.form.get('course_id')
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    file_type = request.form.get('file_type', 'PDF')
    file = request.files.get('material_file')

    if not course_id or not title:
        flash("Vui lòng nhập tên tài liệu và chọn lớp học.", "danger")
        return redirect(url_for('teacher_bp.materials'))

    file_path = "/static/uploads/sample_material.pdf"
    file_size = "2.4 MB"

    if file and file.filename != '':
        upload_folder = os.path.join(current_app.root_path, 'static', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        filename = f"mat_{user['id']}_{file.filename}"
        save_path = os.path.join(upload_folder, filename)
        file.save(save_path)
        file_path = f"/static/uploads/{filename}"
        size_bytes = os.path.getsize(save_path)
        file_size = f"{round(size_bytes / (1024*1024), 1)} MB" if size_bytes >= 1024*1024 else f"{round(size_bytes / 1024, 1)} KB"

    execute_db("""
        INSERT INTO materials (course_id, title, description, file_path, file_type, file_size, uploaded_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (course_id, title, description, file_path, file_type, file_size, user['id']))

    log_audit(
        user_id=user['id'],
        user_email=user['email'],
        user_role='teacher',
        action='UPLOAD_MATERIAL',
        target_type='material',
        target_id=course_id,
        details={'title': title, 'file_type': file_type, 'file_size': file_size}
    )

    flash(f"Đã tải lên tài liệu '{title}' thành công!", "success")
    return redirect(url_for('teacher_bp.materials'))

@teacher_bp.route('/assignments')
@login_required
@role_required('teacher')
def assignments():
    user = get_current_user()

    assignments_list = query_db("""
        SELECT a.*, c.name as course_name,
               (SELECT COUNT(*) FROM submissions WHERE assignment_id = a.id) as submitted_count,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = a.course_id) as total_students
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.created_by = ?
        ORDER BY a.created_at DESC
    """, (user['id'],))

    my_courses = query_db("SELECT id, name FROM courses WHERE teacher_id = ?", (user['id'],))

    return render_template('teacher/assignments.html', assignments=assignments_list, courses=my_courses)

@teacher_bp.route('/assignment/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_assignment():
    user = get_current_user()
    course_id = request.form.get('course_id')
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    due_date = request.form.get('due_date', '').strip()
    max_points = float(request.form.get('max_points', 10.0))

    if not course_id or not title or not due_date:
        flash("Vui lòng điền các thông tin bài tập bắt buộc.", "danger")
        return redirect(url_for('teacher_bp.assignments'))

    file_path = ""
    file = request.files.get('assignment_file')
    if file and file.filename != '':
        upload_folder = os.path.join(current_app.root_path, 'static', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        filename = f"assign_{user['id']}_{file.filename}"
        file.save(os.path.join(upload_folder, filename))
        file_path = f"/static/uploads/{filename}"

    # Standardize HTML datetime format T to space
    due_date_str = due_date.replace('T', ' ') + ':00' if 'T' in due_date else due_date

    execute_db("""
        INSERT INTO assignments (course_id, title, description, file_path, due_date, max_points, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (course_id, title, description, file_path, due_date_str, max_points, user['id']))

    flash(f"Tạo bài tập '{title}' thành công!", "success")
    return redirect(url_for('teacher_bp.assignments'))

@teacher_bp.route('/assignment/<int:assignment_id>/submissions')
@login_required
@role_required('teacher')
def assignment_submissions(assignment_id):
    assignment = query_db("""
        SELECT a.*, c.name as course_name FROM assignments a JOIN courses c ON a.course_id = c.id WHERE a.id = ?
    """, (assignment_id,), one=True)

    submissions_list = query_db("""
        SELECT s.*, u.full_name as student_name, st.student_code
        FROM submissions s
        JOIN users u ON s.student_id = u.id
        LEFT JOIN students st ON u.id = st.user_id
        WHERE s.assignment_id = ?
        ORDER BY s.submitted_at DESC
    """, (assignment_id,))

    return render_template('teacher/submissions.html', assignment=assignment, submissions=submissions_list)

@teacher_bp.route('/submission/<int:submission_id>/grade', methods=['POST'])
@login_required
@role_required('teacher')
def grade_submission(submission_id):
    score = float(request.form.get('score', 0.0))
    feedback = request.form.get('feedback', '').strip()
    assignment_id = request.form.get('assignment_id')

    execute_db("""
        UPDATE submissions
        SET score = ?, feedback = ?, graded_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (score, feedback, submission_id))

    user = get_current_user()
    log_audit(
        user_id=user['id'],
        user_email=user['email'],
        user_role='teacher',
        action='GRADE_SUBMISSION',
        target_type='submission',
        target_id=submission_id,
        details={'score': score, 'feedback': feedback[:100]}
    )

    flash("Đã lưu điểm và nhận xét thành công!", "success")
    return redirect(url_for('teacher_bp.assignment_submissions', assignment_id=assignment_id))

@teacher_bp.route('/exams')
@login_required
@role_required('teacher')
def exams():
    user = get_current_user()

    exams_list = query_db("""
        SELECT ex.*, c.name as course_name,
               (SELECT COUNT(*) FROM questions WHERE exam_id = ex.id) as question_count,
               (SELECT COUNT(*) FROM exam_results WHERE exam_id = ex.id) as result_count
        FROM exams ex
        JOIN courses c ON ex.course_id = c.id
        WHERE ex.created_by = ?
        ORDER BY ex.created_at DESC
    """, (user['id'],))

    my_courses = query_db("SELECT id, name FROM courses WHERE teacher_id = ?", (user['id'],))

    return render_template('teacher/exams.html', exams=exams_list, courses=my_courses)

@teacher_bp.route('/exam/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_exam():
    user = get_current_user()
    course_id = request.form.get('course_id')
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    duration_minutes = int(request.form.get('duration_minutes', 45))

    if not course_id or not title:
        flash("Vui lòng điền tiêu đề bài kiểm tra và chọn lớp học.", "danger")
        return redirect(url_for('teacher_bp.exams'))

    exam_id = execute_db("""
        INSERT INTO exams (course_id, title, description, duration_minutes, created_by)
        VALUES (?, ?, ?, ?, ?)
    """, (course_id, title, description, duration_minutes, user['id']))

    log_audit(
        user_id=user['id'],
        user_email=user['email'],
        user_role='teacher',
        action='CREATE_EXAM',
        target_type='exam',
        target_id=exam_id,
        details={'title': title, 'duration_minutes': duration_minutes, 'course_id': course_id}
    )

    flash(f"Tạo bài kiểm tra '{title}' thành công. Hãy thêm các câu hỏi trắc nghiệm!", "success")
    return redirect(url_for('teacher_bp.exam_questions', exam_id=exam_id))

@teacher_bp.route('/exam/<int:exam_id>/questions')
@login_required
@role_required('teacher')
def exam_questions(exam_id):
    exam = query_db("SELECT ex.*, c.name as course_name FROM exams ex JOIN courses c ON ex.course_id = c.id WHERE ex.id = ?", (exam_id,), one=True)
    questions = query_db("SELECT * FROM questions WHERE exam_id = ?", (exam_id,))

    formatted_questions = []
    for q in questions:
        q_dict = dict(q)
        q_dict['options'] = json.loads(q['options_json'])
        q_dict['correct_indices'] = json.loads(q['correct_answers_json'])
        formatted_questions.append(q_dict)

    return render_template('teacher/exam_questions.html', exam=exam, questions=formatted_questions)

@teacher_bp.route('/exam/<int:exam_id>/question/add', methods=['POST'])
@login_required
@role_required('teacher')
def add_question(exam_id):
    question_text = request.form.get('question_text', '').strip()
    q_type = request.form.get('question_type', 'single')
    points = float(request.form.get('points', 2.0))

    opt_a = request.form.get('opt_a', '').strip()
    opt_b = request.form.get('opt_b', '').strip()
    opt_c = request.form.get('opt_c', '').strip()
    opt_d = request.form.get('opt_d', '').strip()

    options = [opt_a, opt_b, opt_c, opt_d]
    correct_idx = int(request.form.get('correct_option', 0))

    execute_db("""
        INSERT INTO questions (exam_id, question_text, question_type, options_json, correct_answers_json, points)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (exam_id, question_text, q_type, json.dumps(options), json.dumps([correct_idx]), points))

    flash("Đã thêm câu hỏi mới thành công!", "success")
    return redirect(url_for('teacher_bp.exam_questions', exam_id=exam_id))

@teacher_bp.route('/grades')
@login_required
@role_required('teacher')
def grades():
    user = get_current_user()
    course_id = request.args.get('course_id', '')

    my_courses = query_db("SELECT id, name, code FROM courses WHERE teacher_id = ?", (user['id'],))

    students_grades = []
    selected_course_info = None

    if course_id:
        selected_course_info = query_db("SELECT * FROM courses WHERE id = ?", (course_id,), one=True)
        students_grades = query_db("""
            SELECT u.id as student_id, u.full_name, st.student_code,
                   g.assignment_score, g.quiz_score, g.midterm_score, g.final_score, g.total_score, g.letter_grade
            FROM enrollments e
            JOIN users u ON e.student_id = u.id
            LEFT JOIN students st ON u.id = st.user_id
            LEFT JOIN grades g ON g.course_id = e.course_id AND g.student_id = e.student_id
            WHERE e.course_id = ?
            ORDER BY u.full_name ASC
        """, (course_id,))
        formatted = []
        for sg in students_grades:
            item = dict(sg)
            item['a1'] = a1_from_parts(item.get('assignment_score'), item.get('quiz_score'))
            item['a2'] = round(float(item['midterm_score'] or 0), 2)
            item['a3'] = round(float(item['final_score'] or 0), 2)
            item['total_score'] = round(item['a1'] * 0.2 + item['a2'] * 0.3 + item['a3'] * 0.5, 2)
            formatted.append(item)
        students_grades = formatted
        # #region agent log
        _teacher_dbg('H6', 'teacher_routes.py:grades', 'teacher gradebook A1 A2 A3', {
            'course_id': course_id,
            'rows': [{'a1': r['a1'], 'a2': r['a2'], 'a3': r['a3']} for r in students_grades[:5]],
        })
        # #endregion

    return render_template('teacher/grades.html', courses=my_courses, students_grades=students_grades, selected_course=course_id, selected_course_info=selected_course_info)

@teacher_bp.route('/grades/update', methods=['POST'])
@login_required
@role_required('teacher')
def update_grade():
    course_id = request.form.get('course_id')
    student_id = request.form.get('student_id')

    a1 = float(request.form.get('a1_score', request.form.get('assignment_score', 0.0)))
    a2 = float(request.form.get('a2_score', request.form.get('midterm_score', 0.0)))
    a3 = float(request.form.get('a3_score', request.form.get('final_score', 0.0)))

    assignment_score = a1
    quiz_score = a1
    midterm_score = a2
    final_score = a3
    total = round(a1 * 0.2 + a2 * 0.3 + a3 * 0.5, 2)
    letter = letter_from_total(total)
    # #region agent log
    _teacher_dbg('H6', 'teacher_routes.py:update_grade', 'saved A1 A2 A3', {
        'a1': a1, 'a2': a2, 'a3': a3, 'total': total, 'letter': letter, 'weights': [0.2, 0.3, 0.5],
    })
    # #endregion

    existing = query_db("SELECT id FROM grades WHERE course_id = ? AND student_id = ?", (course_id, student_id), one=True)
    if existing:
        execute_db("""
            UPDATE grades
            SET assignment_score = ?, quiz_score = ?, midterm_score = ?, final_score = ?, total_score = ?, letter_grade = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (assignment_score, quiz_score, midterm_score, final_score, total, letter, existing['id']))
    else:
        execute_db("""
            INSERT INTO grades (course_id, student_id, assignment_score, quiz_score, midterm_score, final_score, total_score, letter_grade)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (course_id, student_id, assignment_score, quiz_score, midterm_score, final_score, total, letter))

    teacher = get_current_user()
    log_audit(
        user_id=teacher['id'] if teacher else None,
        user_email=teacher['email'] if teacher else '',
        user_role='teacher',
        action='UPDATE_GRADE',
        target_type='grade',
        target_id=f"course_{course_id}_student_{student_id}",
        details={'course_id': course_id, 'student_id': student_id, 'a1': a1, 'a2': a2, 'a3': a3, 'total': total, 'letter': letter}
    )

    flash("Cập nhật điểm thành công!", "success")
    return redirect(url_for('teacher_bp.grades', course_id=course_id))

@teacher_bp.route('/notifications', methods=['GET', 'POST'])
@login_required
@role_required('teacher')
def class_notifications():
    user = get_current_user()

    if request.method == 'POST':
        course_id = request.form.get('course_id')
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()

        if not course_id or not title or not content:
            flash("Vui lòng chọn lớp học phần và điền đầy đủ tiêu đề, nội dung.", "danger")
            return redirect(url_for('teacher_bp.class_notifications'))

        # Verify teacher owns this course
        course = query_db("SELECT * FROM courses WHERE id = ? AND teacher_id = ?", (course_id, user['id']), one=True)
        if not course:
            flash("Bạn không có quyền gửi thông báo cho lớp học phần này.", "danger")
            return redirect(url_for('teacher_bp.class_notifications'))

        # Insert into announcements
        execute_db(
            "INSERT INTO announcements (sender_id, title, content, target_type, course_id) VALUES (?, ?, ?, 'course', ?)",
            (user['id'], title, content, course['id'])
        )

        # Deliver notification to each enrolled student
        enrolled_students = query_db("SELECT student_id FROM enrollments WHERE course_id = ?", (course['id'],))
        for s in enrolled_students:
            execute_db(
                "INSERT INTO notifications (user_id, title, message, category, link) VALUES (?, ?, ?, 'teacher', ?)",
                (s['student_id'], f"[{course['name']}] {title}", content, f"/student/class/{course['id']}")
            )

        flash(f"Đã gửi thông báo đến {len(enrolled_students)} sinh viên của lớp học phần {course['name']} thành công!", "success")
        return redirect(url_for('teacher_bp.class_notifications'))

    # GET
    courses = query_db("""
        SELECT c.*, sub.name as subject_name,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as student_count
        FROM courses c
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE c.teacher_id = ?
        ORDER BY c.id DESC
    """, (user['id'],))

    announcements = query_db("""
        SELECT a.*, c.name as course_name, c.code as course_code
        FROM announcements a
        JOIN courses c ON a.course_id = c.id
        WHERE a.sender_id = ? AND a.target_type = 'course'
        ORDER BY a.created_at DESC
    """, (user['id'],))

    return render_template(
        'teacher/class_notifications.html',
        courses=courses,
        announcements=announcements
    )

@teacher_bp.route('/notification/<int:announcement_id>/delete', methods=['POST'])
@login_required
@role_required('teacher')
def delete_class_notification(announcement_id):
    user = get_current_user()
    execute_db("DELETE FROM announcements WHERE id = ? AND sender_id = ?", (announcement_id, user['id']))
    flash("Đã xóa bản ghi thông báo lớp học phần.", "info")
    return redirect(url_for('teacher_bp.class_notifications'))

@teacher_bp.route('/analytics')
@login_required
@role_required('teacher')
def learning_analytics():
    user = get_current_user()
    course_id = request.args.get('course_id')
    analytics_data = get_teacher_learning_analytics(user['id'], course_id=course_id)
    return render_template('teacher/analytics.html', analytics=analytics_data)

@teacher_bp.route('/analytics/interventions/<int:intervention_id>/update', methods=['POST'])
@login_required
@role_required('teacher')
def update_student_intervention(intervention_id):
    user = get_current_user()
    status = request.form.get('status', 'in_progress')
    notes = request.form.get('notes', '').strip()
    course_id = request.form.get('course_id')

    update_intervention_status(intervention_id, status, notes=notes, teacher_id=user['id'])
    flash("Đã cập nhật trạng thái can thiệp học vụ thành công!", "success")
    return redirect(url_for('teacher_bp.learning_analytics', course_id=course_id))

@teacher_bp.route('/ai-assistant')
@login_required
@role_required('teacher')
def ai_assistant():
    user = get_current_user()
    my_courses = query_db("""
        SELECT c.id, c.name, c.code, c.semester
        FROM courses c
        WHERE c.teacher_id = ?
        ORDER BY c.id DESC
    """, (user['id'],))

    my_exams = query_db("""
        SELECT ex.id, ex.title, c.name as course_name
        FROM exams ex
        JOIN courses c ON ex.course_id = c.id
        WHERE ex.created_by = ?
        ORDER BY ex.id DESC
    """, (user['id'],))

    return render_template(
        'teacher/ai_assistant.html',
        courses=my_courses,
        exams=my_exams
    )

@teacher_bp.route('/ai-assistant/generate-quiz', methods=['POST'])
@login_required
@role_required('teacher')
def ai_generate_quiz():
    data = request.get_json(silent=True) or request.form.to_dict()
    topic = (data.get('topic') or '').strip()
    course_name = (data.get('course_name') or '').strip()
    difficulty = data.get('difficulty', 'Trung bình')
    num_q = min(10, max(1, int(data.get('num_questions', 3))))

    if not topic:
        return jsonify({"success": False, "message": "Vui lòng nhập chủ đề cần tạo câu hỏi."}), 400

    result = generate_quiz_questions(
        topic=topic,
        num_questions=num_q,
        difficulty=difficulty,
        course_name=course_name
    )
    return jsonify(result)

@teacher_bp.route('/ai-assistant/save-question', methods=['POST'])
@login_required
@role_required('teacher')
def ai_save_question():
    data = request.get_json(silent=True) or request.form.to_dict()
    exam_id = int(data.get('exam_id', 0))
    question_text = (data.get('question') or '').strip()
    options = data.get('options')
    correct_idx = int(data.get('correct_index', 0))
    points = float(data.get('points', 1.0))

    if isinstance(options, str):
        try:
            options = json.loads(options)
        except Exception:
            options = [options]

    if not exam_id or not question_text or not options:
        return jsonify({"success": False, "message": "Thiếu thông tin câu hỏi hoặc đề thi."}), 400

    new_id = save_generated_question_to_exam(
        exam_id=exam_id,
        question_text=question_text,
        options=options,
        correct_index=correct_idx,
        points=points
    )
    return jsonify({"success": True, "message": "Đã lưu câu hỏi vào đề thi thành công!", "question_id": new_id})

@teacher_bp.route('/ai-assistant/generate-outline', methods=['POST'])
@login_required
@role_required('teacher')
def ai_generate_outline():
    data = request.get_json(silent=True) or request.form.to_dict()
    topic = (data.get('topic') or '').strip()
    course_name = (data.get('course_name') or '').strip()

    if not topic:
        return jsonify({"success": False, "message": "Vui lòng nhập chủ đề bài học."}), 400

    res = generate_lecture_outline(topic=topic, course_name=course_name)
    return jsonify(res)


# ==========================================
# PHASE 4: ADAPTIVE LEARNING & TOPIC MASTERY
# ==========================================

@teacher_bp.route('/adaptive-learning')
@login_required
@role_required('teacher')
def adaptive_learning():
    user = get_current_user()
    course_id = request.args.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else None
    data = get_teacher_adaptive_overview(user['id'], course_id=cid)
    return render_template('teacher/adaptive_learning.html', user=user, data=data)


# ==========================================
# PHASE 5: SMART ASSESSMENT & CODING
# ==========================================

@teacher_bp.route('/question-bank')
@login_required
@role_required('teacher')
def question_bank():
    user = get_current_user()
    course_id = request.args.get('course_id')
    chapter = request.args.get('chapter')
    difficulty = request.args.get('difficulty')
    tag = request.args.get('tag')
    search = request.args.get('search')

    courses = query_db("SELECT id, code, name FROM courses WHERE teacher_id = ? ORDER BY code ASC", (user['id'],))
    cid = int(course_id) if course_id and course_id.isdigit() else (courses[0]['id'] if courses else None)

    if cid:
        seed_default_question_bank_if_empty(cid, user['id'])

    chap_num = int(chapter) if chapter and chapter.isdigit() else None
    questions = get_question_bank(course_id=cid, chapter_num=chap_num, difficulty=difficulty, tag=tag, search=search)
    stats = get_question_bank_stats(course_id=cid)

    return render_template(
        'teacher/question_bank.html',
        user=user,
        courses=courses,
        selected_course_id=cid,
        questions=questions,
        stats=stats,
        current_chapter=chap_num,
        current_difficulty=difficulty,
        current_search=search
    )

@teacher_bp.route('/question-bank/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_question_endpoint():
    user = get_current_user()
    course_id = int(request.form.get('course_id', 0))
    chapter_num = int(request.form.get('chapter_num', 1))
    question_text = request.form.get('question_text', '').strip()
    opt_a = request.form.get('option_a', '').strip()
    opt_b = request.form.get('option_b', '').strip()
    opt_c = request.form.get('option_c', '').strip()
    opt_d = request.form.get('option_d', '').strip()
    correct_idx = int(request.form.get('correct_index', 0))
    difficulty = request.form.get('difficulty', 'MEDIUM')
    points = float(request.form.get('points', 1.0))
    tags_str = request.form.get('tags', '')
    explanation = request.form.get('explanation', '').strip()

    options = [opt for opt in [opt_a, opt_b, opt_c, opt_d] if opt]
    tags = [t.strip() for t in tags_str.split(',') if t.strip()]

    res = create_bank_question(
        course_id=course_id,
        question_text=question_text,
        options=options,
        correct_answers=[correct_idx],
        chapter_num=chapter_num,
        difficulty=difficulty,
        points=points,
        tags=tags,
        explanation=explanation,
        created_by=user['id']
    )

    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('teacher_bp.question_bank', course_id=course_id))

@teacher_bp.route('/question-bank/<int:qid>/delete', methods=['POST'])
@login_required
@role_required('teacher')
def delete_question_endpoint(qid):
    user = get_current_user()
    res = delete_bank_question(qid, user_id=user['id'])
    if res.get('success'):
        flash(res.get('message'), 'info')
    else:
        flash(res.get('message'), 'danger')
    return redirect(request.referrer or url_for('teacher_bp.question_bank'))

@teacher_bp.route('/question-bank/ai-generate', methods=['POST'])
@login_required
@role_required('teacher')
def ai_generate_questions_endpoint():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    course_id = int(data.get('course_id', 0))
    chapter_num = int(data.get('chapter_num', 1))
    count = int(data.get('count', 5))
    difficulty = data.get('difficulty', 'MEDIUM')
    prompt_hint = data.get('prompt_hint', '')

    res = generate_ai_questions(
        course_id=course_id,
        chapter_num=chapter_num,
        count=count,
        difficulty=difficulty,
        prompt_hint=prompt_hint,
        teacher_id=user['id']
    )
    return jsonify(res)

@teacher_bp.route('/question-bank/approve', methods=['POST'])
@login_required
@role_required('teacher')
def approve_question_endpoint():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    course_id = int(data.get('course_id', 0))
    chapter_num = int(data.get('chapter_num', 1))
    question_text = data.get('question', '').strip()
    options = data.get('options', [])
    correct_idx = int(data.get('correct_index', 0))
    difficulty = data.get('difficulty', 'MEDIUM')
    explanation = data.get('explanation', '')
    tags = data.get('tags', [])

    if isinstance(options, str):
        try:
            options = json.loads(options)
        except Exception:
            options = [options]

    if isinstance(tags, str):
        try:
            tags = json.loads(tags)
        except Exception:
            tags = [tags]

    res = create_bank_question(
        course_id=course_id,
        question_text=question_text,
        options=options,
        correct_answers=[correct_idx],
        chapter_num=chapter_num,
        difficulty=difficulty,
        points=1.0,
        tags=tags,
        explanation=explanation,
        created_by=user['id']
    )
    return jsonify(res)

@teacher_bp.route('/assessment-matrices')
@login_required
@role_required('teacher')
def assessment_matrices():
    user = get_current_user()
    courses = query_db("SELECT id, code, name FROM courses WHERE teacher_id = ? ORDER BY code ASC", (user['id'],))
    course_id = request.args.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else (courses[0]['id'] if courses else None)
    matrices = get_assessment_matrices(course_id=cid)
    return render_template('teacher/assessment_matrices.html', user=user, courses=courses, selected_course_id=cid, matrices=matrices)

@teacher_bp.route('/assessment-matrices/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_assessment_matrix_endpoint():
    user = get_current_user()
    course_id = int(request.form.get('course_id', 0))
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()

    items = [
        {
            'chapter_num': 1,
            'topic_title': 'Chương 1: Tổng quan & Cơ sở lý thuyết',
            'easy_count': int(request.form.get('ch1_easy', 2)),
            'medium_count': int(request.form.get('ch1_medium', 1)),
            'hard_count': int(request.form.get('ch1_hard', 0)),
            'points_per_question': 1.0,
            'skill_evaluated': 'Ghi nhớ & Nhận biết'
        },
        {
            'chapter_num': 2,
            'topic_title': 'Chương 2: Kiến trúc & Phương pháp cốt lõi',
            'easy_count': int(request.form.get('ch2_easy', 1)),
            'medium_count': int(request.form.get('ch2_medium', 2)),
            'hard_count': int(request.form.get('ch2_hard', 1)),
            'points_per_question': 1.0,
            'skill_evaluated': 'Hiểu & Áp dụng'
        },
        {
            'chapter_num': 3,
            'topic_title': 'Chương 3: Kỹ thuật nâng cao & Ứng dụng',
            'easy_count': int(request.form.get('ch3_easy', 0)),
            'medium_count': int(request.form.get('ch3_medium', 1)),
            'hard_count': int(request.form.get('ch3_hard', 2)),
            'points_per_question': 1.0,
            'skill_evaluated': 'Phân tích & Đánh giá'
        }
    ]

    res = create_assessment_matrix(course_id, title, description, items, user['id'])
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('teacher_bp.assessment_matrices', course_id=course_id))

@teacher_bp.route('/assessment-matrices/<int:mid>/generate-exam', methods=['POST'])
@login_required
@role_required('teacher')
def generate_exam_from_matrix_endpoint(mid):
    user = get_current_user()
    exam_title = request.form.get('exam_title', '').strip()
    duration = int(request.form.get('duration_minutes', 45))

    res = generate_exam_from_matrix(mid, exam_title, duration_minutes=duration, created_by=user['id'])
    if res.get('success'):
        flash(res.get('message'), 'success')
        return redirect(url_for('teacher_bp.exams'))
    else:
        flash(res.get('message'), 'danger')
        return redirect(url_for('teacher_bp.assessment_matrices'))

@teacher_bp.route('/courses/<int:course_id>/coding-assessments')
@login_required
@role_required('teacher')
def coding_assessments(course_id):
    user = get_current_user()
    course = query_db("SELECT id, code, name FROM courses WHERE id = ?", (course_id,), one=True)
    if not course:
        flash('Lớp học phần không tồn tại.', 'danger')
        return redirect(url_for('teacher_bp.classes'))

    seed_default_coding_problems(course_id, user['id'])
    problems = get_coding_problems(course_id=course_id)
    return render_template('teacher/coding_assessments.html', user=user, course=course, problems=problems)

@teacher_bp.route('/courses/<int:course_id>/coding-assessments/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_coding_problem_endpoint(course_id):
    user = get_current_user()
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    difficulty = request.form.get('difficulty', 'EASY')
    language = request.form.get('language', 'python')
    starter_code = request.form.get('starter_code', '')
    time_limit = float(request.form.get('time_limit_seconds', 2.0))

    inp1 = request.form.get('input_1', '').strip()
    exp1 = request.form.get('output_1', '').strip()
    inp2 = request.form.get('input_2', '').strip()
    exp2 = request.form.get('output_2', '').strip()

    test_cases = []
    if inp1 and exp1:
        test_cases.append({'input_data': inp1, 'expected_output': exp1, 'is_hidden': 0})
    if inp2 and exp2:
        test_cases.append({'input_data': inp2, 'expected_output': exp2, 'is_hidden': 1})

    res = create_coding_problem(
        course_id=course_id,
        title=title,
        description=description,
        difficulty=difficulty,
        language=language,
        starter_code=starter_code,
        time_limit_seconds=time_limit,
        test_cases=test_cases,
        created_by=user['id']
    )

    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('teacher_bp.coding_assessments', course_id=course_id))

@teacher_bp.route('/assignments/<int:assignment_id>/rubric')
@login_required
@role_required('teacher')
def rubric_view(assignment_id):
    user = get_current_user()
    assignment = query_db("""
        SELECT a.*, c.name as course_name, c.code as course_code
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    """, (assignment_id,), one=True)
    if not assignment:
        flash('Bài tập không tồn tại.', 'danger')
        return redirect(url_for('teacher_bp.assignments'))

    rubric = get_rubric_for_assignment(assignment_id)
    return render_template('teacher/rubric_config.html', user=user, assignment=assignment, rubric=rubric)

@teacher_bp.route('/assignments/<int:assignment_id>/rubric/save', methods=['POST'])
@login_required
@role_required('teacher')
def save_rubric_endpoint(assignment_id):
    user = get_current_user()
    title = request.form.get('title', 'Rubric Tiêu chuẩn').strip()
    description = request.form.get('description', '').strip()

    # Nhận các tiêu chí từ form
    crit_names = request.form.getlist('criterion_name[]')
    weights = request.form.getlist('weight_pct[]')
    max_pts = request.form.getlist('max_points[]')

    criteria_list = []
    for i in range(len(crit_names)):
        if crit_names[i].strip():
            w = float(weights[i]) if i < len(weights) and weights[i] else 25.0
            mp = float(max_pts[i]) if i < len(max_pts) and max_pts[i] else 10.0
            criteria_list.append({
                'criterion_name': crit_names[i].strip(),
                'weight_pct': w,
                'max_points': mp,
                'description': 'Đánh giá mức độ hoàn thiện tiêu chí'
            })

    if not criteria_list:
        criteria_list = [
            {'criterion_name': 'Nội dung & Tính chính xác', 'weight_pct': 40.0, 'max_points': 10.0},
            {'criterion_name': 'Cấu trúc & Trình bày', 'weight_pct': 30.0, 'max_points': 10.0},
            {'criterion_name': 'Tính sáng tạo & Kỹ năng giải quyết vấn đề', 'weight_pct': 30.0, 'max_points': 10.0}
        ]

    res = create_rubric(assignment_id, title, description, criteria_list, user['id'])
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('teacher_bp.rubric_view', assignment_id=assignment_id))

@teacher_bp.route('/submissions/<int:submission_id>/rubric-grade', methods=['POST'])
@login_required
@role_required('teacher')
def rubric_grade_endpoint(submission_id):
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    rubric_id = int(data.get('rubric_id', 0))
    evaluations = data.get('evaluations', [])

    if isinstance(evaluations, str):
        try:
            evaluations = json.loads(evaluations)
        except Exception:
            evaluations = []

    res = grade_with_rubric(rubric_id, submission_id, evaluations, user['id'])
    return jsonify(res)


# ==========================================
# PHASE 6: TEACHER COMPETENCY VERIFICATION
# ==========================================

@teacher_bp.route('/competencies')
@login_required
@role_required('teacher')
def teacher_competencies():
    user = get_current_user()
    from services.portfolio_competency_service import get_all_competencies, get_student_competency_profile
    courses = query_db("SELECT id, code, name FROM courses WHERE teacher_id = ? ORDER BY code ASC", (user['id'],))
    course_id = request.args.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else (courses[0]['id'] if courses else None)

    competencies = get_all_competencies()

    # Sinh viên trong lớp học phần
    students = []
    if cid:
        students = query_db("""
            SELECT u.id, u.full_name, u.email, st.student_code
            FROM enrollments e
            JOIN users u ON e.student_id = u.id
            LEFT JOIN students st ON u.id = st.user_id
            WHERE e.course_id = ?
            ORDER BY u.full_name ASC
        """, (cid,))

    return render_template(
        'teacher/competency_verification.html',
        user=user,
        courses=courses,
        selected_course_id=cid,
        competencies=competencies,
        students=students
    )

@teacher_bp.route('/competencies/verify', methods=['POST'])
@login_required
@role_required('teacher')
def verify_competency_endpoint():
    user = get_current_user()
    from services.portfolio_competency_service import update_or_verify_student_competency
    data = request.get_json(silent=True) or request.form
    student_id = int(data.get('student_id', 0))
    competency_id = int(data.get('competency_id', 0))
    level = int(data.get('level', 3))
    status = data.get('status', 'ACHIEVED')
    evidence_text = data.get('evidence', 'Giảng viên xác thực qua kết quả đồ án và bài kiểm tra trên lớp.')

    res = update_or_verify_student_competency(
        student_id=student_id,
        competency_id=competency_id,
        level=level,
        status=status,
        evidence_text=evidence_text,
        verified_by=user['id']
    )
    return jsonify(res)

