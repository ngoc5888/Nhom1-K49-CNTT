from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, Response
from werkzeug.security import generate_password_hash, check_password_hash
from database import query_db, execute_db
from auth import login_required, get_current_user
from datetime import datetime

common_bp = Blueprint('common_bp', __name__)

@common_bp.route('/notifications')
@login_required
def notifications():
    user = get_current_user()

    # Mark all read if requested
    action = request.args.get('action')
    if action == 'mark_all_read':
        execute_db("UPDATE notifications SET is_read = 1 WHERE user_id = ?", (user['id'],))
        flash("Đã đánh dấu tất cả thông báo là đã đọc.", "success")
        return redirect(url_for('common_bp.notifications'))

    all_notifs = query_db("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC", (user['id'],))

    return render_template('common/notifications.html', notifications=all_notifs)

@common_bp.route('/notification/<int:notif_id>/read')
@login_required
def read_notification(notif_id):
    user = get_current_user()
    notif = query_db("SELECT * FROM notifications WHERE id = ? AND user_id = ?", (notif_id, user['id']), one=True)
    if notif:
        execute_db("UPDATE notifications SET is_read = 1 WHERE id = ?", (notif_id,))
        if notif['link'] and notif['link'] != '#':
            return redirect(notif['link'])
    return redirect(url_for('common_bp.notifications'))

@common_bp.route('/notification/<int:notif_id>/delete')
@login_required
def delete_notification(notif_id):
    user = get_current_user()
    execute_db("DELETE FROM notifications WHERE id = ? AND user_id = ?", (notif_id, user['id']))
    flash("Đã xóa thông báo.", "info")
    return redirect(url_for('common_bp.notifications'))

@common_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = get_current_user()

    # Get specific role details
    student_details = None
    teacher_details = None

    if user['role'] == 'student':
        student_details = query_db("""
            SELECT s.*, c.name as class_name, m.name as major_name, d.name as dept_name
            FROM students s
            LEFT JOIN student_classes c ON s.student_class_id = c.id
            LEFT JOIN majors m ON s.major_id = m.id
            LEFT JOIN departments d ON s.department_id = d.id
            WHERE s.user_id = ?
        """, (user['id'],), one=True)
    elif user['role'] == 'teacher':
        teacher_details = query_db("""
            SELECT t.*, d.name as dept_name
            FROM teachers t
            LEFT JOIN departments d ON t.department_id = d.id
            WHERE t.user_id = ?
        """, (user['id'],), one=True)

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'update_info':
            full_name = request.form.get('full_name', '').strip()
            phone = request.form.get('phone', '').strip()

            execute_db("UPDATE users SET full_name = ?, phone = ? WHERE id = ?", (full_name, phone, user['id']))
            flash("Cập nhật thông tin cá nhân thành công!", "success")
            return redirect(url_for('common_bp.profile'))

        elif action == 'change_password':
            old_pass = request.form.get('old_password', '').strip()
            new_pass = request.form.get('new_password', '').strip()
            confirm_pass = request.form.get('confirm_password', '').strip()

            if not check_password_hash(user['password_hash'], old_pass):
                flash("Mật khẩu hiện tại không chính xác.", "danger")
            elif new_pass != confirm_pass:
                flash("Mật khẩu mới không trùng khớp.", "danger")
            elif len(new_pass) < 6:
                flash("Mật khẩu mới phải có ít nhất 6 ký tự.", "danger")
            else:
                new_hash = generate_password_hash(new_pass)
                execute_db("UPDATE users SET password_hash = ? WHERE id = ?", (new_hash, user['id']))
                flash("Đổi mật khẩu thành công!", "success")

            return redirect(url_for('common_bp.profile'))

    return render_template(
        'common/profile.html',
        user=user,
        student_details=student_details,
        teacher_details=teacher_details
    )

@common_bp.route('/maintenance')
def maintenance():
    return render_template('common/maintenance.html')

@common_bp.route('/system-locked')
def system_locked():
    return render_template('common/system_locked.html')

@common_bp.route('/portfolio/<int:student_id>')
def public_portfolio(student_id):
    from services.portfolio_competency_service import get_public_portfolio_by_user_id
    portfolio_data = get_public_portfolio_by_user_id(student_id)
    if not portfolio_data:
        return render_template('common/public_portfolio_not_found.html'), 404
    return render_template('common/public_portfolio.html', portfolio=portfolio_data)


# =====================================================================
# PHASE 7: SMART CALENDAR, DISCUSSION FORUM, GROUP WORKSPACE & INTEROP
# =====================================================================

# 1. SMART CALENDAR
@common_bp.route('/calendar')
@login_required
def calendar_view():
    user = get_current_user()
    from services.ecosystem_service import get_user_calendar_events
    course_id = request.args.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else None
    events = get_user_calendar_events(user['id'], user['role'], course_id=cid)
    
    # Danh sách lớp học phần để lọc
    if user['role'] == 'student':
        user_courses = query_db("""
            SELECT c.id, c.code, c.name FROM enrollments e JOIN courses c ON e.course_id = c.id WHERE e.student_id = ?
        """, (user['id'],))
    elif user['role'] == 'teacher':
        user_courses = query_db("SELECT id, code, name FROM courses WHERE teacher_id = ?", (user['id'],))
    else:
        user_courses = query_db("SELECT id, code, name FROM courses LIMIT 50")
        
    return render_template(
        'calendar/smart_calendar.html',
        user=user,
        events=events,
        user_courses=user_courses,
        selected_course_id=cid
    )

@common_bp.route('/api/calendar/events', methods=['GET', 'POST'])
@login_required
def api_calendar_events():
    user = get_current_user()
    from services.ecosystem_service import get_user_calendar_events, create_calendar_event
    if request.method == 'POST':
        data = request.get_json(silent=True) or request.form
        title = data.get('title', '').strip()
        start_time = data.get('start_time', '').strip()
        end_time = data.get('end_time', '').strip() or None
        course_id = int(data.get('course_id')) if data.get('course_id') and str(data.get('course_id')).isdigit() else None
        description = data.get('description', '').strip()
        event_type = data.get('event_type', 'personal')
        color = data.get('color', '#6366f1')
        res = create_calendar_event(user['id'], title, start_time, end_time, course_id, description, event_type, color)
        return jsonify(res)
    else:
        course_id = request.args.get('course_id')
        cid = int(course_id) if course_id and course_id.isdigit() else None
        events = get_user_calendar_events(user['id'], user['role'], course_id=cid)
        return jsonify({'success': True, 'events': events})

@common_bp.route('/api/calendar/events/<int:event_id>', methods=['DELETE', 'POST'])
@login_required
def api_delete_calendar_event(event_id):
    user = get_current_user()
    from services.ecosystem_service import delete_calendar_event
    res = delete_calendar_event(event_id, user['id'])
    return jsonify(res)

@common_bp.route('/calendar/export.ics')
@login_required
def calendar_export_ics():
    user = get_current_user()
    from services.ecosystem_service import export_calendar_ics
    ics_content = export_calendar_ics(user['id'], user['role'])
    return Response(
        ics_content,
        mimetype="text/calendar",
        headers={"Content-Disposition": "attachment; filename=lms_calendar.ics"}
    )

# 2. DISCUSSION FORUM
@common_bp.route('/courses/<int:course_id>/discussions')
@login_required
def course_discussions_view(course_id):
    user = get_current_user()
    from services.ecosystem_service import can_access_course_forum, get_course_discussions
    if not can_access_course_forum(user['id'], course_id, user['role']):
        flash("Bạn không có quyền truy cập diễn đàn của môn học này.", "danger")
        return redirect(url_for('common_bp.notifications'))

    course = query_db("SELECT * FROM courses WHERE id = ?", (course_id,), one=True)
    if not course:
        flash("Lớp học phần không tồn tại.", "danger")
        return redirect(url_for('common_bp.notifications'))

    search = request.args.get('q', '').strip()
    tag = request.args.get('tag', '').strip()
    discussions = get_course_discussions(course_id, search=search or None, tag=tag or None)
    return render_template(
        'discussion/course_discussions.html',
        user=user,
        course=course,
        discussions=discussions,
        search_query=search,
        selected_tag=tag
    )

@common_bp.route('/courses/<int:course_id>/discussions/create', methods=['POST'])
@login_required
def create_discussion_endpoint(course_id):
    user = get_current_user()
    from services.ecosystem_service import can_access_course_forum, create_discussion_topic
    if not can_access_course_forum(user['id'], course_id, user['role']):
        flash("Bạn không có quyền đăng thảo luận trong môn này.", "danger")
        return redirect(url_for('common_bp.notifications'))

    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    tags_raw = request.form.get('tags', '').strip()
    is_pinned = 1 if (request.form.get('is_pinned') and user['role'] in ['teacher', 'admin']) else 0

    res = create_discussion_topic(course_id, user['id'], title, content, is_pinned=is_pinned, tags=tags_raw)
    if res.get('success'):
        flash(res.get('message'), 'success')
        return redirect(url_for('common_bp.discussion_detail_view', discussion_id=res['discussion_id']))
    else:
        flash(res.get('message'), 'danger')
        return redirect(url_for('common_bp.course_discussions_view', course_id=course_id))

@common_bp.route('/discussions/<int:discussion_id>')
@login_required
def discussion_detail_view(discussion_id):
    user = get_current_user()
    from services.ecosystem_service import get_discussion_detail, can_access_course_forum
    topic = get_discussion_detail(discussion_id)
    if not topic:
        flash("Chủ đề thảo luận không tồn tại.", "danger")
        return redirect(url_for('common_bp.notifications'))

    if not can_access_course_forum(user['id'], topic['course_id'], user['role']):
        flash("Bạn không có quyền xem thảo luận của môn học này.", "danger")
        return redirect(url_for('common_bp.notifications'))

    return render_template('discussion/discussion_detail.html', user=user, topic=topic)

@common_bp.route('/discussions/<int:discussion_id>/comment', methods=['POST'])
@login_required
def add_discussion_comment_endpoint(discussion_id):
    user = get_current_user()
    from services.ecosystem_service import get_discussion_detail, can_access_course_forum, add_discussion_comment
    topic = get_discussion_detail(discussion_id)
    if not topic or not can_access_course_forum(user['id'], topic['course_id'], user['role']):
        flash("Không có quyền gửi phản hồi.", "danger")
        return redirect(url_for('common_bp.notifications'))

    content = request.form.get('content', '').strip()
    res = add_discussion_comment(discussion_id, user['id'], content)
    if res.get('success'):
        flash("Đã gửi câu trả lời thành công!", "success")
    else:
        flash(res.get('message', 'Lỗi gửi câu trả lời'), "danger")
    return redirect(url_for('common_bp.discussion_detail_view', discussion_id=discussion_id))

@common_bp.route('/discussions/<int:discussion_id>/upvote', methods=['POST'])
@login_required
def upvote_discussion_endpoint(discussion_id):
    from services.ecosystem_service import upvote_discussion
    res = upvote_discussion(discussion_id)
    return jsonify(res)

@common_bp.route('/discussions/comments/<int:comment_id>/accept', methods=['POST'])
@login_required
def accept_comment_endpoint(comment_id):
    user = get_current_user()
    from services.ecosystem_service import toggle_accepted_answer
    res = toggle_accepted_answer(comment_id, user['id'])
    return jsonify(res)

@common_bp.route('/discussions/<int:discussion_id>/pin', methods=['POST'])
@login_required
def pin_discussion_endpoint(discussion_id):
    user = get_current_user()
    if user['role'] not in ['teacher', 'admin']:
        return jsonify({'success': False, 'message': 'Chỉ giảng viên mới có quyền ghim thông báo.'}), 403
    from services.ecosystem_service import toggle_pin_discussion
    res = toggle_pin_discussion(discussion_id, user['id'])
    return jsonify(res)

# 3. GROUP WORKSPACE
@common_bp.route('/courses/<int:course_id>/groups')
@login_required
def course_groups_view(course_id):
    user = get_current_user()
    from services.ecosystem_service import can_access_course_forum, get_course_groups
    if not can_access_course_forum(user['id'], course_id, user['role']):
        flash("Bạn không có quyền truy cập không gian nhóm của môn học này.", "danger")
        return redirect(url_for('common_bp.notifications'))

    course = query_db("SELECT * FROM courses WHERE id = ?", (course_id,), one=True)
    group_data = get_course_groups(course_id, current_user_id=user['id'])
    return render_template(
        'group/group_workspace.html',
        user=user,
        course=course,
        groups=group_data['groups'],
        user_group_id=group_data['user_group_id']
    )

@common_bp.route('/courses/<int:course_id>/groups/create', methods=['POST'])
@login_required
def create_group_endpoint(course_id):
    user = get_current_user()
    from services.ecosystem_service import can_access_course_forum, create_course_group
    if not can_access_course_forum(user['id'], course_id, user['role']):
        flash("Bạn không thuộc môn học này.", "danger")
        return redirect(url_for('common_bp.notifications'))

    name = request.form.get('name', '').strip()
    description = request.form.get('description', '').strip()
    topic_name = request.form.get('topic_name', '').strip()
    max_members = int(request.form.get('max_members', 5))

    res = create_course_group(course_id, name, description, leader_id=user['id'], max_members=max_members, topic_name=topic_name)
    if res.get('success'):
        flash(res.get('message'), 'success')
        return redirect(url_for('common_bp.group_detail_view', group_id=res['group_id']))
    else:
        flash(res.get('message'), 'danger')
        return redirect(url_for('common_bp.course_groups_view', course_id=course_id))

@common_bp.route('/groups/<int:group_id>')
@login_required
def group_detail_view(group_id):
    user = get_current_user()
    from services.ecosystem_service import get_group_detail
    group_data = get_group_detail(group_id, current_user_id=user['id'])
    if not group_data:
        flash("Nhóm học tập không tồn tại.", "danger")
        return redirect(url_for('common_bp.notifications'))

    return render_template('group/group_detail.html', user=user, group=group_data)

@common_bp.route('/groups/<int:group_id>/join', methods=['POST'])
@login_required
def join_group_endpoint(group_id):
    user = get_current_user()
    from services.ecosystem_service import join_course_group
    res = join_course_group(group_id, user['id'])
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('common_bp.group_detail_view', group_id=group_id))

@common_bp.route('/groups/<int:group_id>/leave', methods=['POST'])
@login_required
def leave_group_endpoint(group_id):
    user = get_current_user()
    from services.ecosystem_service import leave_course_group, get_group_detail
    group = get_group_detail(group_id, user['id'])
    cid = group['course_id'] if group else 1
    res = leave_course_group(group_id, user['id'])
    flash(res.get('message'), 'info')
    return redirect(url_for('common_bp.course_groups_view', course_id=cid))

@common_bp.route('/groups/<int:group_id>/tasks/add', methods=['POST'])
@login_required
def add_group_task_endpoint(group_id):
    user = get_current_user()
    from services.ecosystem_service import create_group_task
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    assigned_to = int(request.form.get('assigned_to')) if request.form.get('assigned_to') and request.form.get('assigned_to').isdigit() else None
    due_date = request.form.get('due_date', '').strip() or None
    priority = request.form.get('priority', 'MEDIUM')

    res = create_group_task(group_id, title, description, assigned_to=assigned_to, due_date=due_date, priority=priority, created_by=user['id'])
    if res.get('success'):
        flash("Đã giao nhiệm vụ mới cho nhóm!", "success")
    else:
        flash(res.get('message'), "danger")
    return redirect(url_for('common_bp.group_detail_view', group_id=group_id))

@common_bp.route('/groups/tasks/<int:task_id>/update-status', methods=['POST'])
@login_required
def update_group_task_endpoint(task_id):
    from services.ecosystem_service import update_group_task_status
    data = request.get_json(silent=True) or request.form
    status = data.get('status', 'DONE')
    progress_pct = float(data.get('progress_pct', 100.0)) if data.get('progress_pct') else None
    res = update_group_task_status(task_id, status, progress_pct)
    return jsonify(res)

@common_bp.route('/groups/<int:group_id>/resources/add', methods=['POST'])
@login_required
def add_group_resource_endpoint(group_id):
    user = get_current_user()
    from services.ecosystem_service import add_group_resource
    title = request.form.get('title', '').strip()
    url_or_path = request.form.get('url_or_path', '').strip()
    resource_type = request.form.get('resource_type', 'link')
    notes = request.form.get('notes', '').strip()

    res = add_group_resource(group_id, user['id'], title, resource_type=resource_type, url_or_path=url_or_path, notes=notes)
    if res.get('success'):
        flash("Đã thêm tài liệu chia sẻ thành công!", "success")
    else:
        flash(res.get('message'), "danger")
    return redirect(url_for('common_bp.group_detail_view', group_id=group_id))

# 4. INTEROPERABILITY APIS
@common_bp.route('/api/v1/interop/exams/<int:exam_id>/qti.xml')
def interop_export_qti_xml(exam_id):
    from services.ecosystem_service import export_exam_to_qti_xml
    xml = export_exam_to_qti_xml(exam_id)
    if not xml:
        return Response("<error>Đề thi không tồn tại</error>", status=404, mimetype="application/xml")
    return Response(xml, mimetype="application/xml", headers={"Content-Disposition": f"attachment; filename=exam_{exam_id}_qti.xml"})

@common_bp.route('/api/v1/interop/badges/<int:student_badge_id>.json')
def interop_export_open_badges(student_badge_id):
    from services.ecosystem_service import export_badge_open_badges_json_ld
    base_url = request.host_url.rstrip('/')
    data = export_badge_open_badges_json_ld(student_badge_id, base_url=base_url)
    if not data:
        return jsonify({'error': 'Huy hiệu không tồn tại'}), 404
    return jsonify(data)

@common_bp.route('/api/v1/interop/xapi/statements', methods=['POST', 'GET'])
def interop_xapi_endpoint():
    if request.method == 'GET':
        return jsonify({'status': 'active', 'standard': 'xAPI / ADL Tin Can 1.0.3', 'lrs_endpoint': '/api/v1/interop/xapi/statements'})
    data = request.get_json(silent=True) or {}
    return jsonify({'success': True, 'statement_id': f"xapi_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}", 'received': True})


