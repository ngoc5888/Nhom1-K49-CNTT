import math
from functools import wraps
from flask import Blueprint, request, jsonify, g
from auth import get_current_user
from database import query_db, get_setting
from services.audit_service import log_audit, get_audit_logs
from services.activity_service import get_user_activities
from services.config_service import get_all_system_configs, update_system_config

api_bp = Blueprint('api_bp', __name__, url_prefix='/api/v1')

def api_response(data=None, message="Thành công", code=200, success=True, meta=None):
    payload = {
        "success": success,
        "code": code,
        "message": message,
        "data": data
    }
    if meta is not None:
        payload["meta"] = meta
    return jsonify(payload), code

def api_error(message="Có lỗi xảy ra", code=400, errors=None):
    return jsonify({
        "success": False,
        "code": code,
        "message": message,
        "errors": errors
    }), code

def api_login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if user is None:
            return api_error("Yêu cầu đăng nhập để truy cập tài nguyên này", 401)
        if not user['is_active']:
            return api_error("Tài khoản của bạn đã bị khóa", 403)
        return f(*args, **kwargs)
    return decorated

def api_role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = get_current_user()
            if user is None:
                return api_error("Yêu cầu đăng nhập", 401)
            if user['role'] not in roles:
                return api_error("Bạn không có quyền truy cập API này", 403)
            return f(*args, **kwargs)
        return decorated
    return decorator

@api_bp.route('/system/health', methods=['GET'])
def health():
    """Public health check endpoint."""
    is_maintenance = get_setting('maintenance_mode', '0') == '1'
    is_locked = get_setting('system_lock', '0') == '1'
    return api_response({
        "status": "UP",
        "maintenance_mode": is_maintenance,
        "system_lock": is_locked,
        "version": "2.0-smart-learning"
    }, "Hệ thống hoạt động bình thường")

@api_bp.route('/auth/me', methods=['GET'])
@api_login_required
def get_me():
    """Retrieve authenticated user profile."""
    user = get_current_user()
    user_dict = {
        "id": user['id'],
        "email": user['email'],
        "full_name": user['full_name'],
        "role": user['role'],
        "avatar": user['avatar'],
        "phone": user['phone'],
        "is_active": bool(user['is_active']),
        "created_at": user['created_at']
    }
    return api_response(user_dict, "Lấy thông tin người dùng thành công")

@api_bp.route('/courses', methods=['GET'])
@api_login_required
def get_courses():
    """Retrieve courses based on caller role with pagination."""
    user = get_current_user()
    page = max(1, request.args.get('page', 1, type=int))
    per_page = min(50, max(1, request.args.get('per_page', 10, type=int)))
    offset = (page - 1) * per_page
    search = request.args.get('search', '').strip()

    search_clause = ""
    params = []
    if search:
        search_clause = " AND (c.name LIKE ? OR c.code LIKE ? OR s.name LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s])

    if user['role'] == 'admin':
        base_query = f"""
            FROM courses c
            JOIN subjects s ON c.subject_id = s.id
            JOIN users u ON c.teacher_id = u.id
            WHERE 1=1 {search_clause}
        """
        count_query = f"SELECT COUNT(*) as cnt {base_query}"
        data_query = f"""
            SELECT c.*, s.name as subject_name, s.credits, u.full_name as teacher_name
            {base_query}
            ORDER BY c.id DESC
            LIMIT ? OFFSET ?
        """
    elif user['role'] == 'teacher':
        base_query = f"""
            FROM courses c
            JOIN subjects s ON c.subject_id = s.id
            WHERE c.teacher_id = ? {search_clause}
        """
        params = [user['id']] + params
        count_query = f"SELECT COUNT(*) as cnt {base_query}"
        data_query = f"""
            SELECT c.*, s.name as subject_name, s.credits
            {base_query}
            ORDER BY c.id DESC
            LIMIT ? OFFSET ?
        """
    else: # student
        base_query = f"""
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            JOIN subjects s ON c.subject_id = s.id
            JOIN users u ON c.teacher_id = u.id
            WHERE e.student_id = ? {search_clause}
        """
        params = [user['id']] + params
        count_query = f"SELECT COUNT(*) as cnt {base_query}"
        data_query = f"""
            SELECT c.*, s.name as subject_name, s.credits, u.full_name as teacher_name, e.enrolled_at
            {base_query}
            ORDER BY c.id DESC
            LIMIT ? OFFSET ?
        """

    total_rows = query_db(count_query, tuple(params[:len(params)]), one=True)['cnt']
    exec_params = tuple(params + [per_page, offset])
    rows = query_db(data_query, exec_params)

    data = [dict(r) for r in rows]
    meta = {
        "page": page,
        "per_page": per_page,
        "total_items": total_rows,
        "total_pages": math.ceil(total_rows / per_page) if per_page else 1
    }
    return api_response(data, "Lấy danh sách khóa học thành công", meta=meta)

@api_bp.route('/courses/<int:course_id>/materials', methods=['GET'])
@api_login_required
def get_course_materials(course_id):
    """Retrieve materials for a course with RBAC isolation."""
    user = get_current_user()

    # Permission check: student must be enrolled, teacher must own course, admin has full access
    if user['role'] == 'student':
        enrolled = query_db("SELECT id FROM enrollments WHERE course_id = ? AND student_id = ?", (course_id, user['id']), one=True)
        if not enrolled:
            return api_error("Bạn chưa ghi danh vào lớp học phần này", 403)
    elif user['role'] == 'teacher':
        owned = query_db("SELECT id FROM courses WHERE id = ? AND teacher_id = ?", (course_id, user['id']), one=True)
        if not owned:
            return api_error("Bạn không phụ trách lớp học phần này", 403)

    materials = query_db("""
        SELECT m.*, u.full_name as uploaded_by_name
        FROM materials m
        JOIN users u ON m.uploaded_by = u.id
        WHERE m.course_id = ?
        ORDER BY m.created_at DESC
    """, (course_id,))

    return api_response([dict(m) for m in materials], "Lấy danh sách học liệu thành công")

@api_bp.route('/activities/recent', methods=['GET'])
@api_login_required
def get_recent_activities():
    """Retrieve recent learning activities of the authenticated user."""
    user = get_current_user()
    limit = min(50, max(5, request.args.get('limit', 15, type=int)))
    activities = get_user_activities(user['id'], limit=limit)
    return api_response([dict(a) for a in activities], "Lấy hoạt động học tập gần đây thành công")

@api_bp.route('/admin/audit-logs', methods=['GET'])
@api_login_required
@api_role_required('admin')
def get_system_audit_logs():
    """Paginated and filtered audit logs for administrators."""
    page = max(1, request.args.get('page', 1, type=int))
    per_page = min(100, max(5, request.args.get('per_page', 20, type=int)))
    offset = (page - 1) * per_page
    action = request.args.get('action')
    role = request.args.get('role')
    search = request.args.get('search')

    logs = get_audit_logs(limit=per_page, offset=offset, action_filter=action, role_filter=role, search=search)
    return api_response([dict(l) for l in logs], "Lấy nhật ký kiểm toán thành công", meta={
        "page": page,
        "per_page": per_page
    })

@api_bp.route('/admin/system-config', methods=['GET', 'POST'])
@api_login_required
@api_role_required('admin')
def manage_system_config():
    """View and update system and AI configuration parameters."""
    user = get_current_user()
    if request.method == 'POST':
        data = request.get_json(silent=True) or request.form.to_dict()
        if not data:
            return api_error("Dữ liệu cấu hình không hợp lệ", 400)

        updated_keys = []
        for k, v in data.items():
            update_system_config(k, v)
            updated_keys.append(k)

        log_audit(
            user_id=user['id'],
            user_email=user['email'],
            user_role='admin',
            action='CHANGE_SYSTEM_SETTING',
            target_type='system_setting',
            details={"updated_keys": updated_keys}
        )
        return api_response({"updated": updated_keys}, "Cập nhật cấu hình thành công")

    configs = get_all_system_configs()
    return api_response(configs, "Lấy danh sách cấu hình hệ thống thành công")
