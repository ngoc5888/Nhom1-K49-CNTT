import os
import json
import time
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app, jsonify
from database import query_db, execute_db
from auth import login_required, role_required, get_current_user
from services.activity_service import track_activity
from services.ai_gateway import call_ai
from services.rag_service import query_rag_learning_assistant
from services.adaptive_service import compute_student_learning_path, update_topic_progress, get_student_courses
from services.spaced_repetition_service import (
    process_flashcard_review, get_student_flashcards, get_flashcard_stats,
    create_flashcard, delete_flashcard, generate_flashcards_with_ai,
    get_student_notes, create_student_note, delete_student_note,
    record_study_session, get_study_session_stats
)
from services.smart_assessment_service import (
    start_adaptive_practice, submit_adaptive_practice_answer, get_adaptive_practice_report,
    record_submission_version, get_submission_history, seed_default_question_bank_if_empty
)
from services.online_coding_service import (
    get_coding_problems, get_coding_problem_detail, submit_coding_solution,
    get_student_coding_submissions, seed_default_coding_problems
)
from services.portfolio_competency_service import (
    get_student_competency_profile, get_or_create_student_portfolio,
    update_portfolio_profile, add_portfolio_item, delete_portfolio_item,
    get_all_badges, get_student_badges, check_and_auto_award_badges
)

student_bp = Blueprint('student_bp', __name__, url_prefix='/student')

DEBUG_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'debug-45cb16.log')


def score10_to_gpa4(score):
    if score is None:
        return 0.0
    s = float(score)
    if s >= 9.0:
        return 4.0
    if s >= 8.5:
        return 3.7
    if s >= 8.0:
        return 3.5
    if s >= 7.0:
        return 3.0
    if s >= 6.5:
        return 2.5
    if s >= 5.5:
        return 2.0
    if s >= 4.0:
        return 1.0
    return 0.0


def classify_gpa4(gpa):
    if gpa >= 3.6:
        return "Xuất sắc"
    if gpa >= 3.2:
        return "Giỏi"
    if gpa >= 2.5:
        return "Khá"
    if gpa >= 2.0:
        return "Trung bình"
    return "Yếu"


def compute_gpa4(grade_rows):
    total_credits = 0
    weighted = 0.0
    for row in grade_rows or []:
        credits = row['credits'] or 0
        total_credits += credits
        weighted += score10_to_gpa4(row['total_score']) * credits
    if total_credits <= 0:
        return 0.0
    return round(weighted / total_credits, 2)


def grade_components(row):
    """A1 chuyên cần (bài tập + kiểm tra, thang 10); A2 giữa kỳ; A3 cuối kỳ."""
    assignment = float(row['assignment_score'] or 0)
    quiz = float(row['quiz_score'] or 0)
    if quiz == 0 or assignment == quiz:
        a1 = round(assignment, 2)
    else:
        a1 = round((assignment + quiz) / 2.0, 2)
    a2 = round(float(row['midterm_score'] or 0), 2)
    a3 = round(float(row['final_score'] or 0), 2)
    return a1, a2, a3


def compute_total10(a1, a2, a3):
    return round(float(a1) * 0.2 + float(a2) * 0.3 + float(a3) * 0.5, 2)


def _dbg(hypothesis_id, location, message, data, run_id='post-fix'):
    # #region agent log
    try:
        with open(DEBUG_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(json.dumps({
                'sessionId': '45cb16',
                'runId': run_id,
                'hypothesisId': hypothesis_id,
                'location': location,
                'message': message,
                'data': data,
                'timestamp': int(time.time() * 1000),
            }) + '\n')
    except Exception:
        pass
    # #endregion

@student_bp.route('/dashboard')
@login_required
@role_required('student')
def dashboard():
    user = get_current_user()
    user_id = user['id']

    # Get student info
    student_info = query_db("""
        SELECT s.*, c.name as class_name, m.name as major_name, d.name as dept_name
        FROM students s
        LEFT JOIN student_classes c ON s.student_class_id = c.id
        LEFT JOIN majors m ON s.major_id = m.id
        LEFT JOIN departments d ON s.department_id = d.id
        WHERE s.user_id = ?
    """, (user_id,), one=True)

    # 1. Class count
    classes_count = query_db("""
        SELECT COUNT(*) as count FROM enrollments WHERE student_id = ? AND status = 'active'
    """, (user_id,), one=True)['count']

    # 2. Materials count across student courses
    materials_count = query_db("""
        SELECT COUNT(m.id) as count
        FROM materials m
        JOIN enrollments e ON m.course_id = e.course_id
        WHERE e.student_id = ?
    """, (user_id,), one=True)['count']

    # 3. Assignments count
    assignments_count = query_db("""
        SELECT COUNT(a.id) as count
        FROM assignments a
        JOIN enrollments e ON a.course_id = e.course_id
        WHERE e.student_id = ?
    """, (user_id,), one=True)['count']

    # 4. Exams count
    exams_count = query_db("""
        SELECT COUNT(ex.id) as count
        FROM exams ex
        JOIN enrollments e ON ex.course_id = e.course_id
        WHERE e.student_id = ?
    """, (user_id,), one=True)['count']

    # 5. Cumulative GPA (4.0 scale, credit-weighted)
    grade_rows = query_db("""
        SELECT g.total_score, g.assignment_score, g.quiz_score, g.midterm_score, g.final_score, sub.credits
        FROM grades g
        JOIN courses c ON g.course_id = c.id
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE g.student_id = ?
    """, (user_id,))
    recomputed = []
    for r in grade_rows:
        item = dict(r)
        a1, a2, a3 = grade_components(item)
        item['total_score'] = compute_total10(a1, a2, a3)
        recomputed.append(item)
    avg_score_10 = round(sum((r['total_score'] or 0) for r in recomputed) / len(recomputed), 2) if recomputed else 0.0
    avg_grade = compute_gpa4(recomputed)
    gpa_classification = classify_gpa4(avg_grade)
    # #region agent log
    _dbg('H1', 'student_routes.py:dashboard', 'dashboard GPA scales', {
        'avg_score_10': avg_score_10,
        'gpa4': avg_grade,
        'gpa_classification': gpa_classification,
        'grade_count': len(recomputed),
        'display_denominator': 4,
        'weights': 'A1 20 A2 30 A3 50',
    })
    # #endregion

    # 6. Overall progress percentage
    submitted_count = query_db("SELECT COUNT(*) as count FROM submissions WHERE student_id = ?", (user_id,), one=True)['count']
    progress_pct = round((submitted_count / assignments_count * 100), 1) if assignments_count > 0 else 0

    # 7. Upcoming assignments
    upcoming_assignments = query_db("""
        SELECT a.*, c.name as course_name, s.score, s.submitted_at
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        JOIN enrollments e ON a.course_id = e.course_id
        LEFT JOIN submissions s ON a.id = s.assignment_id AND s.student_id = e.student_id
        WHERE e.student_id = ?
        ORDER BY a.due_date ASC
        LIMIT 5
    """, (user_id,))

    # 8. Recent notifications
    recent_notifs = query_db("""
        SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5
    """, (user_id,))

    # 9. Enrolled classes preview
    recent_classes = query_db("""
        SELECT c.*, u.full_name as teacher_name, sub.name as subject_name,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as student_count
        FROM courses c
        JOIN enrollments e ON c.id = e.course_id
        JOIN users u ON c.teacher_id = u.id
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE e.student_id = ?
        LIMIT 4
    """, (user_id,))

    return render_template(
        'student/dashboard.html',
        user=user,
        student_info=student_info,
        classes_count=classes_count,
        materials_count=materials_count,
        assignments_count=assignments_count,
        exams_count=exams_count,
        avg_grade=avg_grade,
        gpa_classification=gpa_classification,
        progress_pct=progress_pct,
        upcoming_assignments=upcoming_assignments,
        recent_notifs=recent_notifs,
        recent_classes=recent_classes
    )

@student_bp.route('/classes')
@login_required
@role_required('student')
def classes():
    user = get_current_user()
    search = request.args.get('search', '').strip()
    subject_id = request.args.get('subject_id', '')

    query = """
        SELECT c.*, u.full_name as teacher_name, sub.name as subject_name, sub.credits,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as student_count
        FROM courses c
        JOIN enrollments e ON c.id = e.course_id
        JOIN users u ON c.teacher_id = u.id
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE e.student_id = ?
    """
    params = [user['id']]

    if search:
        query += " AND (c.name LIKE ? OR c.code LIKE ? OR sub.name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])
    if subject_id:
        query += " AND c.subject_id = ?"
        params.append(subject_id)

    query += " ORDER BY c.id DESC"
    enrolled_courses = query_db(query, params)
    all_subjects = query_db("SELECT * FROM subjects ORDER BY name ASC")

    return render_template('student/classes.html', courses=enrolled_courses, subjects=all_subjects, search=search, selected_subject=subject_id)

@student_bp.route('/class/<int:course_id>')
@login_required
@role_required('student')
def class_detail(course_id):
    user = get_current_user()

    # Check enrollment
    enrollment = query_db("SELECT * FROM enrollments WHERE course_id = ? AND student_id = ?", (course_id, user['id']), one=True)
    if not enrollment:
        flash("Bạn chưa đăng ký tham gia lớp học này.", "danger")
        return redirect(url_for('student_bp.classes'))

    track_activity(user['id'], course_id=course_id, event_type='VIEW_COURSE')

    course = query_db("""
        SELECT c.*, u.full_name as teacher_name, u.email as teacher_email, u.phone as teacher_phone,
               sub.name as subject_name, sub.code as subject_code, sub.credits, sub.description as subject_desc
        FROM courses c
        JOIN users u ON c.teacher_id = u.id
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE c.id = ?
    """, (course_id,), one=True)

    materials = query_db("SELECT m.*, u.full_name as uploader FROM materials m JOIN users u ON m.uploaded_by = u.id WHERE m.course_id = ? ORDER BY m.created_at DESC", (course_id,))
    assignments = query_db("""
        SELECT a.*, s.submitted_at, s.score
        FROM assignments a
        LEFT JOIN submissions s ON a.id = s.assignment_id AND s.student_id = ?
        WHERE a.course_id = ?
        ORDER BY a.due_date ASC
    """, (user['id'], course_id))

    exams = query_db("""
        SELECT ex.*, er.score as my_score, er.submitted_at as exam_submitted_at
        FROM exams ex
        LEFT JOIN exam_results er ON ex.id = er.exam_id AND er.student_id = ?
        WHERE ex.course_id = ?
        ORDER BY ex.created_at DESC
    """, (user['id'], course_id))

    members = query_db("""
        SELECT u.full_name, u.email, u.avatar, st.student_code
        FROM enrollments e
        JOIN users u ON e.student_id = u.id
        LEFT JOIN students st ON u.id = st.user_id
        WHERE e.course_id = ?
        ORDER BY u.full_name ASC
    """, (course_id,))

    return render_template(
        'student/class_detail.html',
        course=course,
        materials=materials,
        assignments=assignments,
        exams=exams,
        members=members
    )

@student_bp.route('/materials')
@login_required
@role_required('student')
def materials():
    user = get_current_user()
    search = request.args.get('search', '').strip()
    course_id = request.args.get('course_id', '')
    file_type = request.args.get('file_type', '')

    query = """
        SELECT m.*, c.name as course_name, u.full_name as uploader_name
        FROM materials m
        JOIN courses c ON m.course_id = c.id
        JOIN enrollments e ON c.id = e.course_id
        JOIN users u ON m.uploaded_by = u.id
        WHERE e.student_id = ?
    """
    params = [user['id']]

    if search:
        query += " AND (m.title LIKE ? OR m.description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    if course_id:
        query += " AND m.course_id = ?"
        params.append(course_id)
    if file_type:
        query += " AND m.file_type = ?"
        params.append(file_type)

    query += " ORDER BY m.created_at DESC"
    materials_list = query_db(query, params)

    enrolled_courses = query_db("""
        SELECT c.id, c.name FROM courses c JOIN enrollments e ON c.id = e.course_id WHERE e.student_id = ?
    """, (user['id'],))

    return render_template(
        'student/materials.html',
        materials=materials_list,
        courses=enrolled_courses,
        search=search,
        selected_course=course_id,
        selected_type=file_type
    )

@student_bp.route('/assignments')
@login_required
@role_required('student')
def assignments():
    user = get_current_user()
    search = request.args.get('search', '').strip()
    course_id = request.args.get('course_id', '')
    status = request.args.get('status', '')

    query = """
        SELECT a.*, c.name as course_name, s.file_path as sub_file, s.submitted_at, s.score, s.feedback
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        JOIN enrollments e ON c.id = e.course_id
        LEFT JOIN submissions s ON a.id = s.assignment_id AND s.student_id = ?
        WHERE e.student_id = ?
    """
    params = [user['id'], user['id']]

    if search:
        query += " AND (a.title LIKE ? OR a.description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    if course_id:
        query += " AND a.course_id = ?"
        params.append(course_id)

    query += " ORDER BY a.due_date ASC"
    all_assignments = query_db(query, params)

    # Filter by status post query for accuracy
    filtered_assignments = []
    for item in all_assignments:
        item_status = "Chưa làm"
        if item['score'] is not None:
            item_status = "Đã chấm"
        elif item['submitted_at'] is not None:
            item_status = "Đã nộp"

        if status:
            if status == item_status:
                filtered_assignments.append(item)
        else:
            filtered_assignments.append(item)

    enrolled_courses = query_db("""
        SELECT c.id, c.name FROM courses c JOIN enrollments e ON c.id = e.course_id WHERE e.student_id = ?
    """, (user['id'],))

    return render_template(
        'student/assignments.html',
        assignments=filtered_assignments,
        courses=enrolled_courses,
        search=search,
        selected_course=course_id,
        selected_status=status
    )

@student_bp.route('/assignment/<int:assignment_id>')
@login_required
@role_required('student')
def assignment_detail(assignment_id):
    user = get_current_user()

    assignment = query_db("""
        SELECT a.*, c.name as course_name, u.full_name as teacher_name
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        JOIN users u ON a.created_by = u.id
        WHERE a.id = ?
    """, (assignment_id,), one=True)

    if not assignment:
        flash("Bài tập không tồn tại.", "danger")
        return redirect(url_for('student_bp.assignments'))

    submission = query_db("""
        SELECT * FROM submissions WHERE assignment_id = ? AND student_id = ?
    """, (assignment_id, user['id']), one=True)

    return render_template('student/assignment_detail.html', assignment=assignment, submission=submission)

@student_bp.route('/assignment/<int:assignment_id>/submit', methods=['POST'])
@login_required
@role_required('student')
def submit_assignment(assignment_id):
    user = get_current_user()
    notes = request.form.get('notes', '').strip()
    file = request.files.get('submission_file')

    file_path = "/static/uploads/default_submission.zip"
    if file and file.filename != '':
        upload_folder = os.path.join(current_app.root_path, 'static', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        filename = f"sub_{user['id']}_{assignment_id}_{file.filename}"
        file.save(os.path.join(upload_folder, filename))
        file_path = f"/static/uploads/{filename}"

    existing = query_db("SELECT id FROM submissions WHERE assignment_id = ? AND student_id = ?", (assignment_id, user['id']), one=True)
    if existing:
        execute_db("""
            UPDATE submissions
            SET file_path = ?, notes = ?, submitted_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (file_path, notes, existing['id']))
        flash("Cập nhật bài nộp thành công!", "success")
    else:
        execute_db("""
            INSERT INTO submissions (assignment_id, student_id, file_path, notes)
            VALUES (?, ?, ?, ?)
        """, (assignment_id, user['id'], file_path, notes))
        flash("Nộp bài tập thành công!", "success")

    assignment = query_db("SELECT course_id FROM assignments WHERE id = ?", (assignment_id,), one=True)
    track_activity(user['id'], course_id=assignment['course_id'] if assignment else None,
                   event_type='SUBMIT_ASSIGNMENT', reference_id=assignment_id)

    return redirect(url_for('student_bp.assignment_detail', assignment_id=assignment_id))

@student_bp.route('/exams')
@login_required
@role_required('student')
def exams():
    user = get_current_user()

    exams_list = query_db("""
        SELECT ex.*, c.name as course_name, er.score as student_score, er.submitted_at as exam_submitted_at,
               (SELECT COUNT(*) FROM questions WHERE exam_id = ex.id) as question_count
        FROM exams ex
        JOIN courses c ON ex.course_id = c.id
        JOIN enrollments e ON c.id = e.course_id
        LEFT JOIN exam_results er ON ex.id = er.exam_id AND er.student_id = ?
        WHERE e.student_id = ?
        ORDER BY ex.created_at DESC
    """, (user['id'], user['id']))

    return render_template('student/exams.html', exams=exams_list)

@student_bp.route('/exam/<int:exam_id>/take')
@login_required
@role_required('student')
def take_exam(exam_id):
    user = get_current_user()

    # Check if already submitted
    existing_result = query_db("SELECT * FROM exam_results WHERE exam_id = ? AND student_id = ?", (exam_id, user['id']), one=True)
    if existing_result:
        flash("Bạn đã hoàn thành bài kiểm tra này trước đó.", "info")
        return redirect(url_for('student_bp.exam_result', exam_id=exam_id))

    exam = query_db("""
        SELECT ex.*, c.name as course_name FROM exams ex JOIN courses c ON ex.course_id = c.id WHERE ex.id = ?
    """, (exam_id,), one=True)

    if not exam:
        flash("Bài kiểm tra không tồn tại.", "danger")
        return redirect(url_for('student_bp.exams'))

    questions = query_db("SELECT * FROM questions WHERE exam_id = ?", (exam_id,))

    track_activity(user['id'], course_id=exam['course_id'], event_type='TAKE_EXAM', reference_id=exam_id)

    # Format JSON options
    formatted_questions = []
    for q in questions:
        q_dict = dict(q)
        q_dict['options'] = json.loads(q['options_json'])
        formatted_questions.append(q_dict)

    return render_template('student/take_exam.html', exam=exam, questions=formatted_questions)

@student_bp.route('/exam/<int:exam_id>/submit', methods=['POST'])
@login_required
@role_required('student')
def submit_exam(exam_id):
    user = get_current_user()

    existing_result = query_db("SELECT id FROM exam_results WHERE exam_id = ? AND student_id = ?", (exam_id, user['id']), one=True)
    if existing_result:
        return redirect(url_for('student_bp.exam_result', exam_id=exam_id))

    questions = query_db("SELECT * FROM questions WHERE exam_id = ?", (exam_id,))
    total_questions = len(questions)
    correct_count = 0
    total_points_earned = 0.0
    total_possible_points = sum(q['points'] for q in questions) if questions else 10.0

    student_answers = {}

    for q in questions:
        q_id = str(q['id'])
        correct_indices = json.loads(q['correct_answers_json'])

        # Selected options from form
        selected = request.form.getlist(f"question_{q_id}")
        selected_indices = [int(x) for x in selected if x.isdigit()]
        student_answers[q_id] = selected_indices

        if sorted(selected_indices) == sorted(correct_indices):
            correct_count += 1
            total_points_earned += q['points']

    final_score = round((total_points_earned / total_possible_points) * 10.0, 1) if total_possible_points > 0 else 0.0

    execute_db("""
        INSERT INTO exam_results (exam_id, student_id, score, total_questions, correct_count, answers_json)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (exam_id, user['id'], final_score, total_questions, correct_count, json.dumps(student_answers)))

    exam = query_db("SELECT course_id FROM exams WHERE id = ?", (exam_id,), one=True)
    track_activity(user['id'], course_id=exam['course_id'] if exam else None,
                   event_type='SUBMIT_EXAM', reference_id=exam_id,
                   metadata={'score': final_score, 'correct_count': correct_count, 'total_questions': total_questions})

    flash(f"Nộp bài kiểm tra thành công! Điểm của bạn: {final_score}/10", "success")
    return redirect(url_for('student_bp.exam_result', exam_id=exam_id))

@student_bp.route('/exam/<int:exam_id>/result')
@login_required
@role_required('student')
def exam_result(exam_id):
    user = get_current_user()

    result = query_db("SELECT * FROM exam_results WHERE exam_id = ? AND student_id = ?", (exam_id, user['id']), one=True)
    if not result:
        flash("Chưa tìm thấy kết quả làm bài.", "danger")
        return redirect(url_for('student_bp.exams'))

    exam = query_db("SELECT ex.*, c.name as course_name FROM exams ex JOIN courses c ON ex.course_id = c.id WHERE ex.id = ?", (exam_id,), one=True)
    questions = query_db("SELECT * FROM questions WHERE exam_id = ?", (exam_id,))

    answers_given = json.loads(result['answers_json']) if result['answers_json'] else {}

    formatted_questions = []
    for q in questions:
        q_dict = dict(q)
        q_dict['options'] = json.loads(q['options_json'])
        q_dict['correct_indices'] = json.loads(q['correct_answers_json'])
        q_dict['student_selected'] = answers_given.get(str(q['id']), [])
        formatted_questions.append(q_dict)

    return render_template('student/exam_result.html', exam=exam, result=result, questions=formatted_questions)

@student_bp.route('/academic-results')
@login_required
@role_required('student')
def academic_results():
    user = get_current_user()
    track_activity(user['id'], event_type='VIEW_RESULTS')

    grades_list = query_db("""
        SELECT g.*, c.name as course_name, c.code as course_code, c.semester, c.academic_year, sub.credits
        FROM grades g
        JOIN courses c ON g.course_id = c.id
        JOIN subjects sub ON c.subject_id = sub.id
        WHERE g.student_id = ?
    """, (user['id'],))

    latest_term = query_db("""
        SELECT c.semester, c.academic_year
        FROM grades g
        JOIN courses c ON g.course_id = c.id
        WHERE g.student_id = ?
        ORDER BY c.academic_year DESC, c.semester DESC
        LIMIT 1
    """, (user['id'],), one=True)

    semester_grades = grades_list
    current_semester_label = ''
    if latest_term:
        current_semester_label = f"{latest_term['semester']}"
        semester_grades = [
            g for g in grades_list
            if g['semester'] == latest_term['semester'] and g['academic_year'] == latest_term['academic_year']
        ]

    formatted_grades = []
    for g in grades_list:
        item = dict(g)
        item['a1'], item['a2'], item['a3'] = grade_components(item)
        item['total_score'] = compute_total10(item['a1'], item['a2'], item['a3'])
        formatted_grades.append(item)

    semester_formatted = formatted_grades
    if latest_term:
        semester_formatted = [
            g for g in formatted_grades
            if g['semester'] == latest_term['semester'] and g['academic_year'] == latest_term['academic_year']
        ]

    avg_score = (
        round(sum((g['total_score'] or 0) for g in semester_formatted) / len(semester_formatted), 2)
        if semester_formatted else 0.0
    )
    gpa4 = compute_gpa4(formatted_grades)
    total_courses = len(formatted_grades)
    completed_courses = len([g for g in formatted_grades if g['total_score'] >= 5.0])
    classification = classify_gpa4(gpa4)

    # #region agent log
    _dbg('H2', 'student_routes.py:academic_results', 'academic results scales', {
        'semester_avg_10': avg_score,
        'gpa4': gpa4,
        'current_semester': current_semester_label,
        'semester_grade_count': len(semester_grades),
        'all_grade_count': total_courses,
        'course_totals_10': [g['total_score'] for g in formatted_grades],
        'classification': classification,
    })
    _dbg('H6', 'student_routes.py:academic_results', 'A1 A2 A3 components', {
        'components': [
            {'code': g.get('course_code'), 'a1': g['a1'], 'a2': g['a2'], 'a3': g['a3'], 'assignment': g['assignment_score'], 'quiz': g['quiz_score']}
            for g in formatted_grades
        ],
        'column_count': 3,
    })
    # #endregion

    return render_template(
        'student/academic_results.html',
        grades=formatted_grades,
        avg_score=avg_score,
        gpa4=gpa4,
        current_semester_label=current_semester_label,
        total_courses=total_courses,
        completed_courses=completed_courses,
        classification=classification
    )

@student_bp.route('/ai-assistant')
@login_required
@role_required('student')
def ai_assistant():
    user = get_current_user()
    conv_id = request.args.get('c', type=int)

    # 1. Fetch conversations of student
    conversations = query_db("""
        SELECT * FROM ai_conversations WHERE user_id = ? ORDER BY updated_at DESC
    """, (user['id'],))

    # 2. Select active conversation
    active_conv = None
    messages = []
    if conv_id:
        active_conv = query_db("""
            SELECT * FROM ai_conversations WHERE id = ? AND user_id = ?
        """, (conv_id, user['id']), one=True)
    elif conversations:
        active_conv = conversations[0]

    if active_conv:
        raw_msgs = query_db("""
            SELECT * FROM ai_messages WHERE conversation_id = ? ORDER BY id ASC
        """, (active_conv['id'],))
        for m in raw_msgs:
            d = dict(m)
            d['sources'] = json.loads(d['sources_json']) if d['sources_json'] else []
            messages.append(d)

    # 3. Student's enrolled courses for RAG
    enrolled_courses = query_db("""
        SELECT c.id, c.name, c.code
        FROM enrollments e
        JOIN courses c ON e.course_id = c.id
        WHERE e.student_id = ?
        ORDER BY c.name
    """, (user['id'],))

    return render_template(
        'student/ai_assistant.html',
        conversations=conversations,
        active_conv=active_conv,
        messages=messages,
        enrolled_courses=enrolled_courses
    )

@student_bp.route('/ai-assistant/chat', methods=['POST'])
@login_required
@role_required('student')
def ai_assistant_chat():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form.to_dict()
    prompt = (data.get('message') or '').strip()
    conv_id = data.get('conversation_id', type=int) if isinstance(data.get('conversation_id'), (int, str)) and str(data.get('conversation_id')).isdigit() else None
    mode = data.get('mode', 'general')
    course_id = int(data.get('course_id')) if data.get('course_id') and str(data.get('course_id')).isdigit() else None
    ip = request.remote_addr or '127.0.0.1'

    if not prompt:
        return jsonify({"success": False, "error": "Vui lòng nhập nội dung câu hỏi."}), 400

    # 1. Ensure conversation exists
    if not conv_id:
        title = prompt[:45] + ("..." if len(prompt) > 45 else "")
        conv_id = execute_db("""
            INSERT INTO ai_conversations (user_id, course_id, title, mode)
            VALUES (?, ?, ?, ?)
        """, (user['id'], course_id, title, mode))
    else:
        conv = query_db("SELECT id FROM ai_conversations WHERE id = ? AND user_id = ?", (conv_id, user['id']), one=True)
        if not conv:
            return jsonify({"success": False, "error": "Cuộc hội thoại không tồn tại."}), 404

    # 2. Save user message
    execute_db("""
        INSERT INTO ai_messages (conversation_id, role, content)
        VALUES (?, 'user', ?)
    """, (conv_id, prompt))

    # 3. Call AI (RAG or General)
    if mode == 'rag_doc' and course_id:
        ai_res = query_rag_learning_assistant(
            user_id=user['id'],
            role='student',
            course_id=course_id,
            user_question=prompt,
            ip=ip
        )
    else:
        system_instruction = (
            "Bạn là Trợ lý Học tập AI thông minh của Trường Đại học. "
            "Hãy trả lời đầy đủ, thân thiện, sư phạm, trình bày từng bước rõ ràng, "
            "đưa ra ví dụ minh họa và khuyến khích sinh viên tự học hỏi."
        )
        ai_res = call_ai(
            prompt=prompt,
            system_instruction=system_instruction,
            user_id=user['id'],
            role='student',
            service_name='chat',
            ip=ip
        )
        ai_res['sources'] = []

    # 4. Save assistant response
    execute_db("""
        INSERT INTO ai_messages (conversation_id, role, content, sources_json, tokens_used)
        VALUES (?, 'assistant', ?, ?, ?)
    """, (conv_id, ai_res['content'], json.dumps(ai_res.get('sources', []), ensure_ascii=False), ai_res.get('tokens', 0)))

    execute_db("UPDATE ai_conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", (conv_id,))

    return jsonify({
        "success": ai_res['success'],
        "status": ai_res['status'],
        "conversation_id": conv_id,
        "content": ai_res['content'],
        "sources": ai_res.get('sources', [])
    })

@student_bp.route('/ai-assistant/conversation/new', methods=['POST'])
@login_required
@role_required('student')
def ai_assistant_new_conversation():
    user = get_current_user()
    mode = request.form.get('mode', 'general')
    course_id = request.form.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else None

    new_id = execute_db("""
        INSERT INTO ai_conversations (user_id, course_id, title, mode)
        VALUES (?, ?, 'Cuộc trò chuyện mới', ?)
    """, (user['id'], cid, mode))

    return redirect(url_for('student_bp.ai_assistant', c=new_id))

@student_bp.route('/ai-assistant/conversation/<int:conv_id>/delete', methods=['POST'])
@login_required
@role_required('student')
def ai_assistant_delete_conversation(conv_id):
    user = get_current_user()
    execute_db("DELETE FROM ai_conversations WHERE id = ? AND user_id = ?", (conv_id, user['id']))
    flash("Đã xóa cuộc hội thoại thành công.", "info")
    return redirect(url_for('student_bp.ai_assistant'))


# ==========================================
# PHASE 4: ADAPTIVE LEARNING & SMART STUDY
# ==========================================

@student_bp.route('/learning-path')
@login_required
@role_required('student')
def learning_path():
    user = get_current_user()
    course_id = request.args.get('course_id')
    path_data = compute_student_learning_path(user['id'], course_id)
    return render_template('student/learning_path.html', user=user, path=path_data)

@student_bp.route('/learning-path/update-progress', methods=['POST'])
@login_required
@role_required('student')
def update_topic_progress_endpoint():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    topic_id = data.get('topic_id')
    mastery_score = data.get('mastery_score')
    status = data.get('status')
    notes = data.get('notes')

    if not topic_id:
        return jsonify({'success': False, 'message': 'Thiếu ID chủ đề.'}), 400

    result = update_topic_progress(
        student_id=user['id'],
        topic_id=int(topic_id),
        mastery_score=float(mastery_score) if mastery_score is not None and str(mastery_score).replace('.', '', 1).isdigit() else None,
        status=status,
        notes=notes
    )

    if request.is_json:
        return jsonify(result)
    
    if result.get('success'):
        flash(result.get('message'), 'success')
    else:
        flash(result.get('message'), 'danger')
    return redirect(request.referrer or url_for('student_bp.learning_path'))

@student_bp.route('/smart-study')
@login_required
@role_required('student')
def smart_study():
    user = get_current_user()
    tab = request.args.get('tab', 'flashcards')
    course_id = request.args.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else None

    courses = get_student_courses(user['id'])
    flashcards = get_student_flashcards(user['id'], course_id=cid)
    due_flashcards = get_student_flashcards(user['id'], course_id=cid, filter_due=True)
    flashcard_stats = get_flashcard_stats(user['id'], course_id=cid)
    notes = get_student_notes(user['id'], course_id=cid)
    study_stats = get_study_session_stats(user['id'])

    return render_template(
        'student/smart_study.html',
        user=user,
        tab=tab,
        courses=courses,
        selected_course_id=cid,
        flashcards=flashcards,
        due_flashcards=due_flashcards,
        flashcard_stats=flashcard_stats,
        notes=notes,
        study_stats=study_stats
    )

@student_bp.route('/smart-study/notes/create', methods=['POST'])
@login_required
@role_required('student')
def create_note_endpoint():
    user = get_current_user()
    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    course_id = request.form.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else None
    is_pinned = 1 if request.form.get('is_pinned') else 0

    res = create_student_note(user['id'], title, content, course_id=cid, is_pinned=is_pinned)
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('student_bp.smart_study', tab='notes', course_id=course_id if course_id else ''))

@student_bp.route('/smart-study/notes/<int:note_id>/delete', methods=['POST'])
@login_required
@role_required('student')
def delete_note_endpoint(note_id):
    user = get_current_user()
    res = delete_student_note(user['id'], note_id)
    if res.get('success'):
        flash(res.get('message'), 'info')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('student_bp.smart_study', tab='notes'))

@student_bp.route('/smart-study/flashcards/create', methods=['POST'])
@login_required
@role_required('student')
def create_flashcard_endpoint():
    user = get_current_user()
    front = request.form.get('front_text', '').strip()
    back = request.form.get('back_text', '').strip()
    course_id = request.form.get('course_id')
    cid = int(course_id) if course_id and course_id.isdigit() else None
    deck_name = request.form.get('deck_name', 'Mặc định').strip()

    res = create_flashcard(user['id'], front, back, course_id=cid, deck_name=deck_name)
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('student_bp.smart_study', tab='flashcards', course_id=course_id if course_id else ''))

@student_bp.route('/smart-study/flashcards/ai-generate', methods=['POST'])
@login_required
@role_required('student')
def ai_generate_flashcards_endpoint():
    user = get_current_user()
    course_id = request.form.get('course_id')
    if not course_id or not course_id.isdigit():
        flash('Vui lòng chọn học phần để AI tạo thẻ ghi nhớ.', 'warning')
        return redirect(url_for('student_bp.smart_study', tab='flashcards'))

    topic_prompt = request.form.get('topic_prompt', '').strip()
    count = int(request.form.get('count', 5))

    res = generate_flashcards_with_ai(user['id'], int(course_id), topic_prompt=topic_prompt, count=count)
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message', 'Không thể tạo thẻ ghi nhớ.'), 'danger')
    return redirect(url_for('student_bp.smart_study', tab='flashcards', course_id=course_id))

@student_bp.route('/smart-study/flashcards/<int:card_id>/review', methods=['POST'])
@login_required
@role_required('student')
def review_flashcard_endpoint(card_id):
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    rating = int(data.get('rating', 3))

    res = process_flashcard_review(user['id'], card_id, rating)
    return jsonify(res)

@student_bp.route('/smart-study/flashcards/<int:card_id>/delete', methods=['POST'])
@login_required
@role_required('student')
def delete_flashcard_endpoint(card_id):
    user = get_current_user()
    res = delete_flashcard(user['id'], card_id)
    if res.get('success'):
        flash(res.get('message'), 'info')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('student_bp.smart_study', tab='flashcards'))

@student_bp.route('/smart-study/sessions/record', methods=['POST'])
@login_required
@role_required('student')
def record_study_session_endpoint():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    duration = int(data.get('duration_minutes', 25))
    course_id = data.get('course_id')
    cid = int(course_id) if course_id and str(course_id).isdigit() else None
    study_type = data.get('study_type', 'pomodoro')
    notes = data.get('notes', '')

    res = record_study_session(user['id'], course_id=cid, duration_minutes=duration, study_type=study_type, notes=notes)
    return jsonify(res)


# ==========================================
# PHASE 5: SMART ASSESSMENT & ONLINE CODING
# ==========================================

@student_bp.route('/practice/adaptive')
@login_required
@role_required('student')
def adaptive_practice():
    user = get_current_user()
    courses = get_student_courses(user['id'])
    for c in courses:
        seed_default_question_bank_if_empty(c['id'], user['id'])

    recent_sessions = query_db("""
        SELECT s.*, c.name as course_name, c.code as course_code
        FROM adaptive_test_sessions s
        JOIN courses c ON s.course_id = c.id
        WHERE s.student_id = ?
        ORDER BY s.id DESC LIMIT 5
    """, (user['id'],))

    return render_template('student/adaptive_practice.html', user=user, courses=courses, recent_sessions=recent_sessions)

@student_bp.route('/practice/adaptive/start', methods=['POST'])
@login_required
@role_required('student')
def start_adaptive_practice_endpoint():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    course_id = int(data.get('course_id', 0))
    total_q = int(data.get('total_questions', 10))

    res = start_adaptive_practice(user['id'], course_id, total_questions=total_q)
    return jsonify(res)

@student_bp.route('/practice/adaptive/submit', methods=['POST'])
@login_required
@role_required('student')
def submit_adaptive_answer_endpoint():
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    session_id = int(data.get('session_id', 0))
    question_id = int(data.get('question_id', 0))
    selected_answer = int(data.get('selected_answer', 0))
    response_time = int(data.get('response_time', 10))

    res = submit_adaptive_practice_answer(session_id, question_id, selected_answer, response_time)
    return jsonify(res)

@student_bp.route('/practice/adaptive/report/<int:session_id>')
@login_required
@role_required('student')
def adaptive_practice_report_view(session_id):
    user = get_current_user()
    data = get_adaptive_practice_report(session_id)
    if not data or data['student_id'] != user['id']:
        flash('Không tìm thấy báo cáo hoặc bạn không có quyền xem.', 'danger')
        return redirect(url_for('student_bp.adaptive_practice'))
    return render_template('student/adaptive_practice_report.html', user=user, report=data)

@student_bp.route('/coding-assessments')
@login_required
@role_required('student')
def coding_assessments_list():
    user = get_current_user()
    courses = get_student_courses(user['id'])
    for c in courses:
        seed_default_coding_problems(c['id'], user['id'])

    course_ids = [c['id'] for c in courses]
    problems = []
    if course_ids:
        in_clause = ','.join(map(str, course_ids))
        sql = f"""
            SELECT p.*, c.code as course_code, c.name as course_name,
                   (SELECT MAX(score) FROM coding_submissions WHERE problem_id = p.id AND student_id = ?) as best_score,
                   (SELECT status FROM coding_submissions WHERE problem_id = p.id AND student_id = ? ORDER BY id DESC LIMIT 1) as last_status
            FROM coding_problems p
            JOIN courses c ON p.course_id = c.id
            WHERE p.course_id IN ({in_clause})
            ORDER BY p.id DESC
        """
        problems = query_db(sql, (user['id'], user['id']))

    return render_template('student/coding_list.html', user=user, courses=courses, problems=problems)

@student_bp.route('/coding-assessments/<int:problem_id>')
@login_required
@role_required('student')
def coding_workspace(problem_id):
    user = get_current_user()
    problem = get_coding_problem_detail(problem_id, is_teacher=False)
    if not problem:
        flash('Bài tập lập trình không tồn tại.', 'danger')
        return redirect(url_for('student_bp.coding_assessments_list'))

    submissions = get_student_coding_submissions(problem_id, user['id'])
    return render_template('student/coding_workspace.html', user=user, problem=problem, submissions=submissions)

@student_bp.route('/coding-assessments/<int:problem_id>/submit', methods=['POST'])
@login_required
@role_required('student')
def submit_coding_endpoint(problem_id):
    user = get_current_user()
    data = request.get_json(silent=True) or request.form
    code = data.get('code', '')
    language = data.get('language', 'python')

    res = submit_coding_solution(problem_id, user['id'], code, language)
    return jsonify(res)

@student_bp.route('/assignments/<int:assignment_id>/history')
@login_required
@role_required('student')
def assignment_submission_history_view(assignment_id):
    user = get_current_user()
    assignment = query_db("""
        SELECT a.*, c.name as course_name, c.code as course_code
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    """, (assignment_id,), one=True)
    if not assignment:
        flash('Bài tập không tồn tại.', 'danger')
        return redirect(url_for('student_bp.assignments'))

    history = get_submission_history(assignment_id, user['id'])
    return render_template('student/assignment_history.html', user=user, assignment=assignment, history=history)

@student_bp.route('/assignments/<int:assignment_id>/submit-version', methods=['POST'])
@login_required
@role_required('student')
def submit_assignment_version_endpoint(assignment_id):
    user = get_current_user()
    notes = request.form.get('notes', '').strip()
    stage_name = request.form.get('stage_name', 'Bản nộp tiến trình').strip()
    file_path = request.form.get('file_path', '').strip()

    res = record_submission_version(assignment_id, user['id'], file_path=file_path, notes=notes, stage_name=stage_name)
    flash(res.get('message'), 'success')
    return redirect(url_for('student_bp.assignment_submission_history_view', assignment_id=assignment_id))


# ==========================================
# PHASE 6: COMPETENCIES, PORTFOLIO & BADGES
# ==========================================

@student_bp.route('/competencies')
@login_required
@role_required('student')
def competencies():
    user = get_current_user()
    profile = get_student_competency_profile(user['id'])
    return render_template('student/competencies.html', user=user, profile=profile)

@student_bp.route('/portfolio')
@login_required
@role_required('student')
def portfolio():
    user = get_current_user()
    check_and_auto_award_badges(user['id'])
    port_data = get_or_create_student_portfolio(user['id'])
    badges = get_student_badges(user['id'])
    comp_profile = get_student_competency_profile(user['id'])
    return render_template('student/portfolio.html', user=user, portfolio=port_data, badges=badges, comp_profile=comp_profile)

@student_bp.route('/portfolio/update-profile', methods=['POST'])
@login_required
@role_required('student')
def update_portfolio_profile_endpoint():
    user = get_current_user()
    headline = request.form.get('headline', '')
    bio = request.form.get('bio', '')
    github = request.form.get('github', '')
    linkedin = request.form.get('linkedin', '')
    website = request.form.get('website', '')
    is_public = 1 if request.form.get('is_public') else 0

    social_links = {
        'github': github.strip(),
        'linkedin': linkedin.strip(),
        'website': website.strip()
    }
    res = update_portfolio_profile(user['id'], headline, bio, social_links, is_public)
    flash(res.get('message'), 'success')
    return redirect(url_for('student_bp.portfolio'))

@student_bp.route('/portfolio/items/add', methods=['POST'])
@login_required
@role_required('student')
def add_portfolio_item_endpoint():
    user = get_current_user()
    port = get_or_create_student_portfolio(user['id'])
    item_type = request.form.get('item_type', 'project')
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    image_url = request.form.get('image_url', '').strip()
    link_url = request.form.get('link_url', '').strip()
    skills_raw = request.form.get('skills', '').strip()
    is_pinned = 1 if request.form.get('is_pinned') else 0

    skills = [s.strip() for s in skills_raw.split(',') if s.strip()]
    res = add_portfolio_item(port['id'], item_type, title, description, image_url, link_url, skills, is_pinned)
    if res.get('success'):
        flash(res.get('message'), 'success')
    else:
        flash(res.get('message'), 'danger')
    return redirect(url_for('student_bp.portfolio'))

@student_bp.route('/portfolio/items/<int:item_id>/delete', methods=['POST'])
@login_required
@role_required('student')
def delete_portfolio_item_endpoint(item_id):
    user = get_current_user()
    port = get_or_create_student_portfolio(user['id'])
    res = delete_portfolio_item(port['id'], item_id)
    flash(res.get('message'), 'info')
    return redirect(url_for('student_bp.portfolio'))

@student_bp.route('/badges')
@login_required
@role_required('student')
def badges_view():
    user = get_current_user()
    check_and_auto_award_badges(user['id'])
    earned_badges = get_student_badges(user['id'])
    all_badges = get_all_badges()
    earned_ids = {b['badge_id'] for b in earned_badges}
    return render_template('student/badges.html', user=user, earned_badges=earned_badges, all_badges=all_badges, earned_ids=earned_ids)
