import sys
import os
import json

# Set UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from __init__ import create_app
from database import query_db, DB_PATH
from services.predictive_service import evaluate_student_risk, scan_and_sync_course_risks, get_at_risk_students
from services.analytics_service import get_admin_learning_analytics, get_teacher_learning_analytics

app = create_app()
app.config['TESTING'] = True
client = app.test_client()

print("==================================================")
print("RUNNING COMPREHENSIVE PHASE 2 VERIFICATION SUITE")
print("==================================================")

# 1. Database Schema & Preservation
print("\n[TEST 1] Database Tables & Old Data Preservation:")
with app.app_context():
    tables_rows = query_db("SELECT name FROM sqlite_master WHERE type='table' AND name != 'sqlite_sequence'")
    tables = [r['name'] for r in tables_rows]
    print(f"Total Tables in DB: {len(tables)}/25")
    assert 'student_interventions' in tables, "student_interventions table missing"

    u_cnt = query_db("SELECT COUNT(*) as c FROM users", one=True)['c']
    c_cnt = query_db("SELECT COUNT(*) as c FROM courses", one=True)['c']
    e_cnt = query_db("SELECT COUNT(*) as c FROM enrollments", one=True)['c']
    g_cnt = query_db("SELECT COUNT(*) as c FROM grades", one=True)['c']
    assert u_cnt >= 73, f"Users count changed: {u_cnt}"
    assert c_cnt == 42, f"Courses count changed: {c_cnt}"
    assert e_cnt == 405, f"Enrollments count changed: {e_cnt}"
    assert g_cnt == 248, f"Grades count changed: {g_cnt}"
    print(f"  -> Old data 100% preserved (Users: {u_cnt}, Courses: {c_cnt}, Enrollments: {e_cnt}, Grades: {g_cnt}): PASS")

# 2. Predictive Analytics Service & Explainability
print("\n[TEST 2] Predictive Engine & Risk Assessment:")
with app.app_context():
    # Sync course risks
    scan_and_sync_course_risks()
    at_risk = get_at_risk_students(limit=10)
    assert len(at_risk) > 0, "No interventions populated"
    sample = at_risk[0]
    print(f"  -> Sample Student: {sample['student_name']} ({sample['student_code']})")
    print(f"     Risk Level: {sample['risk_level']}")
    print(f"     Reasons: {sample['reasons']}")
    print(f"     Action: {sample['suggested_action']}")
    assert sample['risk_level'] in ('NEEDS_SUPPORT', 'MONITORING', 'NORMAL')
    assert isinstance(sample['reasons'], list)
    print("  -> Predictive Risk Assessment with transparent explainability: PASS")

# 3. Admin Learning Analytics & Dynamic Filters
print("\n[TEST 3] Admin Learning Analytics (/admin/analytics):")
client.get('/logout')
res = client.post('/login', data={'email': 'admin@example.com', 'password': 'admin123'}, follow_redirects=True)
assert res.status_code == 200

# Base analytics page
res = client.get('/admin/analytics')
assert res.status_code == 200
html = res.data.decode('utf-8')
assert "Learning Analytics & Dự báo Học tập" in html
assert "gradeDistChart" in html
assert "termCompareChart" in html
print("  -> GET /admin/analytics (200 OK & Charts present): PASS")

# Filtered analytics page
res = client.get('/admin/analytics?department_id=1&semester=Học+kỳ+1')
assert res.status_code == 200
print("  -> GET /admin/analytics with dynamic multi-filters: PASS")

# CSV Export
res = client.get('/admin/analytics/export')
assert res.status_code == 200
assert res.mimetype == "text/csv"
csv_text = res.data.decode('utf-8')
assert "BÁO CÁO PHÂN TÍCH HỌC TẬP THÔNG MINH" in csv_text
assert "DANH SÁCH SINH VIÊN CẦN HỖ TRỢ SỚM" in csv_text
print("  -> GET /admin/analytics/export (CSV Export with UTF-8): PASS")

# 4. Teacher Learning Analytics & Interventions
print("\n[TEST 4] Teacher Learning Analytics (/teacher/analytics):")
client.get('/logout')
res = client.post('/login', data={'email': 'teacher@example.com', 'password': 'teacher123'}, follow_redirects=True)
assert res.status_code == 200

res = client.get('/teacher/analytics')
assert res.status_code == 200
t_html = res.data.decode('utf-8')
assert "Phân Tích Kết Quả & Can Thiệp Học Vụ" in t_html
assert "teacherGradeChart" in t_html
print("  -> GET /teacher/analytics (200 OK & Class analytics present): PASS")

# Update intervention status
with app.app_context():
    teacher_u = query_db("SELECT id FROM users WHERE email = 'teacher@example.com'", one=True)
    t_course = query_db("SELECT id FROM courses WHERE teacher_id = ?", (teacher_u['id'],), one=True)
    intervention = query_db("SELECT id FROM student_interventions WHERE course_id = ?", (t_course['id'],), one=True)
    if intervention:
        res = client.post(f"/teacher/analytics/interventions/{intervention['id']}/update", data={
            'status': 'in_progress',
            'notes': 'Đã gửi email nhắc nhở ôn tập',
            'course_id': t_course['id']
        }, follow_redirects=True)
        assert res.status_code == 200
        updated = query_db("SELECT status, teacher_notes FROM student_interventions WHERE id = ?", (intervention['id'],), one=True)
        assert updated['status'] == 'in_progress'
        print("  -> Teacher updated student intervention status to in_progress: PASS")

# 5. Security & RBAC Cross-Role Isolation
print("\n[TEST 5] Security & Cross-Role Access Control:")
client.get('/logout')
res = client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
assert res.status_code == 200

# Student tries Admin Analytics
res = client.get('/admin/analytics', follow_redirects=True)
assert "Bạn không có quyền truy cập" in res.data.decode('utf-8') or "/student/dashboard" in res.request.path
print("  -> Security Test: Student BLOCKED from /admin/analytics: PASS")

# Student tries Teacher Analytics
res = client.get('/teacher/analytics', follow_redirects=True)
assert "Bạn không có quyền truy cập" in res.data.decode('utf-8') or "/student/dashboard" in res.request.path
print("  -> Security Test: Student BLOCKED from /teacher/analytics: PASS")

# 6. Regression Testing Core LMS Routes
print("\n[TEST 6] Regression Testing Core 27 Web Routes:")
client.get('/logout')
for route in ['/login', '/maintenance', '/system-locked', '/forgot-password']:
    res = client.get(route)
    assert res.status_code == 200

client.post('/login', data={'email': 'admin@example.com', 'password': 'admin123'}, follow_redirects=True)
for route in ['/admin/dashboard', '/admin/users', '/admin/education', '/admin/reports', '/admin/notifications', '/admin/analytics']:
    res = client.get(route)
    assert res.status_code == 200

client.get('/logout')
client.post('/login', data={'email': 'teacher@example.com', 'password': 'teacher123'}, follow_redirects=True)
for route in ['/teacher/dashboard', '/teacher/classes', '/teacher/materials', '/teacher/assignments', '/teacher/exams', '/teacher/grades', '/teacher/analytics']:
    res = client.get(route)
    assert res.status_code == 200

client.get('/logout')
client.post('/login', data={'email': 'student@example.com', 'password': 'student123'}, follow_redirects=True)
for route in ['/student/dashboard', '/student/classes', '/student/materials', '/student/assignments', '/student/exams', '/student/academic-results']:
    res = client.get(route)
    assert res.status_code == 200

print("  -> All core routes + new analytics routes verified 100% (200 OK): PASS")

client.get('/logout')
print("\n==================================================")
print("ALL PHASE 2 TESTS PASSED 100% WITH ZERO ERRORS!")
print("==================================================")
