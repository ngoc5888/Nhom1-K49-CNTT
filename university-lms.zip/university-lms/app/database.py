import sqlite3
import os
from flask import g

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lms.db")

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            DB_PATH
        )
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db(db_path=None):
    target_path = db_path or DB_PATH
    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()

    # Foreign key support
    cursor.execute("PRAGMA foreign_keys = ON;")

    # 1. Users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin', 'teacher', 'student')),
        avatar TEXT DEFAULT '/static/images/default_avatar.png',
        phone TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. Departments (Khoa)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        description TEXT DEFAULT ''
    );
    """)

    # 3. Majors (Ngành)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS majors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        department_id INTEGER NOT NULL,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE CASCADE
    );
    """)

    # 4. Student Classes (Lớp sinh hoạt)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_classes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        major_id INTEGER NOT NULL,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        year TEXT DEFAULT '2024-2028',
        FOREIGN KEY (major_id) REFERENCES majors (id) ON DELETE CASCADE
    );
    """)

    # 5. Students
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        user_id INTEGER PRIMARY KEY,
        student_code TEXT UNIQUE NOT NULL,
        department_id INTEGER,
        major_id INTEGER,
        student_class_id INTEGER,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE SET NULL,
        FOREIGN KEY (major_id) REFERENCES majors (id) ON DELETE SET NULL,
        FOREIGN KEY (student_class_id) REFERENCES student_classes (id) ON DELETE SET NULL
    );
    """)

    # 6. Teachers
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS teachers (
        user_id INTEGER PRIMARY KEY,
        teacher_code TEXT UNIQUE NOT NULL,
        department_id INTEGER,
        title TEXT DEFAULT 'Giảng viên',
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE SET NULL
    );
    """)

    # 7. Subjects (Môn học)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        department_id INTEGER,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        credits INTEGER NOT NULL DEFAULT 3,
        description TEXT DEFAULT '',
        FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE SET NULL
    );
    """)

    # 8. Courses (Lớp học phần)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        teacher_id INTEGER NOT NULL,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        semester TEXT DEFAULT 'HK1 (2024-2025)',
        academic_year TEXT DEFAULT '2024-2025',
        room TEXT DEFAULT 'A101',
        schedule_info TEXT DEFAULT 'Thứ 2 (08:00 - 11:30)',
        description TEXT DEFAULT '',
        FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE,
        FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 9. Enrollments (Đăng ký môn học)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active',
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        UNIQUE(course_id, student_id)
    );
    """)

    # 10. Materials (Tài liệu học tập)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS materials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        file_path TEXT NOT NULL,
        file_type TEXT NOT NULL, -- PDF, Word, PowerPoint, Video, Image, Zip
        file_size TEXT DEFAULT '1.2 MB',
        uploaded_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 11. Assignments (Bài tập)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        file_path TEXT DEFAULT '',
        due_date TIMESTAMP NOT NULL,
        max_points REAL DEFAULT 10.0,
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 12. Submissions (Bài nộp của sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        file_path TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        score REAL DEFAULT NULL,
        feedback TEXT DEFAULT '',
        graded_at TIMESTAMP DEFAULT NULL,
        FOREIGN KEY (assignment_id) REFERENCES assignments (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        UNIQUE(assignment_id, student_id)
    );
    """)

    # 13. Exams (Bài kiểm tra / Thi trực tuyến)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        duration_minutes INTEGER NOT NULL DEFAULT 45,
        max_score REAL DEFAULT 10.0,
        start_time TIMESTAMP,
        end_time TIMESTAMP,
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 14. Questions (Câu hỏi kiểm tra)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_id INTEGER NOT NULL,
        question_text TEXT NOT NULL,
        question_type TEXT DEFAULT 'single', -- single, multiple, true_false
        options_json TEXT NOT NULL, -- JSON string array of options ["Đáp án A", "Đáp án B", ...]
        correct_answers_json TEXT NOT NULL, -- JSON string array of correct indices [0] or [0, 2]
        points REAL DEFAULT 1.0,
        FOREIGN KEY (exam_id) REFERENCES exams (id) ON DELETE CASCADE
    );
    """)

    # 15. Exam Results (Kết quả kiểm tra sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        score REAL NOT NULL,
        total_questions INTEGER NOT NULL,
        correct_count INTEGER NOT NULL,
        answers_json TEXT DEFAULT '{}', -- JSON student selected answers
        FOREIGN KEY (exam_id) REFERENCES exams (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 16. Grades (Bảng điểm tổng hợp)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS grades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        assignment_score REAL DEFAULT 0.0,
        quiz_score REAL DEFAULT 0.0,
        midterm_score REAL DEFAULT 0.0,
        final_score REAL DEFAULT 0.0,
        total_score REAL DEFAULT 0.0,
        letter_grade TEXT DEFAULT 'F',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        UNIQUE(course_id, student_id)
    );
    """)

    # 17. Notifications (Thông báo)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        category TEXT DEFAULT 'system', -- assignment, exam, material, grade, teacher, system
        link TEXT DEFAULT '#',
        is_read INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 18. Academic Years (Năm học)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS academic_years (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        start_year INTEGER NOT NULL,
        end_year INTEGER NOT NULL
    );
    """)

    # 19. Semesters (Học kỳ)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS semesters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        academic_year_id INTEGER NOT NULL,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        term INTEGER NOT NULL,
        FOREIGN KEY (academic_year_id) REFERENCES academic_years (id) ON DELETE CASCADE
    );
    """)

    # 20. System Settings (Cấu hình bảo trì & khóa hệ thống)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS system_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 21. Announcements (Thông báo toàn trường & thông báo lớp học phần)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        target_type TEXT NOT NULL, -- 'all', 'student', 'teacher', 'course'
        course_id INTEGER DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );
    """)

    # 22. Audit Logs (Nhật ký kiểm toán thao tác hệ thống)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        user_email TEXT DEFAULT '',
        user_role TEXT DEFAULT '',
        action TEXT NOT NULL,
        target_type TEXT NOT NULL,
        target_id TEXT DEFAULT '',
        details TEXT DEFAULT '',
        ip_address TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
    );
    """)

    # 23. Learning Activities (Nhật ký hoạt động học tập)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS learning_activities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        course_id INTEGER,
        event_type TEXT NOT NULL,
        reference_id INTEGER,
        metadata_json TEXT DEFAULT '{}',
        ip_address TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL
    );
    """)

    # 24. Login History (Lịch sử đăng nhập & bảo mật)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS login_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        email TEXT NOT NULL,
        status TEXT NOT NULL, -- 'SUCCESS', 'FAILED', 'LOCKED'
        ip_address TEXT DEFAULT '',
        user_agent TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 25. Student Interventions (Cảnh báo & Can thiệp hỗ trợ học tập)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_interventions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_id INTEGER NOT NULL,
        risk_level TEXT NOT NULL CHECK(risk_level IN ('NORMAL', 'MONITORING', 'NEEDS_SUPPORT')),
        reasons_json TEXT NOT NULL DEFAULT '[]',
        metrics_json TEXT NOT NULL DEFAULT '{}',
        suggested_action TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'in_progress', 'resolved')),
        teacher_notes TEXT DEFAULT '',
        reviewed_by INTEGER DEFAULT NULL,
        reviewed_at TIMESTAMP DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (reviewed_by) REFERENCES users (id) ON DELETE SET NULL,
        UNIQUE(student_id, course_id)
    );
    """)

    # 26. AI Conversations (Lịch sử cuộc hội thoại AI)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ai_conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        course_id INTEGER DEFAULT NULL,
        title TEXT NOT NULL,
        mode TEXT DEFAULT 'general', -- 'general', 'rag_doc', 'exam_prep'
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL
    );
    """)

    # 27. AI Messages (Tin nhắn chi tiết trong hội thoại)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ai_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversation_id INTEGER NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
        content TEXT NOT NULL,
        sources_json TEXT DEFAULT '[]',
        tokens_used INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (conversation_id) REFERENCES ai_conversations (id) ON DELETE CASCADE
    );
    """)

    # 28. AI Document Chunks (Kho lưu trữ vector / chunks tài liệu RAG)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ai_document_chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        material_id INTEGER NOT NULL,
        course_id INTEGER NOT NULL,
        chunk_index INTEGER NOT NULL,
        content TEXT NOT NULL,
        keywords_json TEXT DEFAULT '[]',
        char_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (material_id) REFERENCES materials (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );
    """)

    # 29. AI Usage Logs (Giám sát hạn mức và chi phí AI)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ai_usage_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        user_role TEXT NOT NULL,
        service_name TEXT NOT NULL, -- 'chat', 'rag', 'quiz_gen', 'exam_gen', 'summary'
        model_used TEXT NOT NULL,
        prompt_tokens INTEGER DEFAULT 0,
        completion_tokens INTEGER DEFAULT 0,
        total_tokens INTEGER DEFAULT 0,
        status TEXT NOT NULL, -- 'SUCCESS', 'FAILED', 'NO_KEY', 'FALLBACK'
        error_message TEXT DEFAULT '',
        ip_address TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 30. Course Topics (Chương mục / Chủ đề học tập thích ứng theo môn học)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS course_topics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        chapter_num INTEGER NOT NULL DEFAULT 1,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        order_index INTEGER NOT NULL DEFAULT 0,
        prerequisite_topic_id INTEGER DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (prerequisite_topic_id) REFERENCES course_topics (id) ON DELETE SET NULL
    );
    """)

    # 31. Student Topic Progress (Tiến độ và mức độ thông thạo từng chủ đề của sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_topic_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        topic_id INTEGER NOT NULL,
        course_id INTEGER NOT NULL,
        mastery_score REAL NOT NULL DEFAULT 0.0, -- 0.0 to 100.0
        status TEXT NOT NULL DEFAULT 'NOT_STARTED' CHECK(status IN ('NOT_STARTED', 'IN_PROGRESS', 'MASTERED', 'NEEDS_REVIEW')),
        last_studied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        notes TEXT DEFAULT '',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (topic_id) REFERENCES course_topics (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        UNIQUE(student_id, topic_id)
    );
    """)

    # 32. Study Notes (Ghi chú học tập thông minh cá nhân của sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_id INTEGER DEFAULT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        is_pinned INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL
    );
    """)

    # 33. Study Flashcards (Thẻ ghi nhớ & thuật toán lặp lại ngắt quãng Spaced Repetition)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_flashcards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_id INTEGER DEFAULT NULL,
        front_text TEXT NOT NULL,
        back_text TEXT NOT NULL,
        deck_name TEXT DEFAULT 'Mặc định',
        ease_factor REAL DEFAULT 2.5,
        interval_days INTEGER DEFAULT 1,
        repetition_count INTEGER DEFAULT 0,
        next_review_date DATE DEFAULT (DATE('now')),
        last_reviewed_at TIMESTAMP DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL
    );
    """)

    # 34. Study Sessions (Phiên học tập thông minh & Pomodoro)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_id INTEGER DEFAULT NULL,
        duration_minutes INTEGER NOT NULL DEFAULT 25,
        study_type TEXT DEFAULT 'pomodoro', -- 'pomodoro', 'review', 'flashcard', 'note'
        notes TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL
    );
    """)

    # 35. Question Bank (Ngân hàng câu hỏi thông minh phân loại chương mục, độ khó, kỹ năng)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS question_bank (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER DEFAULT NULL,
        chapter_num INTEGER DEFAULT 1,
        topic_id INTEGER DEFAULT NULL,
        question_text TEXT NOT NULL,
        question_type TEXT DEFAULT 'single', -- single, multiple, true_false
        options_json TEXT NOT NULL, -- JSON array ["A", "B", "C", "D"]
        correct_answers_json TEXT NOT NULL, -- JSON array of indices [0]
        difficulty TEXT DEFAULT 'MEDIUM' CHECK(difficulty IN ('EASY', 'MEDIUM', 'HARD')),
        points REAL DEFAULT 1.0,
        tags_json TEXT DEFAULT '[]',
        skills_json TEXT DEFAULT '[]',
        explanation TEXT DEFAULT '',
        usage_count INTEGER DEFAULT 0,
        discrimination_index REAL DEFAULT 0.0,
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (topic_id) REFERENCES course_topics (id) ON DELETE SET NULL,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 36. Assessment Matrices (Ma trận đề thi chuẩn hóa)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS assessment_matrices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        total_questions INTEGER NOT NULL DEFAULT 10,
        total_points REAL DEFAULT 10.0,
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 37. Matrix Items (Chi tiết các mục phân bổ trong ma trận đề thi)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS matrix_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        matrix_id INTEGER NOT NULL,
        chapter_num INTEGER DEFAULT 1,
        topic_title TEXT NOT NULL,
        easy_count INTEGER DEFAULT 0,
        medium_count INTEGER DEFAULT 0,
        hard_count INTEGER DEFAULT 0,
        points_per_question REAL DEFAULT 1.0,
        skill_evaluated TEXT DEFAULT '',
        FOREIGN KEY (matrix_id) REFERENCES assessment_matrices (id) ON DELETE CASCADE
    );
    """)

    # 38. Adaptive Test Sessions (Phiên luyện tập thi thích ứng sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS adaptive_test_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_id INTEGER NOT NULL,
        current_difficulty TEXT DEFAULT 'MEDIUM' CHECK(current_difficulty IN ('EASY', 'MEDIUM', 'HARD')),
        total_questions INTEGER DEFAULT 10,
        answered_count INTEGER DEFAULT 0,
        correct_count INTEGER DEFAULT 0,
        final_mastery_pct REAL DEFAULT 0.0,
        status TEXT DEFAULT 'IN_PROGRESS' CHECK(status IN ('IN_PROGRESS', 'COMPLETED')),
        recommendations_json TEXT DEFAULT '[]',
        started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP DEFAULT NULL,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
    );
    """)

    # 39. Adaptive Test Answers (Chi tiết từng câu trả lời trong phiên thi thích ứng)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS adaptive_test_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        question_id INTEGER NOT NULL,
        selected_answer TEXT NOT NULL,
        is_correct INTEGER NOT NULL,
        difficulty_at_step TEXT NOT NULL,
        response_time_seconds INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (session_id) REFERENCES adaptive_test_sessions (id) ON DELETE CASCADE,
        FOREIGN KEY (question_id) REFERENCES question_bank (id) ON DELETE CASCADE
    );
    """)

    # 40. Process Submissions History (Đánh giá theo tiến trình bài tập - Process-based)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS process_submissions_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        version INTEGER NOT NULL DEFAULT 1,
        file_path TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        teacher_feedback TEXT DEFAULT '',
        stage_score REAL DEFAULT NULL,
        stage_name TEXT DEFAULT 'Khởi tạo',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (assignment_id) REFERENCES assignments (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 41. Rubrics (Bộ tiêu chí đánh giá chuẩn)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS rubrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignment_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (assignment_id) REFERENCES assignments (id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 42. Rubric Criteria (Các tiêu chí và trọng số trong Rubric)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS rubric_criteria (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rubric_id INTEGER NOT NULL,
        criterion_name TEXT NOT NULL,
        description TEXT DEFAULT '',
        weight_pct REAL NOT NULL DEFAULT 25.0,
        max_points REAL NOT NULL DEFAULT 10.0,
        levels_json TEXT DEFAULT '[]',
        FOREIGN KEY (rubric_id) REFERENCES rubrics (id) ON DELETE CASCADE
    );
    """)

    # 43. Rubric Evaluations (Chi tiết chấm bài theo tiêu chí Rubric)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS rubric_evaluations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rubric_id INTEGER NOT NULL,
        submission_id INTEGER NOT NULL,
        evaluator_id INTEGER NOT NULL,
        criterion_id INTEGER NOT NULL,
        awarded_points REAL NOT NULL,
        feedback TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (rubric_id) REFERENCES rubrics (id) ON DELETE CASCADE,
        FOREIGN KEY (submission_id) REFERENCES submissions (id) ON DELETE CASCADE,
        FOREIGN KEY (evaluator_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (criterion_id) REFERENCES rubric_criteria (id) ON DELETE CASCADE
    );
    """)

    # 44. Coding Problems (Bài tập lập trình trực tuyến)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS coding_problems (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        difficulty TEXT DEFAULT 'EASY' CHECK(difficulty IN ('EASY', 'MEDIUM', 'HARD')),
        language TEXT DEFAULT 'python',
        starter_code TEXT DEFAULT '',
        time_limit_seconds REAL DEFAULT 2.0,
        memory_limit_mb INTEGER DEFAULT 128,
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 45. Coding Test Cases (Bộ kiểm thử cho bài tập lập trình)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS coding_test_cases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problem_id INTEGER NOT NULL,
        input_data TEXT NOT NULL,
        expected_output TEXT NOT NULL,
        is_hidden INTEGER DEFAULT 0,
        points REAL DEFAULT 1.0,
        FOREIGN KEY (problem_id) REFERENCES coding_problems (id) ON DELETE CASCADE
    );
    """)

    # 46. Coding Submissions (Lịch sử nộp bài và chấm code tự động)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS coding_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problem_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        code TEXT NOT NULL,
        language TEXT DEFAULT 'python',
        status TEXT NOT NULL DEFAULT 'PENDING',
        score REAL DEFAULT 0.0,
        passed_count INTEGER DEFAULT 0,
        total_cases INTEGER DEFAULT 0,
        execution_time_ms REAL DEFAULT 0.0,
        compiler_output TEXT DEFAULT '',
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (problem_id) REFERENCES coding_problems (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 47. Competencies (Danh mục chuẩn năng lực & kỹ năng số)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS competencies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        category TEXT NOT NULL CHECK(category IN ('CNTT', 'Kỹ năng chung', 'Chuyên ngành')),
        description TEXT DEFAULT '',
        max_level INTEGER DEFAULT 5,
        criteria TEXT DEFAULT '',
        icon TEXT DEFAULT 'fa-award',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 48. Competency Mappings (Liên kết năng lực vào môn học, bài tập, đề thi)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS competency_mappings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        competency_id INTEGER NOT NULL,
        target_type TEXT NOT NULL CHECK(target_type IN ('course', 'assignment', 'exam')),
        target_id INTEGER NOT NULL,
        passing_score REAL DEFAULT 7.0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (competency_id) REFERENCES competencies (id) ON DELETE CASCADE
    );
    """)

    # 49. Student Competencies (Hồ sơ mức độ năng lực thực tế của từng sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_competencies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        competency_id INTEGER NOT NULL,
        current_level INTEGER DEFAULT 1,
        status TEXT DEFAULT 'IN_PROGRESS' CHECK(status IN ('ACHIEVED', 'IN_PROGRESS', 'NEEDS_IMPROVEMENT')),
        progress_pct REAL DEFAULT 0.0,
        evidence_json TEXT DEFAULT '[]',
        verified_by INTEGER DEFAULT NULL,
        verified_at TIMESTAMP DEFAULT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (competency_id) REFERENCES competencies (id) ON DELETE CASCADE,
        FOREIGN KEY (verified_by) REFERENCES users (id) ON DELETE SET NULL,
        UNIQUE(student_id, competency_id)
    );
    """)

    # 50. Student Portfolios (Hồ sơ năng lực số Digital Portfolio của sinh viên)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_portfolios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER UNIQUE NOT NULL,
        headline TEXT DEFAULT '',
        bio TEXT DEFAULT '',
        social_links_json TEXT DEFAULT '{}',
        avatar_custom TEXT DEFAULT '',
        is_public INTEGER DEFAULT 1,
        view_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 51. Portfolio Items (Dự án, bài tập tiêu biểu, minh chứng và chứng chỉ trong hồ sơ)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS portfolio_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        portfolio_id INTEGER NOT NULL,
        item_type TEXT NOT NULL CHECK(item_type IN ('project', 'featured_assignment', 'artifact', 'certification')),
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        image_url TEXT DEFAULT '',
        link_url TEXT DEFAULT '',
        skills_json TEXT DEFAULT '[]',
        order_index INTEGER DEFAULT 0,
        is_pinned INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (portfolio_id) REFERENCES student_portfolios (id) ON DELETE CASCADE
    );
    """)

    # 52. Digital Badges (Danh mục huy hiệu số thành tích chuẩn hóa)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS digital_badges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        icon TEXT DEFAULT 'fa-medal',
        color_gradient TEXT DEFAULT 'from-amber-500 to-yellow-500',
        category TEXT DEFAULT 'achievement' CHECK(category IN ('academic', 'skill', 'streak', 'project', 'achievement')),
        criteria TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 53. Student Badges (Lịch sử cấp phát huy hiệu số kèm minh chứng hợp lệ)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_badges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        badge_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        course_id INTEGER DEFAULT NULL,
        evidence_text TEXT DEFAULT '',
        issued_by INTEGER DEFAULT NULL,
        awarded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (badge_id) REFERENCES digital_badges (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL,
        FOREIGN KEY (issued_by) REFERENCES users (id) ON DELETE SET NULL,
        UNIQUE(badge_id, student_id, course_id)
    );
    """)

    # 54. Calendar Events (Lịch học & Công việc thông minh)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS calendar_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        course_id INTEGER DEFAULT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        event_type TEXT DEFAULT 'personal' CHECK(event_type IN ('personal', 'study_session', 'milestone', 'reminder', 'academic')),
        start_time TEXT NOT NULL,
        end_time TEXT DEFAULT NULL,
        is_all_day INTEGER DEFAULT 0,
        color TEXT DEFAULT '#6366f1',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE SET NULL
    );
    """)

    # 55. Course Discussions (Diễn đàn thảo luận theo lớp học phần)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS course_discussions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        is_pinned INTEGER DEFAULT 0,
        is_locked INTEGER DEFAULT 0,
        view_count INTEGER DEFAULT 0,
        upvotes INTEGER DEFAULT 0,
        tags_json TEXT DEFAULT '[]',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 56. Discussion Comments (Bình luận / Phản hồi diễn đàn)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS discussion_comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discussion_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        is_accepted_answer INTEGER DEFAULT 0,
        upvotes INTEGER DEFAULT 0,
        parent_id INTEGER DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (discussion_id) REFERENCES course_discussions (id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (parent_id) REFERENCES discussion_comments (id) ON DELETE CASCADE
    );
    """)

    # 57. Course Groups (Không gian Nhóm học tập & Đồ án)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS course_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        leader_id INTEGER DEFAULT NULL,
        max_members INTEGER DEFAULT 5,
        topic_name TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
        FOREIGN KEY (leader_id) REFERENCES users (id) ON DELETE SET NULL
    );
    """)

    # 58. Group Members (Thành viên nhóm học tập)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        role TEXT DEFAULT 'member' CHECK(role IN ('leader', 'member')),
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (group_id, student_id),
        FOREIGN KEY (group_id) REFERENCES course_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 59. Group Tasks (Phân công nhiệm vụ nhóm & Deadline)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        assigned_to INTEGER DEFAULT NULL,
        status TEXT DEFAULT 'TODO' CHECK(status IN ('TODO', 'IN_PROGRESS', 'REVIEW', 'DONE')),
        priority TEXT DEFAULT 'MEDIUM' CHECK(priority IN ('LOW', 'MEDIUM', 'HIGH')),
        due_date TEXT DEFAULT NULL,
        progress_pct REAL DEFAULT 0.0,
        created_by INTEGER DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES course_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (assigned_to) REFERENCES users (id) ON DELETE SET NULL,
        FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
    );
    """)

    # 60. Group Resources (Tài nguyên & Tài liệu chia sẻ của nhóm)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS group_resources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        uploaded_by INTEGER NOT NULL,
        title TEXT NOT NULL,
        resource_type TEXT DEFAULT 'link' CHECK(resource_type IN ('link', 'file', 'doc')),
        url_or_path TEXT NOT NULL,
        notes TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES course_groups (id) ON DELETE CASCADE,
        FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # Default system settings
    default_settings = {
        'maintenance_mode': '0',
        'system_lock': '0',
        'ai_api_enabled': '0',
        'ai_provider': 'gemini',
        'ai_model': 'gemini-1.5-flash',
        'ai_api_key': '',
        'ai_temperature': '0.7',
        'ai_daily_token_limit': '50000',
        'feature_analytics_enabled': '1',
        'feature_adaptive_enabled': '1',
        'feature_smart_assessment_enabled': '1',
        'max_upload_size_mb': '16',
        'log_retention_days': '90'
    }
    for k, v in default_settings.items():
        cursor.execute("INSERT OR IGNORE INTO system_settings (key, value) VALUES (?, ?)", (k, v))

    conn.commit()
    conn.close()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def execute_db(query, args=()):
    db = get_db()
    cur = db.execute(query, args)
    db.commit()
    last_id = cur.lastrowid
    cur.close()
    return last_id

def get_setting(key, default=None):
    row = query_db("SELECT value FROM system_settings WHERE key = ?", (key,), one=True)
    if row:
        return row['value']
    return default

def set_setting(key, value):
    execute_db("""
        INSERT INTO system_settings (key, value, updated_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
    """, (key, str(value)))
